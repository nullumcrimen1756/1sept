# TODO: Remove Graphical Chart and Replace with Manual Table

## Tasks
- [x] Remove canvas element from views/dashboard.php
- [x] Remove Chart.js script and JavaScript code from views/dashboard.php
- [x] Replace chart section with manual HTML table showing monthly data
- [x] Update main dashboard.php file to replace chart with manual table
- [x] Remove Chart.js script and JavaScript code from main dashboard.php
- [x] Add missing $daftar_jurnal variable definition in main dashboard.php
- [x] Test the dashboard page to ensure manual table displays correctly
