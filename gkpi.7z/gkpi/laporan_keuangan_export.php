<?php
session_start();

// Ambil parameter filter
$selected_year = isset($_GET['tahun']) ? intval($_GET['tahun']) : date('Y');
$jurnal_filter = isset($_GET['jurnal_filter']) ? intval($_GET['jurnal_filter']) : null;

// Validasi session dan data
if (!isset($_SESSION['laporan_keuangan_data']) || empty($_SESSION['laporan_keuangan_data'])) {
    die("Tidak ada data laporan keuangan untuk diexport.");
}

$report_data = $_SESSION['laporan_keuangan_data'];

// Ambil daftar jurnal untuk nama jurnal yang dipilih
require_once 'config.php';
global $conn;

$selected_jurnal_name = 'Semua Jurnal';
if ($jurnal_filter) {
    $sql_jurnal = "SELECT id_jurnal, nama_jurnal FROM jurnal WHERE id_jurnal = ?";
    $stmt_jurnal = $conn->prepare($sql_jurnal);
    $stmt_jurnal->bind_param("i", $jurnal_filter);
    $stmt_jurnal->execute();
    $result_jurnal = $stmt_jurnal->get_result();
    
    if ($result_jurnal && $result_jurnal->num_rows > 0) {
        $row_jurnal = $result_jurnal->fetch_assoc();
        $selected_jurnal_name = $row_jurnal['nama_jurnal'];
    }
}

// Set header untuk download file Excel
header("Content-Type: application/vnd.ms-excel");
header("Content-Disposition: attachment; filename=\"Jurnal_Penerimaan_Pengeluaran_Saluran_{$selected_year}_{$selected_jurnal_name}_" . date('Ymd_His') . ".xls\"");
header("Pragma: no-cache");
header("Expires: 0");

// Fungsi untuk format angka yang kompatibel dengan Excel
function formatRupiahExport($number) {
    return number_format($number, 0, '', ''); // Format tanpa pemisah untuk Excel
}

// Mapping nama jurnal ke singkatan
$jurnal_abbreviations = [
    'Penerimaan Jemaat' => 'PJ',
    'Penerimaan Persembahan' => 'PP',
    'Penerimaan Lain-lain' => 'PL',
    'Pengeluaran Operasional' => 'PO',
    'Pengeluaran Program' => 'PPG',
    'Pengeluaran Lain-lain' => 'PLN',
    'Penerimaan Saldo Bank' => 'PSB',
    'Penerimaan GSG' => 'PGSG',
    'JURNAL PENERIMAAN & PENGELUARAN JEMAAT di Bank Mandiri' => 'JPM',
];
?>
<html>
<head>
    <meta charset="UTF-8">
    <style>
        body { font-family: Arial, sans-serif; margin: 0; padding: 20px; }
        .header { text-align: center; margin-bottom: 30px; }
        .title { font-size: 18pt; font-weight: bold; color: #1F4E78; margin-bottom: 5px; }
        .subtitle { font-size: 14pt; color: #2F75B5; margin-bottom: 15px; }
        .info-table { width: 100%; border-collapse: collapse; margin-bottom: 20px; }
        .info-table td { padding: 5px; border: 1px solid #BFBFBF; }
        .info-label { font-weight: bold; background-color: #E6E6E6; width: 120px; }
        .data-table { width: 100%; border-collapse: collapse; margin-bottom: 15px; }
        .data-table th { background-color: #4472C4; color: white; font-weight: bold; padding: 8px; border: 1px solid #5B5B5B; text-align: center; }
        .data-table td { padding: 6px; border: 1px solid #BFBFBF; vertical-align: top; }
        .month-header { background-color: #8FAADC; color: white; font-weight: bold; text-align: center; }
        .total-row { font-weight: bold; background-color: #D9E1F2; }
        .saldo-row { font-weight: bold; background-color: #E2EFDA; }
        .text-right { text-align: right; }
        .text-center { text-align: center; }
        .number-format { mso-number-format: "#\\.##0"; }
        .date-format { mso-number-format: "dd-mm-yyyy"; }
        .footer { margin-top: 30px; font-style: italic; color: #7F7F7F; text-align: right; }
    </style>
</head>
<body>
    <div class="header">
        <div class="title">JURNAL PENERIMAAN & PENGELUARAN SALURAN GKPI MEDAN KOTA</div>
        <div class="subtitle">PERIODE TAHUN <?= $selected_year ?></div>
    </div>

    <table class="info-table">
        <tr>
            <td class="info-label">Tahun:</td>
            <td><?= $selected_year ?></td>
        </tr>
        <tr>
            <td class="info-label">Jurnal:</td>
            <td><?= htmlspecialchars($selected_jurnal_name) ?></td>
        </tr>
        <tr>
            <td class="info-label">Tanggal Export:</td>
            <td><?= date('d-m-Y H:i:s') ?></td>
        </tr>
    </table>

    <?php if (!empty($report_data)): ?>
    <div style="overflow-x:auto;">
    <table class="data-table">
        <thead>
                <tr>
                    <th colspan="5" class="text-center">PENERIMAAN & PENGELUARAN</th>
                    <th colspan="5" class="text-center">PENERIMAAN & PENGELUARAN</th>
                </tr>
            <tr>
                <th>Tanggal</th>
                <th>Uraian</th>
                <th>Jurnal</th>
                <th>No. Bukti</th>
                <th>Jumlah</th>

                <th>Tanggal</th>
                <th>Uraian</th>
                <th>Jurnal</th>
                <th>No. Bukti</th>
                <th>Jumlah</th>
            </tr>
        </thead>
        <tbody>
            <?php 
            $total_penerimaan_tahun = 0;
            $total_pengeluaran_tahun = 0;
            $saldo_akhir_tahun = 0;
            
            foreach ($report_data as $month => $data): 
                $total_penerimaan_tahun += $data['total_penerimaan'];
                $total_pengeluaran_tahun += $data['total_pengeluaran'];
                $saldo_akhir_tahun = $data['saldo_akhir'];
            ?>
                <tr class="month-header">
                    <td colspan="10" class="text-center"><?= htmlspecialchars($month) ?></td>
                </tr>
                <tr>
                    <td colspan="4"><strong>Saldo Awal</strong></td>
                    <td class="text-right number-format"><?= formatRupiahExport($data['saldo_awal']) ?></td>
                    <td colspan="5"></td>
                </tr>
                <?php
                $max_rows = max(count($data['penerimaan']), count($data['pengeluaran']));
                for ($i = 0; $i < $max_rows; $i++):
                    $p = $data['penerimaan'][$i] ?? null;
                    $k = $data['pengeluaran'][$i] ?? null;
                ?>
                <tr>
                    <td class="date-format"><?= $p['tanggal'] ?? '' ?></td>
                    <td><?= htmlspecialchars($p['uraian'] ?? '') ?></td>
                    <td><?= htmlspecialchars($p['jurnal_abbr'] ?? '') ?></td>
                    <td><?= htmlspecialchars($p['no_bukti'] ?? '') ?></td>
                    <td class="text-right number-format"><?= isset($p['jumlah']) ? formatRupiahExport($p['jumlah']) : '' ?></td>

                    <td class="date-format"><?= $k['tanggal'] ?? '' ?></td>
                    <td><?= htmlspecialchars($k['uraian'] ?? '') ?></td>
                    <td><?= htmlspecialchars($k['jurnal_abbr'] ?? '') ?></td>
                    <td><?= htmlspecialchars($k['no_bukti'] ?? '') ?></td>
                    <td class="text-right number-format"><?= isset($k['jumlah']) ? formatRupiahExport($k['jumlah']) : '' ?></td>
                </tr>
                <?php endfor; ?>
                <tr class="total-row">
                    <td colspan="4" class="text-right"><strong>Total Penerimaan</strong></td>
                    <td class="text-right number-format"><strong><?= formatRupiahExport($data['total_penerimaan']) ?></strong></td>
                    <td colspan="4" class="text-right"><strong>Total Pengeluaran</strong></td>
                    <td class="text-right number-format"><strong><?= formatRupiahExport($data['total_pengeluaran']) ?></strong></td>
                </tr>
                <tr class="saldo-row">
                    <td colspan="9" class="text-right"><strong>Saldo Akhir</strong></td>
                    <td class="text-right number-format"><strong><?= formatRupiahExport($data['saldo_akhir']) ?></strong></td>
                </tr>
            <?php endforeach; ?>
            
            <!-- Total Tahun -->
            <tr class="total-row" style="background-color: #FFD966;">
                <td colspan="4" class="text-right"><strong>TOTAL TAHUN - PENERIMAAN</strong></td>
                <td class="text-right number-format"><strong><?= formatRupiahExport($total_penerimaan_tahun) ?></strong></td>
                <td colspan="4" class="text-right"><strong>TOTAL TAHUN - PENGELUARAN</strong></td>
                <td class="text-right number-format"><strong><?= formatRupiahExport($total_pengeluaran_tahun) ?></strong></td>
            </tr>
            <tr class="saldo-row" style="background-color: #C6E0B4;">
                <td colspan="9" class="text-right"><strong>SALDO AKHIR TAHUN</strong></td>
                <td class="text-right number-format"><strong><?= formatRupiahExport($saldo_akhir_tahun) ?></strong></td>
            </tr>
        </tbody>
    </table>
    </div>
    
    <!-- Ringkasan Statistik -->
    <div style="margin-top: 30px;">
        <table class="info-table">
            <tr class="total-row">
                <td class="info-label">Total Penerimaan Tahun <?= $selected_year ?>:</td>
                <td class="text-right number-format"><strong>Rp <?= number_format($total_penerimaan_tahun, 0, ',', '.') ?></strong></td>
            </tr>
            <tr class="total-row">
                <td class="info-label">Total Pengeluaran Tahun <?= $selected_year ?>:</td>
                <td class="text-right number-format"><strong>Rp <?= number_format($total_pengeluaran_tahun, 0, ',', '.') ?></strong></td>
            </tr>
            <tr class="saldo-row">
                <td class="info-label">Saldo Akhir Tahun <?= $selected_year ?>:</td>
                <td class="text-right number-format"><strong>Rp <?= number_format($saldo_akhir_tahun, 0, ',', '.') ?></strong></td>
            </tr>
        </table>
    </div>
    
    <?php else: ?>
        <div style="color: #FF0000; font-weight: bold; font-style: italic; text-align: center; margin: 30px 0;">
            Tidak ada data laporan keuangan untuk tahun <?= $selected_year ?>.
        </div>
    <?php endif; ?>

    <div class="footer">
        Dokumen ini dihasilkan secara otomatis pada <?= date('d F Y H:i:s') ?> dari Sistem Laporan Keuangan GKPI Medan Kota
    </div>
</body>
</html>
