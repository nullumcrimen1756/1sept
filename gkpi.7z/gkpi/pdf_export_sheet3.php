<?php
session_start();
require_once 'lib/dompdf/autoload.inc.php';
use Dompdf\Dompdf;

if (!isset($_SESSION['sheet3_report']) || empty($_SESSION['sheet3_report'])) {
    die("Tidak ada data laporan untuk diexport.");
}

$report = $_SESSION['sheet3_report'];
require_once 'config.php';
require_once 'includes/url_helper.php';

$selected_jurnal_filter = isset($_GET['jurnal_filter']) ? $_GET['jurnal_filter'] : '';
$selected_tahun_filter = isset($_GET['tahun_filter']) ? $_GET['tahun_filter'] : date('Y');

function formatRupiahExport($number) {
    return number_format($number, 0, '', '');
}

ob_start();
?>
<html>
<head>
    <meta charset="UTF-8">
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 8px;
            font-size: 7pt;
            line-height: 1.1;
        }
        .header { text-align: center; margin-bottom: 10px; }
        .title { font-size: 12pt; font-weight: bold; color: #1F4E78; margin-bottom: 2px; }
        .subtitle { font-size: 9pt; color: #2F75B5; margin-bottom: 8px; }
        .data-table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 10px;
            font-size: 6pt;
            table-layout: auto;
        }
        .data-table th {
            background-color: #2c3e50;
            color: white;
            font-weight: bold;
            padding: 4px 2px;
            border: 1px solid #000;
            text-align: center;
            font-size: 6pt;
            word-wrap: break-word;
            min-width: 40px;
            max-width: 60px;
        }
        .data-table td {
            padding: 3px 2px;
            border: 1px solid #BFBFBF;
            text-align: left;
            font-size: 6pt;
            word-wrap: break-word;
            overflow: hidden;
        }
        .data-table th:nth-child(1) { min-width: 80px; max-width: 100px; }
        .data-table th:nth-child(2) { min-width: 70px; max-width: 90px; }
        .data-table th:nth-child(3) { min-width: 100px; max-width: 140px; }
        .data-table td:nth-child(1) { min-width: 80px; max-width: 100px; }
        .data-table td:nth-child(2) { min-width: 70px; max-width: 90px; }
        .data-table td:nth-child(3) { min-width: 100px; max-width: 140px; }
        .text-right { text-align: right; }
        .text-center { text-align: center; }
        .kelompok-total-row { background-color: #fff3cd; font-weight: bold; font-size: 6pt; }
        .total-keseluruhan-row { background-color: #d1ecf1; font-weight: bold; font-size: 6pt; }
        .number-cell { text-align: right; font-size: 6pt; }
        .footer {
            margin-top: 10px;
            font-style: italic;
            color: #666;
            text-align: right;
            font-size: 6pt;
        }
        .page-break { page-break-before: always; }
        @page { margin: 0.3in; }
    </style>
</head>
<body>
    <div class="header">
        <div class="title">LAPORAN HORIZONTAL (SHEET 3)</div>
        <div class="subtitle">SISTEM KEUANGAN GEREJA - TAHUN <?= $selected_tahun_filter ?></div>
        <?php if ($selected_jurnal_filter && isset($daftar_jurnal[$selected_jurnal_filter])): ?>
            <p>Jurnal: <?= htmlspecialchars($daftar_jurnal[$selected_jurnal_filter]) ?></p>
        <?php endif; ?>
    </div>

    <?php if (!empty($report['bulan']) && !empty($report['all_categories'])): ?>
        <?php
        $filtered_categories = $report['all_categories'] ?? [];
        $filtered_sub_categories = $report['all_sub_categories'] ?? [];
        $filtered_total_kas = $report['total_kas'] ?? [];

        // Split months into groups of 5 for pagination
        $all_months = $report['bulan'];
        $month_groups = array_chunk($all_months, 5);
        $page_number = 1;

        foreach ($month_groups as $month_group):
            if ($page_number > 1): ?>
                <div class="page-break"></div>
            <?php endif; ?>

            <div class="data-table-wrapper">
            <table class="data-table">
                <thead>
                    <tr>
                        <th>Kategori</th>
                        <th>Kode Subkategori</th>
                        <th>Uraian</th>
                        <?php foreach ($month_group as $bulan): ?>
                            <th><?= htmlspecialchars($bulan) ?></th>
                        <?php endforeach; ?>
                        <th>Total</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $current_group = '';
                    $group_totals = array_fill_keys($month_group, 0);
                    $overall_totals = array_fill_keys($month_group, 0);
                    ?>

                <?php if (!empty($report['uang_setoran'])): ?>
                    <?php $totalUangSetoran = 0; ?>
                    <tr>
                        <td>Uang Setoran</td>
                        <td></td>
                        <td></td>
                        <?php foreach ($month_group as $bulan):
                            $amount = isset($report['uang_setoran'][$bulan]) ? $report['uang_setoran'][$bulan] : 0;
                            $totalUangSetoran += $amount;
                            $overall_totals[$bulan] += $amount;
                        ?>
                            <td class="number-cell"><?= formatRupiahExport($amount) ?></td>
                        <?php endforeach; ?>
                        <td class="number-cell"><?= formatRupiahExport($totalUangSetoran) ?></td>
                    </tr>
                <?php endif; ?>

                <?php foreach ($filtered_categories as $kategori): ?>
                    <?php
                    $kelompok = substr($kategori, 0, 3);
                    if ($kelompok !== $current_group && $current_group !== ''): ?>
                        <tr class="kelompok-total-row">
                            <td colspan="2">Total Kelompok <?= $current_group ?></td>
                            <td></td>
                            <?php
                            $group_total = 0;
                            foreach ($month_group as $bulan):
                                $amount = $group_totals[$bulan] ?? 0;
                                $group_total += $amount;
                            ?>
                                <td class="number-cell"><?= formatRupiahExport($amount) ?></td>
                            <?php endforeach; ?>
                            <td class="number-cell"><?= formatRupiahExport($group_total) ?></td>
                        </tr>
                        <?php $group_totals = array_fill_keys($month_group, 0); ?>
                    <?php endif; ?>

                    <?php $current_group = $kelompok; ?>

                    <?php if (isset($filtered_sub_categories[$kategori])): ?>
                        <?php foreach ($filtered_sub_categories[$kategori] as $subkategori): ?>
                            <?php
                            $hasData = false;
                            foreach ($month_group as $bulan) {
                                $uniqueKey = $kategori . "|" . $subkategori . "|" . $bulan;
                                if (isset($filtered_total_kas[$uniqueKey]) && $filtered_total_kas[$uniqueKey] > 0) {
                                    $hasData = true;
                                    break;
                                }
                            }
                            if (!$hasData) continue;
                            ?>

                            <tr>
                                <td><?= htmlspecialchars($kategori) ?></td>
                                <td><?= htmlspecialchars($subkategori) ?></td>
                                <td><?= isset($report['uraian_dict'][$subkategori]) ? htmlspecialchars($report['uraian_dict'][$subkategori]) : '' ?></td>
                                <?php
                                $sub_total = 0;
                                foreach ($month_group as $bulan):
                                    $uniqueKey = $kategori . "|" . $subkategori . "|" . $bulan;
                                    $amount = isset($filtered_total_kas[$uniqueKey]) ? $filtered_total_kas[$uniqueKey] : 0;
                                    $sub_total += $amount;
                                    $group_totals[$bulan] += $amount;
                                    $overall_totals[$bulan] += $amount;
                                ?>
                                    <td class="number-cell"><?= formatRupiahExport($amount) ?></td>
                                <?php endforeach; ?>
                                <td class="number-cell"><?= formatRupiahExport($sub_total) ?></td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                <?php endforeach; ?>

                <?php if ($current_group !== ''): ?>
                    <tr class="kelompok-total-row">
                        <td colspan="2">Total Kelompok <?= $current_group ?></td>
                        <td></td>
                        <?php
                        $group_total = 0;
                        foreach ($month_group as $bulan):
                            $amount = $group_totals[$bulan] ?? 0;
                            $group_total += $amount;
                        ?>
                            <td class="number-cell"><?= formatRupiahExport($amount) ?></td>
                        <?php endforeach; ?>
                        <td class="number-cell"><?= formatRupiahExport($group_total) ?></td>
                    </tr>
                <?php endif; ?>

                    <tr class="total-keseluruhan-row">
                        <td colspan="2">TOTAL KESELURUHAN</td>
                        <td></td>
                        <?php
                        $grand_total = 0;
                        foreach ($month_group as $bulan):
                            $amount = $overall_totals[$bulan] ?? 0;
                            $grand_total += $amount;
                        ?>
                            <td class="number-cell"><?= formatRupiahExport($amount) ?></td>
                        <?php endforeach; ?>
                        <td class="number-cell"><?= formatRupiahExport($grand_total) ?></td>
                    </tr>
                </tbody>
            </table>
            </div>

            <?php $page_number++; ?>
        <?php endforeach; ?>
    <?php else: ?>
        <div style="color: #FF0000; font-weight: bold; text-align: center; margin: 30px 0;">
            Tidak ada data yang cocok dengan filter yang dipilih.
        </div>
    <?php endif; ?>

    <div style="margin-top: 20px; font-style: italic; color: #666; text-align: right;">
        Dokumen ini dihasilkan secara otomatis pada <?= date('d F Y H:i:s') ?> dari Sistem Laporan Keuangan
    </div>
</body>
</html>
<?php
$html = ob_get_clean();

$dompdf = new Dompdf();
$dompdf->loadHtml($html);
$dompdf->setPaper('A4', 'landscape');

// Configure DomPDF for better table handling
$dompdf->set_option('isHtml5ParserEnabled', true);
$dompdf->set_option('isRemoteEnabled', false);
$dompdf->set_option('defaultFont', 'Arial');
$dompdf->set_option('dpi', 96);
$dompdf->set_option('fontHeightRatio', 1.0);

$dompdf->render();
$dompdf->stream("Laporan_Sheet3_Horizontal_" . date('Ymd_His') . ".pdf", ["Attachment" => false]);
exit;
?>
