<?php
// views/laporan_keuangan.php

$selected_year = isset($_GET['tahun']) ? intval($_GET['tahun']) : date('Y');

// Ambil daftar jurnal untuk filter
global $conn;
$sql_jurnal = "SELECT id_jurnal, nama_jurnal FROM jurnal ORDER BY nama_jurnal";
$result_jurnal = $conn->query($sql_jurnal);
$daftar_jurnal = [];
if ($result_jurnal && $result_jurnal->num_rows > 0) {
    while ($row = $result_jurnal->fetch_assoc()) {
        $daftar_jurnal[] = $row;
    }
}

$jurnal_filter = isset($_GET['jurnal_filter']) ? intval($_GET['jurnal_filter']) : null;
$selected_jurnal_name = 'Semua Jurnal';
if ($jurnal_filter) {
    foreach ($daftar_jurnal as $jurnal) {
        if ($jurnal['id_jurnal'] == $jurnal_filter) {
            $selected_jurnal_name = $jurnal['nama_jurnal'];
            break;
        }
    }
}

// Mapping nama jurnal ke singkatan
$jurnal_abbreviations = [
    'Penerimaan Jemaat' => 'PJ',
    'Penerimaan Persembahan' => 'PP',
    'Penerimaan Lain-lain' => 'PL',
    'Pengeluaran Operasional' => 'PO',
    'Pengeluaran Program' => 'PPG',
    'Pengeluaran Lain-lain' => 'PLN',
    // Tambahkan mapping lainnya sesuai kebutuhan
];
?>

<div class="card mb-4">
    <div class="card-header"><br><br>
        <h5>JURNAL PENERIMAAN & PENGELUARAN SALURAN GKPI MEDAN KOTA</h5>
        <form method="get" action="index.php" class="row g-3 align-items-center">
            <input type="hidden" name="action" value="laporan_keuangan">
            <div class="col-auto">
                <label for="tahun" class="form-label">Tahun:</label>
                <input type="number" id="tahun" name="tahun" class="form-control" value="<?= htmlspecialchars($selected_year) ?>" min="2000" max="<?= date('Y') ?>" required>
            </div>
            <div class="col-auto">
                <label for="jurnal_filter" class="form-label">Filter Jurnal:</label>
                <select id="jurnal_filter" name="jurnal_filter" class="form-select">
                    <option value="">Semua Jurnal</option>
                    <?php foreach ($daftar_jurnal as $jurnal): ?>
                        <option value="<?= $jurnal['id_jurnal'] ?>" <?= $jurnal_filter == $jurnal['id_jurnal'] ? 'selected' : '' ?>>
                            <?= htmlspecialchars($jurnal['nama_jurnal']) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-auto">
                <button type="submit" class="btn btn-primary mt-4">Tampilkan</button>
            </div>
            <div class="col-auto">
                <a href="laporan_keuangan_export.php?tahun=<?= $selected_year ?>&jurnal_filter=<?= $jurnal_filter ?>" class="btn btn-success mt-4">
                    <i class="bi bi-file-earmark-excel me-1"></i> Export Excel
                </a>
            </div>
            <div class="col-auto">
                <a href="pdf_export_laporan_keuangan.php?tahun=<?= $selected_year ?>&jurnal_filter=<?= $jurnal_filter ?>" class="btn btn-danger mt-4" target="_blank">
                    <i class="bi bi-file-earmark-pdf me-1"></i> Export PDF
                </a>
            </div>
        </form>
    </div>
</div>

<?php if (!isset($report_data) || empty($report_data)): ?>
    <div class="alert alert-info">Tidak ada data laporan untuk tahun <?= htmlspecialchars($selected_year) ?> <?= $jurnal_filter ? "pada jurnal " . htmlspecialchars($selected_jurnal_name) : "" ?>.</div>
<?php else: ?>
    <div class="table-responsive" style="overflow-x:auto;">
        <table class="table table-bordered table-sm table-structured">
            <thead>
                <tr>
                    <th colspan="5" class="text-center">PENERIMAAN</th>
                    <th colspan="5" class="text-center">PENGELUARAN</th>
                </tr>
                <tr>
                    <th>Tanggal</th>
                    <th>Uraian</th>
                    <th>Jurnal</th>
                    <th>No. Bukti</th>
                    <th>Jumlah</th>

                    <th>Tanggal</th>
                    <th>Uraian</th>
                    <th>Jurnal</th>
                    <th>No. Bukti</th>
                    <th>Jumlah</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($report_data as $month => $data): ?>
                    <tr class="table-primary">
                        <td colspan="10" class="text-center fw-bold"><?= htmlspecialchars($month) ?></td>
                    </tr>
                    <tr>
                        <td colspan="4"><strong>Saldo Awal</strong></td>
                        <td class="text-end"><?= number_format($data['saldo_awal'], 0, ',', '.') ?></td>
                        <td colspan="5"></td>
                    </tr>
                    <?php
                    $max_rows = max(count($data['penerimaan']), count($data['pengeluaran']));
                    for ($i = 0; $i < $max_rows; $i++):
                        $p = $data['penerimaan'][$i] ?? null;
                        $k = $data['pengeluaran'][$i] ?? null;
                    ?>
                    <tr>
                        <td><?= $p['tanggal'] ?? '' ?></td>
                        <td><?= htmlspecialchars($p['uraian'] ?? '') ?></td>
                        <td><?= htmlspecialchars($p['jurnal_abbr'] ?? '') ?></td>
                        <td><?= htmlspecialchars($p['no_bukti'] ?? '') ?></td>
                        <td class="text-end"><?= isset($p['jumlah']) ? number_format($p['jumlah'], 0, ',', '.') : '' ?></td>

                        <td><?= $k['tanggal'] ?? '' ?></td>
                        <td><?= htmlspecialchars($k['uraian'] ?? '') ?></td>
                        <td><?= htmlspecialchars($k['jurnal_abbr'] ?? '') ?></td>
                        <td><?= htmlspecialchars($k['no_bukti'] ?? '') ?></td>
                        <td class="text-end"><?= isset($k['jumlah']) ? number_format($k['jumlah'], 0, ',', '.') : '' ?></td>
                    </tr>
                    <?php endfor; ?>
                    <tr class="table-info fw-bold">
                        <td colspan="4" class="text-end">Total Penerimaan <?= htmlspecialchars($month) ?></td>
                        <td class="text-end"><?= number_format($data['total_penerimaan'], 0, ',', '.') ?></td>
                        <td colspan="4" class="text-end">Total Pengeluaran <?= htmlspecialchars($month) ?></td>
                        <td class="text-end"><?= number_format($data['total_pengeluaran'], 0, ',', '.') ?></td>
                    </tr>
                    <tr class="table-success fw-bold">
                        <td colspan="9" class="text-end">Saldo Akhir <?= htmlspecialchars($month) ?></td>
                        <td class="text-end"><?= number_format($data['saldo_akhir'], 0, ',', '.') ?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
<?php endif; ?>
