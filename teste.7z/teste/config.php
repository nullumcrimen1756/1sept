<?php
// Error reporting untuk development (comment untuk production)
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Konfigurasi Database
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'gereja');

// Koneksi ke Database
$conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);

if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

// Set timezone
date_default_timezone_set('Asia/Jakarta');

// Base URL Configuration
// Deteksi otomatis base URL atau set manual
function getBaseUrl() {
    $protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https://' : 'http://';
    $host = $_SERVER['HTTP_HOST'];
    $script = $_SERVER['SCRIPT_NAME'];
    $path = dirname($script);

    // Normalisasi path
    $path = str_replace('\\', '/', $path);
    $path = rtrim($path, '/');

    return $protocol . $host . $path;
}

// Set base URL
define('BASE_URL', getBaseUrl()); // Auto-detection untuk development

// Manual base URL untuk production (uncomment dan edit sesuai domain, lalu comment baris di atas)
// define('BASE_URL', 'http://localhost/teste');
// define('BASE_URL', 'https://yourdomain.com/gereja');
// define('BASE_URL', 'https://gerejaku.com/keuangan');

// Hapus/komentari fungsi URL helper dari config.php untuk menghindari konflik
// Semua fungsi URL helper sekarang ada di includes/url_helper.php
/*
// Helper functions untuk URL - DIPINDAH KE includes/url_helper.php
function url($path = '') {
    $path = ltrim($path, '/');
    return BASE_URL . ($path ? '/' . $path : '');
}

function asset($path = '') {
    return url($path);
}

function redirect($path = '') {
    header('Location: ' . url($path));
    exit;
}

// Helper functions untuk file paths - DIPINDAH KE includes/url_helper.php
function base_path($path = '') {
    return __DIR__ . ($path ? DIRECTORY_SEPARATOR . $path : '');
}

function views_path($path = '') {
    return base_path('views' . ($path ? DIRECTORY_SEPARATOR . $path : ''));
}

function include_view($view) {
    return include views_path($view);
}
*/

// Ambil daftar jurnal dari database
$daftar_jurnal = [];
$sql = "SELECT id_jurnal, kode_jurnal, nama_jurnal FROM jurnal ORDER BY id_jurnal";
$result = $conn->query($sql);

if ($result && $result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $daftar_jurnal[$row['id_jurnal']] = $row['nama_jurnal'];
    }
} else {
    // Fallback jika tabel jurnal kosong atau error
    $daftar_jurnal = [
        1 => 'Pengeluaran Jemaat',
        2 => 'Penerimaan Jemaat',
        3 => 'Penerimaan Saldo Bank',
        4 => 'Penerimaan GSG',
        5 => 'JURNAL PENERIMAAN & PENGELUARAN JEMAAT di Bank Mandiri'
    ];
}
?>