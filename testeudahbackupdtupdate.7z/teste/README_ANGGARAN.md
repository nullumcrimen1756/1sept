# Sistem Anggaran Pendapatan Realtime

## Deskripsi
Sistem ini memungkinkan pengguna untuk menginput dan menyimpan data anggaran pendapatan secara realtime ke database. Data anggaran akan otomatis tersimpan setiap kali ada perubahan input.

## Fitur Utama

### 1. Input Anggaran Realtime
- Input anggaran untuk Uang Setoran
- Input anggaran untuk setiap Kelompok
- Input anggaran untuk setiap Subkategori
- Input anggaran untuk Total Keseluruhan

### 2. Penyimpanan Otomatis
- Data tersimpan ke database secara realtime
- Tidak perlu tombol save/update
- Data tersimpan setiap kali ada perubahan input

### 3. Reset Anggaran
- Double click pada input untuk reset nilai
- Konfirmasi sebelum reset
- Nilai akan diset ke 0 di database

### 4. Notifikasi
- Notifikasi sukses saat berhasil menyimpan
- Notifikasi error jika gagal menyimpan
- Notifikasi otomatis hilang setelah 3 detik

## Struktur Database

### Tabel: `anggaran_pendapatan`
```sql
CREATE TABLE anggaran_pendapatan (
    id INT PRIMARY KEY AUTO_INCREMENT,
    kode_subkategori VARCHAR(50),
    bulan VARCHAR(20) NOT NULL,
    jumlah DECIMAL(15,2) NOT NULL DEFAULT 0.00,
    type ENUM('uang-setoran', 'kelompok', 'subkategori', 'keseluruhan') NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY unique_anggaran (kode_subkategori, bulan, type)
);
```

### Field Type:
- `uang-setoran`: Untuk anggaran uang setoran
- `kelompok`: Untuk anggaran per kelompok (3 digit pertama kode)
- `subkategori`: Untuk anggaran per subkategori
- `keseluruhan`: Untuk anggaran total keseluruhan

## Cara Penggunaan

### 1. Input Anggaran
1. Klik pada kolom "Anggaran Pendapatan"
2. Masukkan nilai anggaran
3. Data akan otomatis tersimpan ke database
4. Notifikasi akan muncul di pojok kanan atas

### 2. Reset Anggaran
1. Double click pada input anggaran
2. Konfirmasi reset
3. Nilai akan diset ke 0
4. Data akan diupdate di database

### 3. Melihat Anggaran Tersimpan
1. Refresh halaman atau buka ulang laporan
2. Nilai anggaran yang tersimpan akan otomatis muncul
3. Perhitungan selisih akan otomatis diupdate

## File yang Dimodifikasi

### 1. `functions.php`
- Ditambahkan fungsi `saveAnggaranPendapatan()` dengan pendekatan INSERT/UPDATE sederhana
- Ditambahkan fungsi `handleSaveAnggaran()`
- Dimodifikasi fungsi `generateSheet3Report()` untuk membaca anggaran
- Fungsi save menggunakan pendekatan SELECT → INSERT/UPDATE (tanpa ON DUPLICATE KEY)

### 2. `views/sheet3_report.php`
- Input anggaran menampilkan nilai yang tersimpan
- JavaScript untuk penyimpanan realtime
- Fungsi notifikasi
- Event listener untuk input dan double click

### 3. `api/save_anggaran.php`
- API endpoint untuk menyimpan anggaran
- Handle CORS dan validasi input

## Instalasi

### 1. Setup Otomatis (Recommended)
```bash
# Buka browser dan akses:
http://localhost/teste/setup_anggaran.php
```
File ini akan otomatis:
- Membuat tabel `anggaran_pendapatan` dengan struktur yang benar
- Menambahkan kolom `type` jika belum ada
- Membuat unique key yang sesuai
- Insert data contoh

### 2. Repair Database (jika ada error)
```bash
# Jika ada masalah dengan struktur tabel, akses:
http://localhost/teste/repair_database.php
```
File ini akan:
- Memperbaiki struktur tabel yang rusak
- Menambahkan kolom yang hilang
- Memperbaiki constraint dan index

### 3. SQL Manual (jika diperlukan)
```sql
-- Jalankan query ini di phpMyAdmin jika ada error:
source fix_database.sql;
```

### 4. Pastikan Struktur File
```
teste/
├── api/
│   └── save_anggaran.php
├── views/
│   └── sheet3_report.php
├── functions.php
├── config.php
├── setup_anggaran.php
├── repair_database.php
├── fix_database.sql
├── create_anggaran_table.sql
└── index_anggaran.html
```

### 3. Test Fitur
1. **Test Fitur Anggaran:** Buka Sheet 3 Report dan input nilai anggaran
2. **Verifikasi Database:** Refresh halaman untuk memastikan data muncul kembali

## Troubleshooting

### 1. Error Kolom `type` Tidak Ditemukan
**Gejala:** Error "Unknown column 'type' in 'field list'"
**Solusi:**
1. Jalankan `repair_database.php` untuk memperbaiki struktur tabel
2. Atau jalankan query manual di phpMyAdmin:
   ```sql
   ALTER TABLE anggaran_pendapatan 
   ADD COLUMN type ENUM('uang-setoran', 'kelompok', 'subkategori', 'keseluruhan') 
   NOT NULL DEFAULT 'subkategori' AFTER jumlah;
   ```

### 2. Data Tidak Tersimpan
- Periksa koneksi database
- Periksa error log PHP
- Pastikan tabel `anggaran_pendapatan` sudah dibuat
- Jalankan `repair_database.php` untuk memperbaiki struktur

### 2. Notifikasi Tidak Muncul
- Periksa console browser untuk error JavaScript
- Pastikan Bootstrap CSS/JS sudah dimuat
- Periksa apakah ada konflik CSS

### 3. Input Tidak Responsif
- Periksa apakah JavaScript berjalan
- Pastikan event listener terpasang dengan benar
- Periksa struktur HTML untuk selector yang benar

## Keamanan

### 1. Validasi Input
- Input divalidasi di sisi server
- Prepared statement untuk mencegah SQL injection
- Validasi tipe data dan format

### 2. CORS
- API endpoint mengizinkan request dari semua origin
- Bisa dibatasi sesuai kebutuhan keamanan

### 3. Session
- Menggunakan session PHP untuk autentikasi
- Pastikan user sudah login sebelum mengakses fitur

## Pengembangan Selanjutnya

### 1. Fitur Tambahan
- Export anggaran ke Excel/PDF
- History perubahan anggaran
- Approval workflow untuk anggaran
- Multi-user dengan permission

### 2. Optimasi
- Debounce input untuk mengurangi request
- Cache data anggaran
- Batch update untuk multiple input

### 3. Monitoring
- Log aktivitas user
- Dashboard monitoring anggaran
- Alert untuk anggaran yang melebihi target
