<?php
require_once 'config.php';

// Set timezone
date_default_timezone_set('Asia/Jakarta');

// Check if this is a web request (not CLI)
$is_web_request = !isset($argv[0]) || !preg_match('/backup_transaksi\.php$/', $argv[0]);

// Function to create backup directory if not exists
function createBackupDir($dir) {
    if (!is_dir($dir)) {
        if (!mkdir($dir, 0755, true)) {
            return false;
        }
    }
    return true;
}

// Function to get the latest backup file
function getLatestBackupFile($backup_dir) {
    if (!is_dir($backup_dir)) {
        return null;
    }

    $files = scandir($backup_dir);
    $latest_backup = null;
    $latest_time = 0;

    foreach ($files as $file) {
        if (strpos($file, 'transaksi_backup_') === 0 && pathinfo($file, PATHINFO_EXTENSION) === 'sql') {
            // Extract date from filename (format: transaksi_backup_YYYYMMDD.sql)
            $date_str = substr($file, 17, 8); // Get YYYYMMDD part
            $file_time = strtotime($date_str);

            if ($file_time > $latest_time) {
                $latest_time = $file_time;
                $latest_backup = $file;
            }
        }
    }

    return $latest_backup;
}

// Function to check if there is new data since last backup
function hasNewDataSinceLastBackup($conn, $last_backup_date) {
    if (!$last_backup_date) {
        return true; // No previous backup, so there is "new" data
    }

    // Get comprehensive data about current transaksi table state
    $sql = "SELECT
                COUNT(*) as total_records,
                MAX(created_at) as latest_created,
                MD5(GROUP_CONCAT(
                    CONCAT_WS('|',
                        COALESCE(id_transaksi, ''),
                        COALESCE(tanggal, ''),
                        COALESCE(no_kwitansi, ''),
                        COALESCE(uraian, ''),
                        COALESCE(jumlah, ''),
                        COALESCE(setoran, ''),
                        COALESCE(id_jurnal, ''),
                        COALESCE(id_subkategori, ''),
                        COALESCE(created_at, '')
                    ) ORDER BY id_transaksi
                )) as data_checksum
            FROM transaksi";

    $result = $conn->query($sql);

    if ($result && $result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $current_count = $row['total_records'];
        $latest_created = $row['latest_created'];
        $current_checksum = $row['data_checksum'];

        // If no records, no need to backup
        if ($current_count == 0) {
            return false;
        }

        // Check if there's newer data based on created_at
        $has_newer_data = false;
        if ($latest_created) {
            $latest_backup_time = strtotime($last_backup_date);
            $latest_data_time = strtotime($latest_created);
            $has_newer_data = $latest_data_time > $latest_backup_time;
        }

        // Also check if the data has changed by comparing checksums
        // We'll store the checksum in a simple file for comparison
        $checksum_file = __DIR__ . '/backupdb/last_backup_checksum.txt';
        $has_data_changed = true;

        if (file_exists($checksum_file)) {
            $last_checksum = trim(file_get_contents($checksum_file));
            $has_data_changed = ($last_checksum !== $current_checksum);
        }

        // Update checksum file for next comparison
        file_put_contents($checksum_file, $current_checksum);

        // Return true if either condition is met:
        // 1. Newer data exists (new inserts)
        // 2. Data has changed (updates or deletes)
        return $has_newer_data || $has_data_changed;
    }

    return false; // No data or error, assume no new data
}

// Function to perform conditional backup
function performConditionalBackup($conn, $backup_dir) {
    $today = date('Ymd');
    $filename = $backup_dir . '/transaksi_backup_' . $today . '.sql';

    // Get latest backup file
    $latest_backup = getLatestBackupFile($backup_dir);
    $last_backup_date = null;

    if ($latest_backup) {
        // Extract date from filename
        $date_str = substr($latest_backup, 17, 8);
        $last_backup_date = date('Y-m-d', strtotime($date_str));
    }

    // Check if there is new data
    if (!hasNewDataSinceLastBackup($conn, $last_backup_date)) {
        return [
            'success' => false,
            'message' => 'Tidak ada data baru sejak backup terakhir. Backup dibatalkan.',
            'skipped' => true
        ];
    }

    // Create backup directory if not exists
    if (!createBackupDir($backup_dir)) {
        return [
            'success' => false,
            'message' => 'Error: Cannot create backup directory',
            'skipped' => false
        ];
    }

    // Perform backup
    $message = exportTransaksiToSQL($conn, $filename);

    if (strpos($message, 'Error') === 0) {
        return [
            'success' => false,
            'message' => $message,
            'skipped' => false
        ];
    }

    return [
        'success' => true,
        'message' => $message,
        'filename' => basename($filename),
        'filepath' => $filename,
        'skipped' => false
    ];
}

// Function to export transaksi table to SQL
function exportTransaksiToSQL($conn, $filename) {
    // Query to get all transaksi data
    $sql = "SELECT * FROM transaksi ORDER BY tanggal DESC, created_at DESC";

    $result = $conn->query($sql);

    if (!$result) {
        return "Error: " . $conn->error;
    }

    // Open file for writing
    $file = fopen($filename, 'w');

    if (!$file) {
        return "Error: Cannot create backup file";
    }

    // Write SQL header
    $backup_date = date('Y-m-d H:i:s');
    fwrite($file, "-- Backup transaksi table\n");
    fwrite($file, "-- Generated on: $backup_date\n");
    fwrite($file, "-- Total records: " . $result->num_rows . "\n\n");

    // Write table structure (simplified)
    fwrite($file, "-- Table structure for transaksi\n");
    fwrite($file, "CREATE TABLE IF NOT EXISTS `transaksi` (\n");
    fwrite($file, "  `id_transaksi` int(11) NOT NULL AUTO_INCREMENT,\n");
    fwrite($file, "  `tanggal` date NOT NULL,\n");
    fwrite($file, "  `no_kwitansi` varchar(50) DEFAULT NULL,\n");
    fwrite($file, "  `uraian` text,\n");
    fwrite($file, "  `jumlah` decimal(15,2) NOT NULL,\n");
    fwrite($file, "  `setoran` decimal(15,2) DEFAULT NULL,\n");
    fwrite($file, "  `id_jurnal` int(11) DEFAULT NULL,\n");
    fwrite($file, "  `id_subkategori` int(11) DEFAULT NULL,\n");
    fwrite($file, "  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,\n");
    fwrite($file, "  PRIMARY KEY (`id_transaksi`)\n");
    fwrite($file, ") ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;\n\n");

    // Write disable foreign key checks
    fwrite($file, "-- Disable foreign key checks\n");
    fwrite($file, "SET FOREIGN_KEY_CHECKS = 0;\n\n");

    // Write delete existing data
    fwrite($file, "-- Clear existing data\n");
    fwrite($file, "DELETE FROM `transaksi`;\n\n");

    // Write data rows as INSERT statements
    $total_records = 0;
    $batch_size = 100; // Insert in batches of 100
    $current_batch = [];

    while ($row = $result->fetch_assoc()) {
        $current_batch[] = $row;
        $total_records++;

        if (count($current_batch) >= $batch_size) {
            writeInsertBatch($file, $current_batch);
            $current_batch = [];
        }
    }

    // Write remaining records
    if (!empty($current_batch)) {
        writeInsertBatch($file, $current_batch);
    }

    // Write enable foreign key checks
    fwrite($file, "\n-- Enable foreign key checks\n");
    fwrite($file, "SET FOREIGN_KEY_CHECKS = 1;\n");

    fclose($file);

    return "Backup SQL berhasil dibuat. Total records: " . $total_records;
}

// Helper function to write INSERT batch
function writeInsertBatch($file, $batch) {
    if (empty($batch)) return;

    fwrite($file, "INSERT INTO `transaksi` (`id_transaksi`, `tanggal`, `no_kwitansi`, `uraian`, `jumlah`, `setoran`, `id_jurnal`, `id_subkategori`, `created_at`) VALUES\n");

    $values = [];
    foreach ($batch as $row) {
        $tanggal = $row['tanggal'];
        $no_kwitansi = $row['no_kwitansi'] ? "'" . $row['no_kwitansi'] . "'" : "NULL";
        $uraian = $row['uraian'] ? "'" . addslashes($row['uraian']) . "'" : "NULL";
        $jumlah = $row['jumlah'];
        $setoran = $row['setoran'] !== null ? $row['setoran'] : "NULL";
        $id_jurnal = $row['id_jurnal'] !== null ? $row['id_jurnal'] : "NULL";
        $id_subkategori = $row['id_subkategori'] !== null ? $row['id_subkategori'] : "NULL";
        $created_at = $row['created_at'];

        $values[] = "({$row['id_transaksi']}, '{$tanggal}', {$no_kwitansi}, {$uraian}, {$jumlah}, {$setoran}, {$id_jurnal}, {$id_subkategori}, '{$created_at}')";
    }

    fwrite($file, implode(",\n", $values) . ";\n");
}

// Only execute main backup logic if this file is called directly (not included)
if (__FILE__ === $_SERVER['SCRIPT_FILENAME']) {
    // Main backup logic
    $backup_dir = __DIR__ . '/backupdb';
    $today = date('Ymd');
    $current_month = date('Ym');
    $filename = $backup_dir . '/transaksi_backup_' . $today . '.sql';

    // Check if manual backup is requested or if it's the 15th of the month
    $manual_backup = (isset($_GET['manual']) && $_GET['manual'] == '1') || (isset($argv[1]) && $argv[1] == 'manual');
    $current_day = date('d');

    if (!$manual_backup && $current_day != '15') {
        echo "Backup otomatis hanya berjalan pada tanggal 15 setiap bulan. Gunakan ?manual=1 untuk backup manual atau jalankan dengan argumen 'manual'.";
        exit;
    }

// Create backup directory
if (!createBackupDir($backup_dir)) {
    echo "Error: Cannot create backup directory";
    exit;
}

// Check for existing backup this month
$existing_backup = false;
if (is_dir($backup_dir)) {
    $files = scandir($backup_dir);
    foreach ($files as $file) {
        if (strpos($file, 'transaksi_backup_' . $current_month) === 0 && pathinfo($file, PATHINFO_EXTENSION) === 'sql') {
            $existing_backup = $file;
            break;
        }
    }
}

if ($existing_backup && !$manual_backup) {
    echo "Backup untuk bulan ini sudah ada: " . $existing_backup . "\n";
    echo "Backup otomatis dilewati untuk menghindari duplikasi.";
    exit;
}

if ($existing_backup && $manual_backup) {
    echo "Peringatan: Backup untuk bulan ini sudah ada: " . $existing_backup . "\n";
    echo "Melanjutkan backup manual...\n\n";
}

// Perform backup
$message = exportTransaksiToSQL($conn, $filename);

// Output result
if ($is_web_request) {
    // HTML output for web requests
    ?>
    <!DOCTYPE html>
    <html lang="id">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Backup Transaksi - Sistem Keuangan</title>
        <style>
            body {
                font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
                background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                margin: 0;
                padding: 0;
                min-height: 100vh;
                display: flex;
                justify-content: center;
                align-items: center;
            }
            .container {
                background: white;
                border-radius: 15px;
                box-shadow: 0 20px 40px rgba(0,0,0,0.1);
                padding: 40px;
                max-width: 600px;
                width: 90%;
                text-align: center;
            }
            .header {
                margin-bottom: 30px;
            }
            .header h1 {
                color: #333;
                margin: 0 0 10px 0;
                font-size: 2.5em;
            }
            .header p {
                color: #666;
                margin: 0;
                font-size: 1.1em;
            }
            .result {
                background: #f8f9fa;
                border-radius: 10px;
                padding: 25px;
                margin: 20px 0;
                border-left: 5px solid <?php echo strpos($message, 'Error') === 0 ? '#dc3545' : '#28a745'; ?>;
            }
            .success {
                color: #155724;
                background-color: #d4edda;
                border-color: #c3e6cb;
            }
            .error {
                color: #721c24;
                background-color: #f8d7da;
                border-color: #f5c6cb;
            }
            .warning {
                color: #856404;
                background-color: #fff3cd;
                border-color: #ffeaa7;
            }
            .file-info {
                background: #e9ecef;
                padding: 15px;
                border-radius: 8px;
                margin: 15px 0;
                font-family: 'Courier New', monospace;
                font-size: 0.9em;
            }
            .buttons {
                margin-top: 30px;
                display: flex;
                gap: 15px;
                justify-content: center;
                flex-wrap: wrap;
            }
            .btn {
                padding: 12px 25px;
                border: none;
                border-radius: 8px;
                text-decoration: none;
                font-weight: 600;
                font-size: 1em;
                cursor: pointer;
                transition: all 0.3s ease;
                display: inline-block;
                min-width: 120px;
            }
            .btn-primary {
                background: #007bff;
                color: white;
            }
            .btn-primary:hover {
                background: #0056b3;
                transform: translateY(-2px);
            }
            .btn-secondary {
                background: #6c757d;
                color: white;
            }
            .btn-secondary:hover {
                background: #545b62;
                transform: translateY(-2px);
            }
            .btn-success {
                background: #28a745;
                color: white;
            }
            .btn-success:hover {
                background: #1e7e34;
                transform: translateY(-2px);
            }
            .icon {
                font-size: 3em;
                margin-bottom: 15px;
            }
            .success-icon {
                color: #28a745;
            }
            .error-icon {
                color: #dc3545;
            }
            .warning-icon {
                color: #ffc107;
            }
            @media (max-width: 480px) {
                .container {
                    padding: 20px;
                }
                .header h1 {
                    font-size: 2em;
                }
                .buttons {
                    flex-direction: column;
                    align-items: center;
                }
                .btn {
                    width: 100%;
                    max-width: 200px;
                }
            }
        </style>
    </head>
    <body>
        <div class="container">
            <div class="header">
                <h1>💾 Backup Transaksi</h1>
                <p>Sistem Backup Data Transaksi</p>
            </div>

            <?php if (strpos($message, 'Error') === 0): ?>
                <div class="result error">
                    <div class="error-icon icon">❌</div>
                    <h3>Backup Gagal</h3>
                    <p><?php echo htmlspecialchars($message); ?></p>
                </div>
            <?php elseif ($existing_backup && $manual_backup): ?>
                <div class="result warning">
                    <div class="warning-icon icon">⚠️</div>
                    <h3>Backup Berhasil (Dengan Peringatan)</h3>
                    <p><?php echo htmlspecialchars($message); ?></p>
                    <div class="file-info">
                        <strong>Backup sebelumnya:</strong> <?php echo htmlspecialchars($existing_backup); ?><br>
                        <strong>File baru:</strong> <?php echo htmlspecialchars(basename($filename)); ?><br>
                        <strong>Lokasi:</strong> <?php echo htmlspecialchars($filename); ?>
                    </div>
                </div>
            <?php else: ?>
                <div class="result success">
                    <div class="success-icon icon">✅</div>
                    <h3>Backup Berhasil</h3>
                    <p><?php echo htmlspecialchars($message); ?></p>
                    <div class="file-info">
                        <strong>File:</strong> <?php echo htmlspecialchars(basename($filename)); ?><br>
                        <strong>Lokasi:</strong> <?php echo htmlspecialchars($filename); ?><br>
                        <strong>Tanggal:</strong> <?php echo date('d F Y H:i:s'); ?>
                    </div>
                </div>
            <?php endif; ?>

            <div class="buttons">
                <a href="dashboard.php" class="btn btn-primary">
                    🏠 Kembali ke Dashboard
                </a>
                <a href="backup_transaksi.php?manual=1" class="btn btn-success">
                    🔄 Backup Lagi
                </a>
                <a href="index.php" class="btn btn-secondary">
                    🏠 Kembali ke Home
                </a>
            </div>
        </div>
    </body>
    </html>
    <?php
} else {
    // CLI output (plain text)
    if (strpos($message, 'Error') === 0) {
        echo $message;
    } else {
        echo $message . "\nFile: " . basename($filename) . "\nPath: " . $filename;
    }
}
} // End of if (__FILE__ === $_SERVER['SCRIPT_FILENAME'])
?>
