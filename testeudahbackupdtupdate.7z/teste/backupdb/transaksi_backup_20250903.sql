-- Backup transaksi table
-- Generated on: 2025-09-03 13:58:12
-- Total records: 0

-- Table structure for transaksi
CREATE TABLE IF NOT EXISTS `transaksi` (
  `id_transaksi` int(11) NOT NULL AUTO_INCREMENT,
  `tanggal` date NOT NULL,
  `no_kwitansi` varchar(50) DEFAULT NULL,
  `uraian` text,
  `jumlah` decimal(15,2) NOT NULL,
  `setoran` decimal(15,2) DEFAULT NULL,
  `id_jurnal` int(11) DEFAULT NULL,
  `id_subkategori` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_transaksi`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Disable foreign key checks
SET FOREIGN_KEY_CHECKS = 0;

-- Clear existing data
DELETE FROM `transaksi`;


-- Enable foreign key checks
SET FOREIGN_KEY_CHECKS = 1;
