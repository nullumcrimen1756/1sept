<?php
require_once 'config.php';

echo "Checking database tables...\n";

$result = $conn->query("SHOW TABLES");
if ($result) {
    $tables = $result->fetch_all();
    echo "Tables found:\n";
    foreach ($tables as $table) {
        echo "- " . $table[0] . "\n";
        
        // Show table structure
        $desc_result = $conn->query("DESCRIBE " . $table[0]);
        if ($desc_result) {
            $columns = $desc_result->fetch_all(MYSQLI_ASSOC);
            foreach ($columns as $column) {
                echo "  - " . $column['Field'] . " (" . $column['Type'] . ")\n";
            }
        }
        echo "\n";
    }
} else {
    echo "Error: " . $conn->error . "\n";
}

$conn->close();
?>
