<?php
require_once 'config.php';

echo "Executing SQL script to create login_logs table...\n";

$sql = file_get_contents('sql_create_login_logs.sql');

if ($conn->multi_query($sql)) {
    echo "SQL script executed successfully!\n";
    
    // Check if table was created
    $result = $conn->query("SHOW TABLES LIKE 'login_logs'");
    if ($result->num_rows > 0) {
        echo "login_logs table created successfully!\n";
        
        // Show table structure
        $result = $conn->query("DESCRIBE login_logs");
        echo "\nTable structure:\n";
        while ($row = $result->fetch_assoc()) {
            echo "{$row['Field']} - {$row['Type']}\n";
        }
    } else {
        echo "Error: login_logs table was not created.\n";
    }
} else {
    echo "Error executing SQL: " . $conn->error . "\n";
}

$conn->close();
?>
