<?php
require_once 'config.php';

// Check if login_logs table exists
$table_check = $conn->query("SHOW TABLES LIKE 'login_logs'");
if (!$table_check || $table_check->num_rows == 0) {
    echo "✗ login_logs table does not exist. Please run create_login_logs_table.php first.\n";
    exit;
}

// Get current table structure
$result = $conn->query("DESCRIBE login_logs");
$current_columns = [];
while ($row = $result->fetch_assoc()) {
    $current_columns[] = $row['Field'];
}

echo "Current table structure:\n";
foreach ($current_columns as $col) {
    echo "- $col\n";
}
echo "\n";

// Columns to add if missing
$columns_to_add = [
    'browser_version' => "VARCHAR(50) DEFAULT NULL",
    'device_model' => "VARCHAR(100) DEFAULT NULL",
    'platform' => "VARCHAR(50) DEFAULT NULL",
    'is_active' => "BOOLEAN DEFAULT true",
    'created_at' => "TIMESTAMP DEFAULT CURRENT_TIMESTAMP",
    'updated_at' => "TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP"
];

// Add missing columns
$added_columns = [];
foreach ($columns_to_add as $column => $definition) {
    if (!in_array($column, $current_columns)) {
        $sql = "ALTER TABLE login_logs ADD COLUMN $column $definition";
        if ($conn->query($sql)) {
            echo "✓ Added column: $column\n";
            $added_columns[] = $column;
        } else {
            echo "✗ Failed to add column $column: " . $conn->error . "\n";
        }
    } else {
        echo "✓ Column $column already exists\n";
    }
}

// Add indexes if missing
$indexes_to_add = [
    'idx_username' => "INDEX idx_username (username)",
    'idx_fingerprint' => "INDEX idx_fingerprint (fingerprint)",
    'idx_waktu_login' => "INDEX idx_waktu_login (waktu_login)"
];

echo "\nChecking indexes...\n";
$result = $conn->query("SHOW INDEX FROM login_logs");
$current_indexes = [];
while ($row = $result->fetch_assoc()) {
    $current_indexes[] = $row['Key_name'];
}

foreach ($indexes_to_add as $index_name => $index_def) {
    if (!in_array($index_name, $current_indexes)) {
        $sql = "ALTER TABLE login_logs ADD $index_def";
        if ($conn->query($sql)) {
            echo "✓ Added index: $index_name\n";
        } else {
            echo "✗ Failed to add index $index_name: " . $conn->error . "\n";
        }
    } else {
        echo "✓ Index $index_name already exists\n";
    }
}

if (!empty($added_columns)) {
    echo "\n✓ Table updated successfully! Added columns: " . implode(', ', $added_columns) . "\n";
    echo "You can now try logging in again.\n";
} else {
    echo "\n✓ Table is already up to date.\n";
}

$conn->close();
?>
