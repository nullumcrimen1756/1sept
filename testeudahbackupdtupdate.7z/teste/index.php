<?php
require_once 'config.php';
require_once 'functions.php';
require_once 'includes/url_helper.php';

session_start();

// Jika belum login, redirect ke halaman login
if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
    header("Location: login.php");
    exit;
}

// Set judul halaman default
$page_title = "Dashboard - Sistem Keuangan Gereja";

$action = isset($_POST['action']) ? $_POST['action'] : (isset($_GET['action']) ? $_GET['action'] : 'form');

switch ($action) {
    case 'form':
        showForm();
        break;
    case 'submit':
        submitForm();
        break;
    case 'delete_sheet1_transactions':
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $ids = isset($_POST['selected_ids']) ? $_POST['selected_ids'] : [];
            $jurnal_filter = isset($_POST['jurnal_filter']) ? $_POST['jurnal_filter'] : '';
            $tahun_filter = isset($_POST['tahun_filter']) ? $_POST['tahun_filter'] : date('Y');
            $search = isset($_POST['search']) ? $_POST['search'] : '';

            $result = deleteSheet1Transactions($ids);

            // Set flash message
            if ($result['success']) {
                $_SESSION['success'] = $result['message'];
            } else {
                $_SESSION['errors'] = [$result['message']];
            }

            // Redirect back to sheet1_report with same filters
            $redirect_url = "index.php?action=sheet1_report";
            if ($jurnal_filter) $redirect_url .= "&jurnal_filter=" . urlencode($jurnal_filter);
            if ($tahun_filter) $redirect_url .= "&tahun_filter=" . urlencode($tahun_filter);
            if ($search) $redirect_url .= "&search=" . urlencode($search);

            header("Location: $redirect_url");
            exit;
        }
        break;

    case 'sheet1_report':
        $jurnal_filter = isset($_GET['jurnal_filter']) ? $_GET['jurnal_filter'] : null;
        $tahun_filter = isset($_GET['tahun_filter']) ? $_GET['tahun_filter'] : date('Y');
        generateSheet1Report($jurnal_filter, $tahun_filter);
        include 'views/sheet1_report.php';
        break;
    case 'sheet2_report':
        $jurnal_filter = isset($_GET['jurnal_filter']) ? $_GET['jurnal_filter'] : null;
        $tahun_filter = isset($_GET['tahun_filter']) ? $_GET['tahun_filter'] : date('Y');
        generateSheet2Report($jurnal_filter, $tahun_filter);
        include 'views/sheet2_report.php';
        break;
    case 'sheet3_report':
        $jurnal_filter = isset($_GET['jurnal_filter']) ? $_GET['jurnal_filter'] : null;
        $tahun_filter = isset($_GET['tahun_filter']) ? $_GET['tahun_filter'] : date('Y');
        generateSheet3Report($jurnal_filter, $tahun_filter);
        include 'views/sheet3_report.php';
        break;
    case 'laporan_keuangan':
        $tahun = isset($_GET['tahun']) ? intval($_GET['tahun']) : date('Y');
        $jurnal_filter = isset($_GET['jurnal_filter']) && $_GET['jurnal_filter'] !== '' ? intval($_GET['jurnal_filter']) : null;
        $report_data = generateLaporanKeuangan($tahun, $jurnal_filter);
        $page_title = "Laporan Keuangan Saluran GKPI Medan Kota - Tahun $tahun";
        include 'views/laporan_keuangan.php';
        break;
    case 'get_kategori':
        getKategoriByJurnal();
        break;
    case 'get_subkategori':
        getSubkategori();
        break;
    case 'dashboard':
        // Redirect to dashboard.php directly to show backup button
        header("Location: dashboard.php");
        exit;
        break;
    case 'login_sessions':
        // Include login sessions view
        include 'views/login_sessions.php';
        break;
    default:
        showDashboard();
}

// Include header
include 'views/header.php';

// ... existing content ...

// Include footer
include 'views/footer.php';
?>