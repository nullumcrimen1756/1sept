<?php
session_start();
require_once 'lib/dompdf/autoload.inc.php';
use Dompdf\Dompdf;

if (!isset($_SESSION['sheet1_report']) || empty($_SESSION['sheet1_report'])) {
    die("Tidak ada data laporan untuk diexport.");
}

$transactions = $_SESSION['sheet1_report'];
require_once 'config.php';

// Ambil parameter filter yang sama dengan laporan
$selected_jurnal_filter = isset($_GET['jurnal_filter']) ? $_GET['jurnal_filter'] : '';

// Daftar jurnal yang menggunakan "Uang dari Bank" bukan "Setoran"
$jurnal_uang_dari_bank = [2, 3, 4, 5]; // ID jurnal: Penerimaan Jemaat, Penerimaan Saldo Bank, Penerimaan GSG, Jurnal Penerimaan Jemaat Saldo Bank Mandiri
$label_setoran = in_array($selected_jurnal_filter, $jurnal_uang_dari_bank) ? "Uang dari Bank" : "Setoran";

function formatRupiahExport($number) {
    return number_format($number, 0, '', '');
}

$total_kas = 0;
$total_setoran = 0;
$unique_kategori = [];

foreach ($transactions as $trans) {
    $kas = (float)$trans['jumlah'];
    $setoran = 0;

    if (empty($trans['kode_subkategori']) && $kas > 0) {
        $setoran = $kas;
        $kas = 0;
    } elseif (!empty($trans['uraian']) && stripos($trans['uraian'], 'Uang Setoran') !== false) {
        $setoran = $kas;
        $kas = 0;
    }

    $total_kas += $kas;
    $total_setoran += $setoran;

    if (!empty($trans['kode_kategori'])) {
        $kode_kelompok = substr($trans['kode_kategori'], 0, 3);
        if (!in_array($kode_kelompok, $unique_kategori)) {
            $unique_kategori[] = $kode_kelompok;
        }
    }
}

sort($unique_kategori);

ob_start();
?>
<html>
<head>
    <meta charset="UTF-8">
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 10px;
            font-size: 8pt;
            line-height: 1.2;
        }
        .header { text-align: center; margin-bottom: 15px; }
        .title { font-size: 14pt; font-weight: bold; color: #1F4E78; margin-bottom: 3px; }
        .subtitle { font-size: 10pt; color: #2F75B5; margin-bottom: 8px; }
        .info-table { width: 100%; border-collapse: collapse; margin-bottom: 10px; font-size: 8pt; }
        .info-table td { padding: 3px; border: 1px solid #BFBFBF; }
        .info-label { font-weight: bold; background-color: #E6E6E6; width: 100px; }
        .data-table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 8px;
            font-size: 7pt;
            table-layout: fixed;
        }
        .data-table th {
            background-color: #4472C4;
            color: white;
            font-weight: bold;
            padding: 4px 2px;
            border: 1px solid #5B5B5B;
            text-align: center;
            font-size: 7pt;
            word-wrap: break-word;
        }
        .data-table td {
            padding: 3px 2px;
            border: 1px solid #BFBFBF;
            vertical-align: top;
            font-size: 7pt;
            word-wrap: break-word;
            overflow: hidden;
        }
        .data-table th:nth-child(1) { width: 60px; } /* Tanggal */
        .data-table th:nth-child(2) { width: 70px; } /* No. Kwitansi */
        .data-table th:nth-child(3) { width: 120px; } /* Uraian */
        .data-table th:nth-child(4) { width: 80px; } /* Jurnal */
        .data-table th:nth-child(5) { width: 80px; } /* Kategori */
        .data-table th:nth-child(6) { width: 80px; } /* Subkategori */
        .data-table th:nth-child(7) { width: 60px; } /* Kas */
        .data-table td:nth-child(1) { width: 60px; }
        .data-table td:nth-child(2) { width: 70px; }
        .data-table td:nth-child(3) { width: 120px; max-width: 120px; }
        .data-table td:nth-child(4) { width: 80px; }
        .data-table td:nth-child(5) { width: 80px; }
        .data-table td:nth-child(6) { width: 80px; }
        .data-table td:nth-child(7) { width: 60px; text-align: right; }
        .total-row { font-weight: bold; background-color: #D9E1F2; }
        .text-right { text-align: right; }
        .text-center { text-align: center; }
        .number-format { text-align: right; }
        .footer { margin-top: 15px; font-style: italic; color: #7F7F7F; text-align: right; font-size: 7pt; }
        .page-break { page-break-before: always; }
        @page { margin: 0.5in; }
    </style>
</head>
<body>
    <div class="header">
        <div class="title">LAPORAN DATA TRANSAKSI</div>
        <div class="subtitle">SHEET 1 - DETAIL TRANSAKSI</div>
    </div>

    <table class="info-table">
        <tr>
            <td class="info-label">Total Transaksi:</td>
            <td><?= count($transactions) ?> transaksi</td>
        </tr>
        <tr>
            <td class="info-label">Tanggal Export:</td>
            <td><?= date('d-m-Y H:i:s') ?></td>
        </tr>
    </table>

    <?php if (!empty($transactions)): ?>
    <div style="overflow-x:auto;">
    <table class="data-table">
        <thead>
            <tr>
                <th>Tanggal</th>
                <th>No. Kwitansi</th>
                <th>Uraian</th>
                <th>Jurnal</th>
                <th>Kategori</th>
                <th>Subkategori</th>
                <th>Kas</th>
                <?php foreach ($unique_kategori as $kode_kelompok): ?>
                    <th>Kode <?= $kode_kelompok ?></th>
                    <th>Nominal <?= $kode_kelompok ?></th>
                <?php endforeach; ?>
                <th><?= $label_setoran ?></th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($transactions as $trans): ?>
                <?php
                $kas = (float)$trans['jumlah'];
                $setoran = 0;

                if (empty($trans['kode_subkategori']) && $kas > 0) {
                    $setoran = $kas;
                    $kas = 0;
                } elseif (!empty($trans['uraian']) && stripos($trans['uraian'], 'Uang Setoran') !== false) {
                    $setoran = $kas;
                    $kas = 0;
                }
                ?>
                <tr>
                    <td class="text-center date-format"><?= date('d-m-Y', strtotime($trans['tanggal'])) ?></td>
                    <td class="text-center"><?= htmlspecialchars($trans['no_kwitansi']) ?></td>
                    <td><?= htmlspecialchars($trans['uraian']) ?></td>
                    <td><?= htmlspecialchars($trans['nama_jurnal']) ?></td>
                    <td><?= htmlspecialchars($trans['nama_kategori'] ?? 'N/A') ?></td>
                    <td><?= htmlspecialchars($trans['nama_subkategori'] ?? 'N/A') ?></td>
                    <td class="text-right number-format"><?= $kas > 0 ? formatRupiahExport($kas) : '' ?></td>
                    <?php 
                    $kategori_values = [];
                    foreach ($unique_kategori as $kode_kelompok) {
                        $kategori_values[$kode_kelompok] = [
                            'kode' => '',
                            'nominal' => ''
                        ];
                    }

                    if (!empty($trans['kode_kategori'])) {
                        $kode_kelompok = substr($trans['kode_kategori'], 0, 3);
                        if (in_array($kode_kelompok, $unique_kategori)) {
                            $kategori_values[$kode_kelompok] = [
                                'kode' => $trans['kode_subkategori'] ?? '',
                                'nominal' => $kas
                            ];
                        }
                    }

                    foreach ($unique_kategori as $kode_kelompok): 
                    ?>
                        <td class="text-center"><?= htmlspecialchars($kategori_values[$kode_kelompok]['kode']) ?></td>
                        <td class="text-right number-format"><?= $kategori_values[$kode_kelompok]['nominal'] ? formatRupiahExport($kategori_values[$kode_kelompok]['nominal']) : '' ?></td>
                    <?php endforeach; ?>
                    <td class="text-right number-format"><?= $setoran ? formatRupiahExport($setoran) : '' ?></td>
                </tr>
            <?php endforeach; ?>
        </tbody>
        <tfoot class="total-row">
            <tr>
                <td colspan="6" class="text-center"><strong>TOTAL</strong></td>
                <td class="text-right number-format"><strong><?= formatRupiahExport($total_kas) ?></strong></td>
                <?php foreach ($unique_kategori as $kode_kelompok): ?>
                    <td></td>
                    <td></td>
                <?php endforeach; ?>
                <td class="text-right number-format"><strong><?= formatRupiahExport($total_setoran) ?></strong></td>
            </tr>
        </tfoot>
    </table>
    </div>
    <?php else: ?>
        <div style="color: #FF0000; font-weight: bold; font-style: italic; text-align: center; margin: 30px 0;">
            Tidak ada data yang cocok dengan filter yang dipilih.
        </div>
    <?php endif; ?>

    <div class="footer">
        Dokumen ini dihasilkan secara otomatis pada <?= date('d F Y H:i:s') ?> dari Sistem Laporan Keuangan
    </div>
</body>
</html>
<?php
$html = ob_get_clean();

$dompdf = new Dompdf();
$dompdf->loadHtml($html);
$dompdf->setPaper('A4', 'landscape');

// Configure DomPDF for better table handling
$dompdf->set_option('isHtml5ParserEnabled', true);
$dompdf->set_option('isRemoteEnabled', false);
$dompdf->set_option('defaultFont', 'Arial');
$dompdf->set_option('dpi', 96);
$dompdf->set_option('fontHeightRatio', 1.0);

$dompdf->render();
$dompdf->stream("Laporan_Sheet1_" . date('Ymd_His') . ".pdf", ["Attachment" => false]);
exit;
?>
