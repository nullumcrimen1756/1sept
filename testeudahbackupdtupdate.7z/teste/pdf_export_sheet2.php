<?php
session_start();
require_once 'lib/dompdf/autoload.inc.php';
use Dompdf\Dompdf;

if (!isset($_SESSION['sheet2_report']) || empty($_SESSION['sheet2_report'])) {
    die("Tidak ada data laporan untuk diexport.");
}

$report = $_SESSION['sheet2_report'];
require_once 'config.php';

$selected_jurnal_filter = isset($_GET['jurnal_filter']) ? $_GET['jurnal_filter'] : '';
$selected_tahun_filter = isset($_GET['tahun_filter']) ? $_GET['tahun_filter'] : date('Y');
$search_keyword = isset($_GET['search']) ? trim($_GET['search']) : '';

if ($selected_jurnal_filter && isset($daftar_jurnal[$selected_jurnal_filter])) {
    $selected_jurnal_name = $daftar_jurnal[$selected_jurnal_filter];
    if (isset($report[$selected_jurnal_name])) {
        $report = [$selected_jurnal_name => $report[$selected_jurnal_name]];
    } else {
        $report = [];
    }
}

if (!empty($search_keyword)) {
    $filtered_report = [];
    foreach ($report as $jurnal => $bulan_data) {
        $filtered_bulan_data = [];
        foreach ($bulan_data as $bulan => $level1_data) {
            $filtered_level1_data = [];
            foreach ($level1_data as $level1 => $data) {
                $filtered_subcategories = [];
                $level1_total = 0;

                foreach ($data['subcategories'] as $level2 => $sub_data) {
                    $filtered_transactions = [];
                    foreach ($sub_data['transactions'] as $trans) {
                        if (stripos($trans['no_kwitansi'], $search_keyword) !== false ||
                            stripos($trans['uraian'], $search_keyword) !== false) {
                            $filtered_transactions[] = $trans;
                        }
                    }
                    if (!empty($filtered_transactions)) {
                        $sub_total = array_sum(array_column($filtered_transactions, 'jumlah'));
                        $filtered_subcategories[$level2] = [
                            'transactions' => $filtered_transactions,
                            'total' => $sub_total
                        ];
                        $level1_total += $sub_total;
                    }
                }

                if (!empty($filtered_subcategories)) {
                    $filtered_level1_data[$level1] = [
                        'kategori' => $data['kategori'] ?? 'Tidak ada kategori',
                        'subcategories' => $filtered_subcategories,
                        'total' => $level1_total
                    ];
                }
            }
            if (!empty($filtered_level1_data)) {
                $filtered_bulan_data[$bulan] = $filtered_level1_data;
            }
        }
        if (!empty($filtered_bulan_data)) {
            $filtered_report[$jurnal] = $filtered_bulan_data;
        }
    }
    $report = $filtered_report;
}

function formatRupiahExport($number) {
    return number_format($number, 0, ',', '');
}

ob_start();
?>
<html>
<head>
    <meta charset="UTF-8">
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 8px;
            font-size: 7pt;
            line-height: 1.1;
        }
        .header { text-align: center; margin-bottom: 10px; }
        .title { font-size: 12pt; font-weight: bold; color: #1F4E78; margin-bottom: 2px; }
        .subtitle { font-size: 9pt; color: #2F75B5; margin-bottom: 8px; }
        .data-table {
            border-collapse: collapse;
            margin-bottom: 10px;
            font-size: 6pt;
            width: 100%;
            table-layout: auto;
        }
        .data-table th {
            background-color: #2c3e50;
            color: white;
            font-weight: bold;
            padding: 3px 2px;
            border: 1px solid #000;
            text-align: center;
            font-size: 6pt;
            word-wrap: break-word;
            min-width: 35px;
            max-width: 50px;
        }
        .data-table td {
            padding: 2px 1px;
            border: 1px solid #BFBFBF;
            text-align: left;
            vertical-align: top;
            font-size: 6pt;
            word-wrap: break-word;
            overflow: hidden;
        }
        .data-table th:first-child { min-width: 80px; max-width: 120px; }
        .data-table td:first-child { min-width: 80px; max-width: 120px; }
        .number-cell { text-align: right; font-size: 6pt; }
        .date-cell { text-align: center; font-size: 6pt; }
        .jurnal-header {
            font-size: 10pt;
            font-weight: bold;
            color: #2F75B5;
            margin: 15px 0 8px 0;
            padding-bottom: 3px;
            border-bottom: 1px solid #2F75B5;
            page-break-after: avoid;
        }
        .subkategori-header {
            font-size: 8pt;
            font-weight: bold;
            color: #823535;
            background-color: #FCE4D6;
            padding: 2px;
            margin: 5px 0 3px 0;
        }
        .total-row { background-color: #d9e1f2; font-weight: bold; font-size: 6pt; }
        .footer {
            margin-top: 10px;
            font-style: italic;
            color: #666;
            text-align: right;
            font-size: 6pt;
        }
        .page-break { page-break-before: always; }
        @page { margin: 0.3in; }
        .month-header th { writing-mode: horizontal-tb; }
    </style>
</head>
<body>
    <div class="header">
        <div class="title">LAPORAN TERSTRUKTUR HORIZONTAL (SHEET 2)</div>
        <div class="subtitle">LAYOUT PER BULAN KE SAMPING - TAHUN <?= $selected_tahun_filter ?></div>
        <?php if ($selected_jurnal_filter && isset($daftar_jurnal[$selected_jurnal_filter])): ?>
            <p>Jurnal: <?= htmlspecialchars($daftar_jurnal[$selected_jurnal_filter]) ?></p>
        <?php endif; ?>
    </div>

    <?php if (!empty($report)): ?>
        <?php foreach ($report as $jurnal => $bulan_data): ?>
            <div class="jurnal-header">JURNAL: <?= htmlspecialchars($jurnal) ?></div>

            <?php
            $sorted_months = [];
            foreach ($bulan_data as $bulan => $subkategori_data) {
                $month_number = date('m', strtotime("1 $bulan"));
                $sorted_months[$month_number] = $bulan;
            }
            ksort($sorted_months);

            // Group months into pairs for better layout
            $month_groups = array_chunk($sorted_months, 2, true);
            $page_number = 1;

            foreach ($month_groups as $month_group):
                if ($page_number > 1): ?>
                    <div class="page-break"></div>
                <?php endif; ?>

                <table class="data-table" style="width: 100%; margin-bottom: 20px;">
                    <thead>
                        <tr>
                            <th style="writing-mode: horizontal-tb; min-width: 150px;">Kategori</th>
                            <th style="writing-mode: horizontal-tb; min-width: 150px;">Subkategori</th>
                            <?php foreach ($month_group as $month_number => $bulan): ?>
                                <th colspan="4" style="text-align: center;"><?= strtoupper($bulan) ?> <?= $selected_tahun_filter ?></th>
                            <?php endforeach; ?>
                        </tr>
                        <tr>
                            <th style="writing-mode: horizontal-tb;">Level 1</th>
                            <th style="writing-mode: horizontal-tb;">Level 2</th>
                            <?php foreach ($month_group as $month_number => $bulan): ?>
                                <th>Tanggal</th>
                                <th>No. Kwitansi</th>
                                <th>Uraian</th>
                                <th>Jumlah</th>
                            <?php endforeach; ?>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $row_counter = 0;
                        foreach ($bulan_data as $bulan => $level1_data) {
                            if (!in_array($bulan, $month_group)) continue;

                        foreach ($level1_data as $level1 => $level1_info) {
                            $level1_start_row = $row_counter;

                            // Calculate total rows needed for this level 1 category
                            $total_rows_for_level1 = 0;
                            foreach ($level1_info['subcategories'] as $level2_check => $level2_data_check) {
                                $trans_count = count($level2_data_check['transactions']);
                                // Header row + transaction rows + total row
                                $total_rows_for_level1 += 1 + max(1, $trans_count) + 1;
                            }
                            // Add one more for the level 1 total row
                            $total_rows_for_level1 += 1;

                            foreach ($level1_info['subcategories'] as $level2 => $level2_data) {
                                $max_transactions = count($level2_data['transactions']);

                                // Level 2 header row
                                echo '<tr class="subkategori-header">';
                                if ($row_counter == $level1_start_row) {
                                    echo '<td rowspan="' . $total_rows_for_level1 . '" style="vertical-align: top; font-weight: bold;">';
                                    echo '<strong>' . htmlspecialchars($level1) . '</strong><br>';
                                    echo '<small>(' . htmlspecialchars($level1_info['kategori'] ?? 'Tidak ada kategori') . ')</small>';
                                    echo '</td>';
                                }
                                echo '<td style="font-weight: bold; background-color: #FCE4D6;">' . htmlspecialchars($level2) . '</td>';

                                // Check if this level2 has transactions for each month
                                foreach ($month_group as $month_number => $current_bulan) {
                                    $has_data = isset($bulan_data[$current_bulan][$level1]['subcategories'][$level2]);
                                    if ($has_data) {
                                        $transaction_count = count($bulan_data[$current_bulan][$level1]['subcategories'][$level2]['transactions']);
                                        echo '<td colspan="4" style="text-align: center; font-weight: bold;">';
                                        echo $transaction_count > 0 ? $transaction_count . ' transaksi' : 'Tidak ada data';
                                        echo '</td>';
                                    } else {
                                        echo '<td colspan="4" style="text-align: center;">-</td>';
                                    }
                                }
                                echo '</tr>';

                                // Transaction rows
                                if ($max_transactions > 0) {
                                    for ($i = 0; $i < $max_transactions; $i++) {
                                        echo '<tr>';
                                        echo '<td style="background-color: #FCE4D6;">' . ($i == 0 ? 'Transaksi:' : '') . '</td>';

                                        // For each month, print transaction details in correct columns
                                        foreach ($month_group as $month_number => $current_bulan) {
                                            $trans = null;
                                            if (isset($bulan_data[$current_bulan][$level1]['subcategories'][$level2]['transactions'][$i])) {
                                                $trans = $bulan_data[$current_bulan][$level1]['subcategories'][$level2]['transactions'][$i];
                                            }

                                            // Print transaction details aligned with headers
                                            echo '<td class="date-cell">' . ($trans ? date('d/m', strtotime($trans['tanggal'])) : '') . '</td>';
                                            echo '<td>' . ($trans ? htmlspecialchars($trans['no_kwitansi']) : '') . '</td>';
                                            echo '<td>' . ($trans ? htmlspecialchars(substr($trans['uraian'], 0, 25)) : '') . '</td>';
                                            echo '<td class="number-cell">' . ($trans ? number_format($trans['jumlah'], 0, ',', '') : '') . '</td>';
                                        }
                                        echo '</tr>';
                                    }
                                } else {
                                    // If no transactions, still show an empty row
                                    echo '<tr>';
                                    echo '<td style="background-color: #FCE4D6;">Transaksi:</td>';
                                    foreach ($month_group as $month_number => $current_bulan) {
                                        echo '<td class="date-cell"></td>';
                                        echo '<td></td>';
                                        echo '<td></td>';
                                        echo '<td class="number-cell"></td>';
                                    }
                                    echo '</tr>';
                                }

                                // Total row for this level 2
                                echo '<tr class="total-row">';
                                echo '<td style="background-color: #FCE4D6; font-weight: bold;">Total ' . htmlspecialchars($level2) . ':</td>';

                                foreach ($month_group as $month_number => $current_bulan) {
                                    $sub_total = 0;
                                    if (isset($bulan_data[$current_bulan][$level1]['subcategories'][$level2]['total'])) {
                                        $sub_total = $bulan_data[$current_bulan][$level1]['subcategories'][$level2]['total'];
                                    }
                                    echo '<td colspan="3" style="text-align: right; font-weight: bold;">Total:</td>';
                                    echo '<td class="number-cell" style="font-weight: bold;">' . ($sub_total > 0 ? number_format($sub_total, 0, ',', '') : '') . '</td>';
                                }
                                echo '</tr>';

                                $row_counter++;
                            }

                                // Total row for this level 1
                                echo '<tr style="background-color: #d9e1f2; font-weight: bold; font-size: 7pt;">';
                                echo '<td colspan="2" style="text-align: right; font-weight: bold;">TOTAL ' . htmlspecialchars($level1) . ':</td>';

                                foreach ($month_group as $month_number => $current_bulan) {
                                    $level1_total = 0;
                                    if (isset($bulan_data[$current_bulan][$level1]['total'])) {
                                        $level1_total = $bulan_data[$current_bulan][$level1]['total'];
                                    }
                                    echo '<td colspan="3" style="text-align: right; font-weight: bold;">Total ' . htmlspecialchars($level1) . ':</td>';
                                    echo '<td class="number-cell" style="font-weight: bold;">' . ($level1_total > 0 ? number_format($level1_total, 0, ',', '') : '') . '</td>';
                                }
                                echo '</tr>';
                            }
                        }
                        ?>
                    </tbody>
                </table>

                <?php $page_number++; ?>
            <?php endforeach; ?>

        <?php endforeach; ?>
    <?php else: ?>
        <div style="color: #FF0000; font-weight: bold; text-align: center; margin: 30px 0;">
            Tidak ada data yang cocok dengan filter yang dipilih.
        </div>
    <?php endif; ?>

    <div style="margin-top: 20px; font-style: italic; color: #666; text-align: right;">
        Dokumen ini dihasilkan secara otomatis pada <?= date('d F Y H:i:s') ?> dari Sistem Laporan Keuangan
    </div>
</body>
</html>
<?php
$html = ob_get_clean();

$dompdf = new Dompdf();
$dompdf->loadHtml($html);
$dompdf->setPaper('A4', 'landscape');

// Configure DomPDF for better table handling
$dompdf->set_option('isHtml5ParserEnabled', true);
$dompdf->set_option('isRemoteEnabled', false);
$dompdf->set_option('defaultFont', 'Arial');
$dompdf->set_option('dpi', 96);
$dompdf->set_option('fontHeightRatio', 1.0);

$dompdf->render();
$dompdf->stream("Sheet2_Horizontal_" . date('Ymd_His') . ".pdf", ["Attachment" => false]);
exit;
?>
