<?php
session_start();

// Ambil parameter filter yang sama dengan laporan
$selected_jurnal_filter = isset($_GET['jurnal_filter']) ? $_GET['jurnal_filter'] : '';
$selected_tahun_filter = isset($_GET['tahun_filter']) ? $_GET['tahun_filter'] : date('Y');
$search_keyword = isset($_GET['search']) ? trim($_GET['search']) : '';
$selected_uraian_filter = isset($_GET['uraian_filter']) ? $_GET['uraian_filter'] : '';
$selected_kwitansi_filter = isset($_GET['kwitansi_filter']) ? $_GET['kwitansi_filter'] : '';

// Daftar jurnal yang menggunakan "Uang dari Bank" bukan "Setoran"
$jurnal_uang_dari_bank = [2, 3, 4, 5]; // ID jurnal: Penerimaan Jemaat, Penerimaan Saldo Bank, Penerimaan GSG, Jurnal Penerimaan Jemaat Saldo Bank Mandiri
$label_setoran = in_array($selected_jurnal_filter, $jurnal_uang_dari_bank) ? "Uang dari Bank" : "Setoran";

// Validasi session dan data
if (!isset($_SESSION['sheet1_report']) || empty($_SESSION['sheet1_report'])) {
    die("Tidak ada data laporan untuk diexport.");
}

$transactions = $_SESSION['sheet1_report'];
require_once 'config.php'; // Ambil $daftar_jurnal dari config.php

// Data sudah difilter oleh generateSheet1Report, jadi gunakan langsung
$filtered_transactions = $transactions;

// Set header untuk download file Excel
header("Content-Type: application/vnd.ms-excel");
header("Content-Disposition: attachment; filename=\"Laporan_Sheet1_" . date('Ymd_His') . ".xls\"");
header("Pragma: no-cache");
header("Expires: 0");

// Fungsi untuk format angka yang kompatibel dengan Excel
function formatRupiahExport($number) {
    // Gunakan format tanpa pemisah untuk memastikan Excel membaca sebagai angka
    return number_format($number, 0, '', ''); // Format: 250000 (tanpa pemisah, Excel friendly)
}

// Hitung total dan kategori unik
$total_kas = 0;
$total_setoran = 0;
$unique_kategori = [];

foreach ($filtered_transactions as $trans) {
    $kas = $trans['jumlah'] + ($trans['setoran'] ?? 0);
    $setoran = $trans['setoran'] ?? 0;

    $total_kas += $kas;
    $total_setoran += $setoran;

    // Kumpulkan kategori unik
    if (!empty($trans['kode_kategori'])) {
        $kode_kelompok = substr($trans['kode_kategori'], 0, 3);
        if (!in_array($kode_kelompok, $unique_kategori)) {
            $unique_kategori[] = $kode_kelompok;
        }
    }
}

sort($unique_kategori);
?>
<html>
<head>
    <meta charset="UTF-8">
    <style>
        body { font-family: Arial, sans-serif; margin: 0; padding: 20px; }
        .header { text-align: center; margin-bottom: 30px; }
        .title { font-size: 18pt; font-weight: bold; color: #1F4E78; margin-bottom: 5px; }
        .subtitle { font-size: 14pt; color: #2F75B5; margin-bottom: 15px; }
        .info-table { width: 100%; border-collapse: collapse; margin-bottom: 20px; }
        .info-table td { padding: 5px; border: 1px solid #BFBFBF; }
        .info-label { font-weight: bold; background-color: #E6E6E6; width: 120px; }
        .data-table { width: 100%; border-collapse: collapse; margin-bottom: 15px; }
        .data-table th { background-color: #4472C4; color: white; font-weight: bold; padding: 8px; border: 1px solid #5B5B5B; text-align: center; }
        .data-table td { padding: 6px; border: 1px solid #BFBFBF; vertical-align: top; }
        .total-row { font-weight: bold; background-color: #D9E1F2; }
        .text-right { text-align: right; }
        .text-center { text-align: center; }
        .number-format { mso-number-format: "#\\.##0"; }
        .date-format { mso-number-format: "dd-mm-yyyy"; }
        .footer { margin-top: 30px; font-style: italic; color: #7F7F7F; text-align: right; }
    </style>
</head>
<body>
    <div class="header">
        <div class="title">LAPORAN DATA TRANSAKSI</div>
        <div class="subtitle">SHEET 1 - DETAIL TRANSAKSI</div>
    </div>

    <table class="info-table">
        <?php if ($selected_jurnal_filter && isset($daftar_jurnal[$selected_jurnal_filter])): ?>
        <tr>
            <td class="info-label">Jurnal:</td>
            <td><?= htmlspecialchars($daftar_jurnal[$selected_jurnal_filter]) ?></td>
        </tr>
        <?php endif; ?>
        <?php if ($selected_tahun_filter): ?>
        <tr>
            <td class="info-label">Tahun:</td>
            <td><?= $selected_tahun_filter ?></td>
        </tr>
        <?php endif; ?>
        <?php if ($search_keyword): ?>
        <tr>
            <td class="info-label">Pencarian:</td>
            <td><?= htmlspecialchars($search_keyword) ?></td>
        </tr>
        <?php endif; ?>
        <?php if ($selected_uraian_filter): ?>
        <tr>
            <td class="info-label">Filter Uraian:</td>
            <td><?= htmlspecialchars($selected_uraian_filter) ?></td>
        </tr>
        <?php endif; ?>
        <?php if ($selected_kwitansi_filter): ?>
        <tr>
            <td class="info-label">Filter Kwitansi:</td>
            <td><?= htmlspecialchars($selected_kwitansi_filter) ?></td>
        </tr>
        <?php endif; ?>
        <tr>
            <td class="info-label">Total Transaksi:</td>
            <td><?= count($filtered_transactions) ?> transaksi</td>
        </tr>
        <tr>
            <td class="info-label">Tanggal Export:</td>
            <td><?= date('d-m-Y H:i:s') ?></td>
        </tr>
    </table>

    <?php if (!empty($filtered_transactions)): ?>
    <div style="overflow-x:auto;">
    <table class="data-table">
        <thead>
            <tr>
                <th>Tanggal</th>
                <th>No. Kwitansi</th>
                <th>Uraian</th>
                <th>Jurnal</th>
                <th>Kategori</th>
                <th>Subkategori</th>
                <th>Kas</th>
                <?php foreach ($unique_kategori as $kode_kelompok): ?>
                    <th>Kode <?= $kode_kelompok ?></th>
                    <th>Nominal <?= $kode_kelompok ?></th>
                <?php endforeach; ?>
                <th><?= $label_setoran ?></th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($filtered_transactions as $trans): ?>
                <?php
                $kas = $trans['jumlah'] + ($trans['setoran'] ?? 0);
                $setoran = $trans['setoran'] ?? 0;
                ?>
                <tr>
                    <td class="text-center date-format"><?= date('d-m-Y', strtotime($trans['tanggal'])) ?></td>
                    <td class="text-center"><?= htmlspecialchars($trans['no_kwitansi']) ?></td>
                    <td><?= htmlspecialchars($trans['uraian']) ?></td>
                    <td><?= htmlspecialchars($trans['nama_jurnal']) ?></td>
                    <td><?= htmlspecialchars($trans['nama_kategori'] ?? 'N/A') ?></td>
                    <td><?= htmlspecialchars($trans['nama_subkategori'] ?? 'N/A') ?></td>
                    <td class="text-right number-format"><?= $kas > 0 ? formatRupiahExport($kas) : '' ?></td>
                    <?php 
                    // Inisialisasi semua kolom kategori dengan nilai kosong
                    $kategori_values = [];
                    foreach ($unique_kategori as $kode_kelompok) {
                        $kategori_values[$kode_kelompok] = [
                            'kode' => '',
                            'nominal' => ''
                        ];
                    }
                    
                    // Isi nilai untuk kategori yang sesuai
                    if (!empty($trans['kode_kategori'])) {
                        $kode_kelompok = substr($trans['kode_kategori'], 0, 3);
                        if (in_array($kode_kelompok, $unique_kategori)) {
                            $kategori_values[$kode_kelompok] = [
                                'kode' => $trans['kode_subkategori'] ?? '',
                                'nominal' => $kas
                            ];
                        }
                    }
                    
                    // Tampilkan kolom untuk setiap kategori
                    foreach ($unique_kategori as $kode_kelompok): 
                    ?>
                        <td class="text-center"><?= htmlspecialchars($kategori_values[$kode_kelompok]['kode']) ?></td>
                        <td class="text-right number-format"><?= $kategori_values[$kode_kelompok]['nominal'] ? formatRupiahExport($kategori_values[$kode_kelompok]['nominal']) : '' ?></td>
                    <?php endforeach; ?>
                    <td class="text-right number-format"><?= $setoran ? formatRupiahExport($setoran) : '' ?></td>
                </tr>
            <?php endforeach; ?>
        </tbody>
        <tfoot class="total-row">
            <tr>
                <td colspan="6" class="text-center"><strong>TOTAL</strong></td>
                <td class="text-right number-format"><strong><?= formatRupiahExport($total_kas) ?></strong></td>
                <?php foreach ($unique_kategori as $kode_kelompok): ?>
                    <td></td>
                    <td></td>
                <?php endforeach; ?>
                <td class="text-right number-format"><strong><?= formatRupiahExport($total_setoran) ?></strong></td>
            </tr>
        </tfoot>
    </table>
    </div>
    <?php else: ?>
        <div style="color: #FF0000; font-weight: bold; font-style: italic; text-align: center; margin: 30px 0;">
            Tidak ada data yang cocok dengan filter yang dipilih.
        </div>
    <?php endif; ?>

    <div class="footer">
        Dokumen ini dihasilkan secara otomatis pada <?= date('d F Y H:i:s') ?> dari Sistem Laporan Keuangan
    </div>
</body>
</html>
