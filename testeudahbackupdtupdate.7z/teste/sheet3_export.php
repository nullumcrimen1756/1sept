<?php
session_start();

// Ambil parameter filter
$selected_jurnal_filter = isset($_GET['jurnal_filter']) ? $_GET['jurnal_filter'] : '';
$selected_tahun_filter = isset($_GET['tahun_filter']) ? $_GET['tahun_filter'] : date('Y');

// Validasi session
if (!isset($_SESSION['sheet3_report']) || empty($_SESSION['sheet3_report'])) {
    die("Tidak ada data laporan untuk diexport.");
}

$report = $_SESSION['sheet3_report'];
require_once 'config.php'; // Ambil $daftar_jurnal dari config.php
require_once 'includes/url_helper.php'; // Include URL helpers

// Set header untuk download file Excel
header("Content-Type: application/vnd.ms-excel");
header("Content-Disposition: attachment; filename=\"Laporan_Sheet3_Horizontal_" . date('Ymd_His') . ".xls\"");
header("Pragma: no-cache");
header("Expires: 0");

// Fungsi untuk format angka yang kompatibel dengan Excel
function formatRupiahExport($number) {
    // Gunakan format tanpa pemisah untuk memastikan Excel membaca sebagai angka
    return number_format($number, 0, '', ''); // Format: 250000 (tanpa pemisah, Excel friendly)
}

// Fungsi alternatif tanpa pemisah (untuk memastikan Excel membaca sebagai angka)
function formatNumberExcel($number) {
    return number_format($number, 0, '', ''); // Format: 250000 (no separator)
}


?>
<html>
<head>
    <meta charset="UTF-8">
    <style>
        body { font-family: Arial, sans-serif; margin: 20px; }
        .header { text-align: center; margin-bottom: 30px; }
        .title { font-size: 18pt; font-weight: bold; color: #1F4E78; }
        .subtitle { font-size: 14pt; color: #2F75B5; margin-bottom: 15px; }
        .data-table { width: 100%; border-collapse: collapse; margin-bottom: 20px; font-size: 11px; }
        .data-table th {
            background-color: #2c3e50;
            color: white;
            font-weight: bold;
            padding: 8px;
            border: 1px solid #000;
            text-align: center;
        }
        .data-table td {
            padding: 6px;
            border: 1px solid #BFBFBF;
            text-align: left;
        }
        .text-right { text-align: right; }
        .text-center { text-align: center; }
        .kelompok-total-row { background-color: #fff3cd; font-weight: bold; }
        .total-keseluruhan-row { background-color: #d1ecf1; font-weight: bold; }
        .footer { margin-top: 20px; font-style: italic; color: #666; text-align: right; }
        /* Format angka untuk Excel */
        .number-cell { mso-number-format: "#\\.##0"; text-align: right; }
        /* Add horizontal scroll for tables */
        .data-table-wrapper {
            overflow-x: auto;
            -webkit-overflow-scrolling: touch;
        }
    </style>
</head>
<body>
    <div class="header">
        <div class="title">LAPORAN HORIZONTAL (SHEET 3)</div>
        <div class="subtitle">SISTEM KEUANGAN GEREJA - TAHUN <?= $selected_tahun_filter ?></div>
        <?php if ($selected_jurnal_filter && isset($daftar_jurnal[$selected_jurnal_filter])): ?>
            <p>Jurnal: <?= htmlspecialchars($daftar_jurnal[$selected_jurnal_filter]) ?></p>
        <?php endif; ?>
    </div>

    <?php if (!empty($report['bulan']) && !empty($report['all_categories'])): ?>
        <div class="data-table-wrapper">
        <table class="data-table">
            <thead>
                <tr>
                    <th>Kategori</th>
                    <th>Kode Subkategori</th>
                    <th>Uraian</th>
                    <?php foreach ($report['bulan'] as $bulan): ?>
                        <th><?= htmlspecialchars($bulan) ?></th>
                    <?php endforeach; ?>
                    <th>Total</th>
                </tr>
            </thead>
            <tbody>
                <?php
                // Gunakan data yang sudah difilter dari session
                $filtered_categories = $report['all_categories'] ?? [];
                $filtered_sub_categories = $report['all_sub_categories'] ?? [];
                $filtered_total_kas = $report['total_kas'] ?? [];

                $current_group = '';
                $group_totals = array_fill_keys($report['bulan'], 0);
                $overall_totals = array_fill_keys($report['bulan'], 0);
                ?>
            
            <!-- Uang Setoran -->
            <?php if (!empty($report['uang_setoran'])): ?>
                <?php $totalUangSetoran = 0; ?>
                <tr>
                    <td><?= in_array($selected_jurnal_filter, [2,3,4,5]) ? "Uang dari Bank" : "Uang Setoran" ?></td>
                    <td></td>
                    <td></td>
                    <?php foreach ($report['bulan'] as $bulan):
                        $amount = isset($report['uang_setoran'][$bulan]) ? $report['uang_setoran'][$bulan] : 0;
                        $totalUangSetoran += $amount;
                        $overall_totals[$bulan] += $amount;
                    ?>
                        <td class="number-cell"><?= formatRupiahExport($amount) ?></td>
                    <?php endforeach; ?>
                    <td class="number-cell"><?= formatRupiahExport($totalUangSetoran) ?></td>
                </tr>
            <?php endif; ?>
            
            <!-- Kategori dan Subkategori -->
            <?php foreach ($filtered_categories as $kategori): ?>
                <?php
                $kelompok = substr($kategori, 0, 3);
                if ($kelompok !== $current_group && $current_group !== ''): ?>
                    <!-- Total Kelompok -->
                    <tr class="kelompok-total-row">
                        <td colspan="2">Total Kelompok <?= $current_group ?></td>
                        <td></td>
                        <?php
                        $group_total = 0;
                        foreach ($report['bulan'] as $bulan):
                            $amount = $group_totals[$bulan] ?? 0;
                            $group_total += $amount;
                        ?>
                            <td class="number-cell"><?= formatRupiahExport($amount) ?></td>
                        <?php endforeach; ?>
                        <td class="number-cell"><?= formatRupiahExport($group_total) ?></td>
                    </tr>
                    <?php $group_totals = array_fill_keys($report['bulan'], 0); ?>
                <?php endif; ?>
                
                <?php $current_group = $kelompok; ?>
                
                <!-- Subkategori -->
                <?php if (isset($filtered_sub_categories[$kategori])): ?>
                    <?php foreach ($filtered_sub_categories[$kategori] as $subkategori): ?>
                        <?php
                        $hasData = false;
                        foreach ($report['bulan'] as $bulan) {
                            $uniqueKey = $kategori . "|" . $subkategori . "|" . $bulan;
                            if (isset($filtered_total_kas[$uniqueKey]) && $filtered_total_kas[$uniqueKey] > 0) {
                                $hasData = true;
                                break;
                            }
                        }
                        if (!$hasData) continue;
                        ?>
                        
                        <tr>
                            <td><?= htmlspecialchars($kategori) ?></td>
                            <td><?= htmlspecialchars($subkategori) ?></td>
                            <td><?= isset($report['uraian_dict'][$subkategori]) ? htmlspecialchars($report['uraian_dict'][$subkategori]) : '' ?></td>
                            <?php 
                            $sub_total = 0;
                            foreach ($report['bulan'] as $bulan): 
                                $uniqueKey = $kategori . "|" . $subkategori . "|" . $bulan;
                                $amount = isset($filtered_total_kas[$uniqueKey]) ? $filtered_total_kas[$uniqueKey] : 0;
                                $sub_total += $amount;
                                $group_totals[$bulan] += $amount;
                                $overall_totals[$bulan] += $amount;
                            ?>
                                <td class="number-cell"><?= formatRupiahExport($amount) ?></td>
                            <?php endforeach; ?>
                            <td class="number-cell"><?= formatRupiahExport($sub_total) ?></td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            <?php endforeach; ?>
            
            <!-- Total Kelompok Terakhir -->
            <?php if ($current_group !== ''): ?>
                <tr class="kelompok-total-row">
                    <td colspan="2">Total Kelompok <?= $current_group ?></td>
                    <td></td>
                    <?php
                    $group_total = 0;
                    foreach ($report['bulan'] as $bulan):
                        $amount = $group_totals[$bulan] ?? 0;
                        $group_total += $amount;
                    ?>
                        <td class="number-cell"><?= formatRupiahExport($amount) ?></td>
                    <?php endforeach; ?>
                    <td class="number-cell"><?= formatRupiahExport($group_total) ?></td>
                </tr>
            <?php endif; ?>
            
                <!-- Total Keseluruhan -->
                <tr class="total-keseluruhan-row">
                    <td colspan="2">TOTAL KESELURUHAN</td>
                    <td></td>
                    <?php
                    $grand_total = 0;
                    foreach ($report['bulan'] as $bulan):
                        $amount = $overall_totals[$bulan] ?? 0;
                        $grand_total += $amount;
                    ?>
                        <td class="number-cell"><?= formatRupiahExport($amount) ?></td>
                    <?php endforeach; ?>
                    <td class="number-cell"><?= formatRupiahExport($grand_total) ?></td>
                </tr>
            </tbody>
        </table>
        </div>
    <?php else: ?>
        <div style="color: #FF0000; font-weight: bold; text-align: center; margin: 30px 0;">
            Tidak ada data yang cocok dengan filter yang dipilih.
        </div>
    <?php endif; ?>

    <div class="footer">
        Dokumen ini dihasilkan secara otomatis pada <?= date('d F Y H:i:s') ?> dari Sistem Laporan Keuangan
    </div>
</body>
</html>
