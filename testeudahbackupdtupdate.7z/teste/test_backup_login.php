<?php
/**
 * Test script for conditional backup on login functionality
 * This script tests the backup functions without requiring actual login
 */

require_once 'config.php';
require_once 'backup_transaksi.php';

echo "=== Testing Conditional Backup on Login ===\n\n";

// Test 1: Check if backup functions exist
echo "Test 1: Checking if backup functions exist...\n";
if (function_exists('getLatestBackupFile')) {
    echo "✓ getLatestBackupFile function exists\n";
} else {
    echo "✗ getLatestBackupFile function missing\n";
}

if (function_exists('hasNewDataSinceLastBackup')) {
    echo "✓ hasNewDataSinceLastBackup function exists\n";
} else {
    echo "✗ hasNewDataSinceLastBackup function missing\n";
}

if (function_exists('performConditionalBackup')) {
    echo "✓ performConditionalBackup function exists\n";
} else {
    echo "✗ performConditionalBackup function missing\n";
}

echo "\n";

// Test 2: Check latest backup file
echo "Test 2: Checking latest backup file...\n";
$backup_dir = __DIR__ . '/backupdb';
$latest_backup = getLatestBackupFile($backup_dir);

if ($latest_backup) {
    echo "✓ Latest backup file: $latest_backup\n";
    $date_str = substr($latest_backup, 17, 8);
    $last_backup_date = date('Y-m-d', strtotime($date_str));
    echo "✓ Last backup date: $last_backup_date\n";
} else {
    echo "✓ No previous backup files found (this is expected for first run)\n";
    $last_backup_date = null;
}

echo "\n";

// Test 3: Check if there is new data since last backup
echo "Test 3: Checking for new data since last backup...\n";
$has_new_data = hasNewDataSinceLastBackup($conn, $last_backup_date);

if ($has_new_data) {
    echo "✓ New data found since last backup\n";
} else {
    echo "✓ No new data since last backup\n";
}

// Test 3b: Check checksum file creation
$checksum_file = __DIR__ . '/backupdb/last_backup_checksum.txt';
if (file_exists($checksum_file)) {
    echo "✓ Checksum file created for data change detection\n";
    $checksum = trim(file_get_contents($checksum_file));
    echo "✓ Current checksum: " . substr($checksum, 0, 16) . "...\n";
} else {
    echo "✗ Checksum file not created\n";
}

echo "\n";

// Test 4: Test conditional backup
echo "Test 4: Testing conditional backup...\n";
$backup_result = performConditionalBackup($conn, $backup_dir);

if ($backup_result['skipped']) {
    echo "✓ Backup was skipped: " . $backup_result['message'] . "\n";
} elseif ($backup_result['success']) {
    echo "✓ Backup was successful: " . $backup_result['message'] . "\n";
    echo "✓ Backup file: " . $backup_result['filename'] . "\n";
    echo "✓ Backup path: " . $backup_result['filepath'] . "\n";
} else {
    echo "✗ Backup failed: " . $backup_result['message'] . "\n";
}

echo "\n";

// Test 5: Verify backup file was created (if backup was performed)
if (isset($backup_result) && $backup_result['success'] && !$backup_result['skipped']) {
    echo "Test 5: Verifying backup file creation...\n";
    $backup_file_path = $backup_result['filepath'];

    if (file_exists($backup_file_path)) {
        echo "✓ Backup file exists: $backup_file_path\n";
        $file_size = filesize($backup_file_path);
        echo "✓ File size: " . number_format($file_size) . " bytes\n";

        // Check if file contains expected content
        $content = file_get_contents($backup_file_path);
        if (strpos($content, '-- Backup transaksi table') !== false) {
            echo "✓ File contains expected SQL backup content\n";
        } else {
            echo "✗ File does not contain expected SQL backup content\n";
        }
    } else {
        echo "✗ Backup file was not created\n";
    }
} else {
    echo "Test 5: Skipped (backup was not performed)\n";
}

echo "\n";

// Test 6: Check database connection and transaksi table
echo "Test 6: Checking database and transaksi table...\n";
$result = $conn->query("SELECT COUNT(*) as total FROM transaksi");
if ($result) {
    $row = $result->fetch_assoc();
    $total_records = $row['total'];
    echo "✓ Transaksi table exists with $total_records records\n";
} else {
    echo "✗ Error accessing transaksi table: " . $conn->error . "\n";
}

echo "\n=== Test Summary ===\n";
echo "All basic functionality tests completed.\n";
echo "For full testing, you should:\n";
echo "1. Login to the system to trigger the backup\n";
echo "2. Check PHP error logs for backup messages\n";
echo "3. Verify backup files are created only when new data exists\n";
echo "4. Test with different scenarios (new data vs no new data)\n";

echo "\nTest completed at: " . date('Y-m-d H:i:s') . "\n";
?>
