<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once 'config.php';

echo "<h2>Database Connection Test</h2>";
echo "Database: " . DB_NAME . "<br>";
echo "Connection: " . ($conn->connect_error ? "FAILED: " . $conn->connect_error : "SUCCESS") . "<br>";
echo "Host Info: " . $conn->host_info . "<br>";

// Test query
$result = $conn->query("SELECT 1");
echo "Query Test: " . ($result ? "SUCCESS" : "FAILED: " . $conn->error) . "<br>";

// Check if login_logs table exists
$table_check = $conn->query("SHOW TABLES LIKE 'login_logs'");
echo "Login logs table exists: " . ($table_check && $table_check->num_rows > 0 ? "YES" : "NO") . "<br>";

if ($table_check && $table_check->num_rows > 0) {
    echo "Table structure:<br>";
    $columns = $conn->query("DESCRIBE login_logs");
    while ($col = $columns->fetch_assoc()) {
        echo "- {$col['Field']} ({$col['Type']})<br>";
    }
} else {
    echo "Creating login_logs table...<br>";
    $sql = "CREATE TABLE IF NOT EXISTS login_logs (
        id INT AUTO_INCREMENT PRIMARY KEY,
        username VARCHAR(255) NOT NULL,
        waktu_login DATETIME NOT NULL,
        ip_address VARCHAR(45) NOT NULL,
        fingerprint VARCHAR(255) NOT NULL,
        browser VARCHAR(100) DEFAULT NULL,
        operating_system VARCHAR(100) DEFAULT NULL,
        device_type VARCHAR(50) DEFAULT NULL,
        user_agent TEXT DEFAULT NULL
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";
    
    if ($conn->query($sql)) {
        echo "SUCCESS: Table created<br>";
    } else {
        echo "ERROR: " . $conn->error . "<br>";
    }
}
?>
