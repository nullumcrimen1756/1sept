<?php
require_once 'config.php';
require_once 'functions.php';

echo "<h1>Testing Login Session Functionality</h1>";

// Test database connection
if ($conn) {
    echo "<p>✓ Database connection successful</p>";
} else {
    echo "<p>✗ Database connection failed</p>";
    exit;
}

// Test table existence
$result = $conn->query("SHOW TABLES LIKE 'login_logs'");
if ($result && $result->num_rows > 0) {
    echo "<p>✓ login_logs table exists</p>";
} else {
    echo "<p>✗ login_logs table does not exist</p>";
}

// Test saveLoginLog function
echo "<h2>Testing saveLoginLog function</h2>";
$test_username = "test_user_" . time();
echo "<p>Testing with username: $test_username</p>";
$result = saveLoginLog($test_username);

if ($result) {
    echo "<p>✓ saveLoginLog function executed successfully</p>";
} else {
    echo "<p>✗ saveLoginLog function failed</p>";
}

// Check if record was inserted
$result = $conn->query("SELECT COUNT(*) as total FROM login_logs WHERE username = '$test_username'");
if ($result) {
    $row = $result->fetch_assoc();
    echo "<p>Records in login_logs for $test_username: " . $row['total'] . "</p>";
}

// Show recent login logs
echo "<h2>Recent Login Logs</h2>";
$result = $conn->query("SELECT * FROM login_logs ORDER BY waktu_login DESC LIMIT 5");
if ($result && $result->num_rows > 0) {
    echo "<table border='1'>";
    echo "<tr><th>ID</th><th>Username</th><th>Time</th><th>IP</th><th>Browser</th><th>OS</th><th>Device</th></tr>";
    while ($row = $result->fetch_assoc()) {
        echo "<tr>";
        echo "<td>" . $row['id'] . "</td>";
        echo "<td>" . $row['username'] . "</td>";
        echo "<td>" . $row['waktu_login'] . "</td>";
        echo "<td>" . $row['ip_address'] . "</td>";
        echo "<td>" . $row['browser'] . "</td>";
        echo "<td>" . $row['operating_system'] . "</td>";
        echo "<td>" . $row['device_type'] . "</td>";
        echo "</tr>";
    }
    echo "</table>";
} else {
    echo "<p>No login logs found</p>";
}

echo "<h2>Table Structure</h2>";
$result = $conn->query("DESCRIBE login_logs");
if ($result) {
    echo "<table border='1'>";
    echo "<tr><th>Field</th><th>Type</th><th>Null</th><th>Key</th><th>Default</th><th>Extra</th></tr>";
    while ($row = $result->fetch_assoc()) {
        echo "<tr>";
        echo "<td>" . $row['Field'] . "</td>";
        echo "<td>" . $row['Type'] . "</td>";
        echo "<td>" . $row['Null'] . "</td>";
        echo "<td>" . $row['Key'] . "</td>";
        echo "<td>" . $row['Default'] . "</td>";
        echo "<td>" . $row['Extra'] . "</td>";
        echo "</tr>";
    }
    echo "</table>";
}

// Test device detection
echo "<h2>Device Detection Test</h2>";
$user_agent = $_SERVER['HTTP_USER_AGENT'] ?? '';
echo "<p>User Agent: " . htmlspecialchars($user_agent) . "</p>";
$device_info = detectDeviceInfo($user_agent);
echo "<pre>";
print_r($device_info);
echo "</pre>";
?>
