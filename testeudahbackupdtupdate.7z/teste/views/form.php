<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=1024, initial-scale=1.0, user-scalable=no">
    <title>Form Transaksi Gereja</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <style>
        :root {
            --primary-color: #2c3e50;
            --secondary-color: #3498db;
            --accent-color: #e74c3c;
            --light-bg: #f8f9fa;
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: var(--light-bg);
        }
        
        .card-form {
            border-radius: 10px;
            box-shadow: 0 4px 20px rgba(0,0,0,0.08);
            border: none;
        }
        
        .form-header {
            background-color: var(--primary-color);
            color: white;
            border-radius: 10px 10px 0 0 !important;
            padding: 15px 20px;
        }
        
        .form-label {
            font-weight: 600;
            color: var(--primary-color);
        }
        
        .form-control, .form-select {
            border-radius: 6px;
            padding: 10px 15px;
            border: 1px solid #ced4da;
            transition: all 0.3s;
        }
        
        .form-control:focus, .form-select:focus {
            border-color: var(--secondary-color);
            box-shadow: 0 0 0 0.25rem rgba(52, 152, 219, 0.25);
        }
        
        .btn-submit {
            background-color: var(--secondary-color) !important;
            color: white !important;
            border: none !important;
            padding: 10px 20px !important;
            font-weight: 600 !important;
            transition: all 0.3s !important;
            display: inline-block !important;
            visibility: visible !important;
            opacity: 1 !important;
        }
        
        .btn-submit:hover {
            background-color: #2980b9;
            transform: translateY(-2px);
        }
        
        .nav-pills .nav-link.active {
            background-color: var(--primary-color);
        }
        
        .nav-pills .nav-link {
            color: var(--primary-color);
        }
        
        .transaction-type {
            border-left: 4px solid var(--secondary-color);
            background-color: rgba(52, 152, 219, 0.1);
            padding: 12px;
            margin-bottom: 15px;
            border-radius: 0 6px 6px 0;
        }
        
        .amount-input {
            position: relative;
        }
        
        .amount-input span {
            position: absolute;
            left: 15px;
            top: 38px; /* Posisi yang lebih tepat */
            font-weight: 600;
            color: var(--primary-color);
            line-height: 1.5;
        }
        
        .amount-input input {
            padding-left: 40px !important;
        }
        
        .error-message {
            color: var(--accent-color);
            font-size: 0.9rem;
            margin-top: 5px;
        }

        .text-end {
            text-align: right !important;
        }
        
        /* Tambahan untuk form validation */
        .form-control:invalid {
            border-color: var(--accent-color);
            box-shadow: 0 0 0 0.25rem rgba(231, 76, 60, 0.25);
        }
        
        .form-control:valid {
            border-color: #28a745;
            border-width: 2px;
            box-shadow: 0 0 0 0.25rem rgba(40, 167, 69, 0.25);
        }
        
        .form-text {
            font-size: 0.875rem;
            color: #6c757d;
            line-height: 1.4;
        }
        
        .form-text i {
            color: var(--secondary-color);
        }
        
        .form-text strong {
            color: var(--primary-color);
        }
        
        .form-text .text-muted {
            color: #6c757d !important;
        }
        
        .form-text .text-success {
            color: #28a745 !important;
        }
        
        /* Styling untuk input yang sedang difokuskan */
        .form-control:focus {
            border-color: var(--secondary-color);
            box-shadow: 0 0 0 0.25rem rgba(52, 152, 219, 0.25);
        }
        
        /* Styling untuk placeholder */
        .form-control::placeholder {
            color: #adb5bd;
            font-style: italic;
        }

        /* Receipt Styles */
        .receipt-container {
            width: 100%;
            max-width: 550px;
            min-height: 350px;
            background: white;
            box-shadow: 0 0 15px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
            overflow: hidden;
            font-size: 10px;
            font-family: 'Arial', sans-serif;
            margin: 0 auto;
        }

        .editable-field {
            border: 1px dashed transparent;
            padding: 2px 4px;
            border-radius: 3px;
            transition: all 0.2s;
            min-height: 16px;
            display: inline-block;
            cursor: text;
        }

        .editable-field:hover {
            border-color: #007bff;
            background-color: rgba(0, 123, 255, 0.1);
        }

        .editable-field:focus {
            border-color: #007bff;
            background-color: rgba(0, 123, 255, 0.1);
            outline: none;
        }

        .editable-field[contenteditable="true"] {
            background-color: rgba(255, 255, 0, 0.1);
        }

        .receipt {
            background: #fff;
            border: 2px solid #d63384;
            border-radius: 6px;
            padding: 12px;
            position: relative;
            min-height: 320px;
        }

        .receipt-header {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            border-bottom: 2px solid #d63384;
            padding-bottom: 10px;
            margin-bottom: 15px;
        }

        /* Gaya untuk header gereja di kedua template */
        #income-receipt .church-info,
        #expense-receipt .church-info {
            text-align: center;
            font-family: 'Arial', sans-serif;
            margin-bottom: 10px;
        }

        #income-receipt .church-info p:nth-child(2),
        #expense-receipt .church-info h2 {
            font-weight: bold;
            font-size: 10px;
            color: #d63384;
            margin-bottom: 2px;
            line-height: 1.2;
        }

        #income-receipt .church-info p:nth-child(3),
        #expense-receipt .church-info p {
            font-size: 8px;
            margin-bottom: 2px;
            line-height: 1.1;
        }

        .receipt-details {
            text-align: right;
        }

        .receipt-number-large {
            position: absolute;
            top: 10px;
            right: 15px;
            font-weight: bold;
            color: #d63384;
            font-size: 10pt;
            background: white;
            padding: 2px 8px;
            border: 1px solid #d63384;
            border-radius: 3px;
        }

        .bank-info-section {
            margin-top: 10px;
        }

        .bank-info {
            display: flex;
            margin-bottom: 5px;
        }

        .bank-label {
            width: 80px;
            font-weight: bold;
            font-size: 10px;
        }

        .bank-value {
            flex: 1;
            font-size: 10px;
            min-height: 12px;
            padding: 1px 2px;
            border-radius: 2px;
            cursor: text;
        }

        .bank-value.editable-field {
            border: 1px dashed transparent;
            transition: all 0.2s;
        }

        .bank-value.editable-field:hover {
            border-color: #007bff;
            background-color: rgba(0, 123, 255, 0.1);
        }

        .bank-value.editable-field:focus {
            border-color: #007bff;
            background-color: rgba(0, 123, 255, 0.1);
            outline: none;
        }

        .receipt-title {
            text-align: center;
            font-weight: bold;
            font-size: 12pt;
            color: #d63384;
            margin-bottom: 10px;
            margin-top: 5px;
        }

        .form-title {
            text-align: center;
            font-weight: bold;
            font-size: 12pt;
            color: #d63384;
            margin-bottom: 10px;
            margin-top: 5px;
        }

        .payment-type {
            display: flex;
            gap: 10px;
            margin-top: 5px;
            font-size: 11px;
        }

        .payment-type div {
            display: flex;
            align-items: center;
            gap: 5px;
        }

        .box {
            width: 12px;
            height: 12px;
            border: 1px solid #333;
            display: inline-block;
        }

        .checked {
            background: #d63384;
            position: relative;
        }

        .checked:after {
            content: "✓";
            color: white;
            font-size: 8px;
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
        }

        .vertical-data {
            display: flex;
            flex-direction: column;
            gap: 0.0078125px;
            margin-bottom: 2px;
        }

        .data-row {
            display: flex;
            border-bottom: 1px solid #eee;
            padding-bottom: 0.015625px;
        }

        .data-label {
            width: 130px;
            font-weight: bold;
            color: #555;
            font-size: 11px;
        }

        .data-value {
            flex: 1;
            font-size: 11px;
            word-wrap: break-word;
            overflow-wrap: break-word;
        }

        .amount-section {
            display: flex;
            justify-content: space-between;
            border: 1px solid #ddd;
            margin-bottom: 10px;
            border-radius: 4px;
            overflow: hidden;
        }

        .payment-method {
            padding: 10px;
            width: 65%;
            border-right: 1px solid #ddd;
        }

        .payment-amount {
            padding: 10px;
            width: 35%;
            text-align: center;
        }

        .amount {
            font-size: 12pt;
            font-weight: bold;
            color: #d63384;
            margin-top: 5px;
        }

        .signature-section {
            border: 1px solid #ddd;
            border-radius: 4px;
            overflow: hidden;
        }

        .signature-table {
            width: 100%;
            border-collapse: collapse;
        }

        .signature-table td {
            padding: 8px;
            border: 1px solid #ddd;
            text-align: center;
            vertical-align: bottom;
        }

        .signature-label {
            font-weight: bold;
            background: #f9f9f9;
            width: 100px;
            font-size: 11px;
        }

        .signature-space {
            height: 50px;
            border-bottom: 1px dashed #999;
            margin-top: 5px;
            display: flex;
            align-items: flex-end;
            justify-content: center;
            padding-bottom: 3px;
        }

        .footer {
            margin-top: 8px;
            display: flex;
            justify-content: space-between;
            font-size: 10px;
            color: #777;
        }

        /* Print styles */
        @media print {
            .receipt-container {
                box-shadow: none;
                max-width: 100%;
                width: 100%;
                min-height: auto;
                font-size: 11px;
                margin: 0;
                float: none;
                page-break-inside: avoid;
            }

            .receipt {
                border: 1px solid #d63384;
                padding: 5px;
                min-height: auto;
                margin: 0;
            }

            .church-info h2 {
                font-size: 12px;
            }

            .receipt-number {
                font-size: 10px;
            }

            .amount {
                font-size: 12pt;
            }

            .signature-space {
                height: 35px;
            }

            .receipt-title {
                font-size: 12pt;
            }

            .form-title {
                font-size: 12pt;
            }
        }
    </style>
</head>
<body>
    <div class="container py-3">
        <div class="row justify-content-center">
            <div class="col-lg-8">
                <div class="card card-form">
                    <div class="card-header form-header">
                        <h4 class="mb-0"><i class="bi bi-journal-plus me-2"></i>Form Input Transaksi</h4>
                    </div>

                    <div class="card-body px-4 py-3">
                        <?php if (isset($_SESSION['success'])): ?>
                            <div class="alert alert-success alert-dismissible fade show">
                                <?php echo $_SESSION['success']; unset($_SESSION['success']); ?>
                                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                            </div>
                        <?php endif; ?>
                        
                        <?php if (isset($_SESSION['errors'])): ?>
                            <div class="alert alert-danger alert-dismissible fade show">
                                <h5 class="alert-heading">Terjadi Kesalahan!</h5>
                                <ul class="mb-0">
                                    <?php foreach ($_SESSION['errors'] as $error): ?>
                                        <li><?php echo $error; ?></li>
                                    <?php endforeach; ?>
                                </ul>
                                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                                <?php unset($_SESSION['errors']); ?>
                            </div>
                        <?php endif; ?>
                        
                        <ul class="nav nav-pills mb-4">
                            <li class="nav-item">
                                <a class="nav-link" href="index.php"><i class="bi bi-house-door me-1"></i> Beranda</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="index.php?action=sheet1_report"><i class="bi bi-table me-1"></i> Sheet 1 Report</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="index.php?action=sheet2_report"><i class="bi bi-list-check me-1"></i> Sheet 2 Report</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="index.php?action=sheet3_report"><i class="bi bi-graph-up me-1"></i> Sheet 3 Report</a>
                            </li>
                        </ul>
                        
                        <form action="index.php?action=submit" method="post" id="transaksiForm">
                            <div class="transaction-type">
                                <h5 class="fw-bold text-primary mb-3"><i class="bi bi-journal-text me-2"></i>Jenis Transaksi</h5>
                                <div class="row">
                                    <div class="col-md-6 mb-3">
                                        <label for="id_jurnal" class="form-label">Jurnal</label>
                                        <select id="id_jurnal" name="id_jurnal" class="form-select" required>
                                            <option value="" selected disabled>Pilih Jurnal</option>
                                            <?php foreach ($jurnal as $jur): ?>
                                                <option value="<?php echo $jur['id_jurnal']; ?>">
                                                    <?php echo $jur['nama_jurnal']; ?>
                                                </option>
                                            <?php endforeach; ?>
                                        </select>
                                    </div>
                                    <div class="col-md-6 mb-3">
                                        <label for="tanggal" class="form-label">Tanggal Transaksi</label>
                                        <input type="date" id="tanggal" name="tanggal" class="form-control"
                                               value="<?php echo date('Y-m-d'); ?>" required>
                                    </div>
                                </div>

                                <!-- Pilihan jenis input -->
                                <div class="mb-3">
                                    <label class="form-label fw-bold">Jenis Input:</label>
                                    <div class="form-check">
                                        <input class="form-check-input" type="radio" name="jenis_input" id="input_lengkap" value="lengkap" checked>
                                        <label class="form-check-label" for="input_lengkap">
                                            Input Lengkap (dengan Kategori & Subkategori)
                                        </label>
                                    </div>
                                    <div class="form-check">
                                        <input class="form-check-input" type="radio" name="jenis_input" id="input_setoran" value="setoran">
                                        <label class="form-check-label" for="input_setoran">
                                            Input Setoran/Uang dari Bank saja
                                        </label>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="mb-3">
                                <h5 class="fw-bold text-primary mb-3"><i class="bi bi-card-text me-2"></i>Detail Transaksi</h5>
                                <div class="row mb-3">
                                    <div class="col-md-6">
                                        <label for="no_kwitansi" class="form-label">Nomor Kwitansi</label>
                                        <input type="text" id="no_kwitansi" name="no_kwitansi" class="form-control"
                                               placeholder="Masukkan nomor kwitansi" required>
                                    </div>
                                    <div class="col-md-6">
                                        <label for="diterima_dari" class="form-label">Diterima Dari</label>
                                        <input type="text" id="diterima_dari" name="diterima_dari" class="form-control"
                                               placeholder="Nama penerima">
                                    </div>
                                </div>

                                <div class="row mb-3">
                                    <div class="col-md-12">
                                        <label for="uraian" class="form-label">Uraian/Keterangan</label>
                                        <textarea id="uraian" name="uraian" class="form-control" rows="4"
                                                  placeholder="Deskripsi transaksi" required></textarea>
                                    </div>
                                </div>

                                <div class="row" id="kategori-row">
                                    <div class="col-md-6 mb-3">
                                        <label for="id_kategori" class="form-label">Kategori</label>
                                        <select id="id_kategori" name="id_kategori" class="form-select" required disabled>
                                            <option value="" selected disabled>Pilih jurnal terlebih dahulu</option>
                                        </select>
                                    </div>
                                    <div class="col-md-6 mb-3">
                                        <label for="id_subkategori" class="form-label">Sub Kategori</label>
                                        <select id="id_subkategori" name="id_subkategori" class="form-select" required disabled>
                                            <option value="" selected disabled>Pilih kategori terlebih dahulu</option>
                                        </select>
                                    </div>
                                </div>

                                <div class="row" id="subkategori-row">
                                    <div class="col-md-6 mb-3 amount-input" id="jumlah-row">
                                        <label for="jumlah" class="form-label">Jumlah</label>
                                        <span>Rp</span>
                                        <input type="number" id="jumlah" name="jumlah" class="form-control"
                                               min="0" step="0.01" required>
                                    </div>
                                    <div class="col-md-6 mb-3 amount-input" id="setoran-row" style="display: none;">
                                        <label for="setoran" class="form-label" id="setoran-label">Setoran (Opsional)</label>
                                        <span>Rp</span>
                                        <input type="number" id="setoran" name="setoran" class="form-control"
                                               min="0" step="0.01" disabled>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="d-grid gap-2 d-md-flex justify-content-md-end">
                                <button type="reset" class="btn btn-outline-secondary me-md-2">
                                    <i class="bi bi-arrow-counterclockwise me-1"></i> Reset
                                </button>
                                <button type="submit" class="btn btn-primary btn-lg">
                                    <i class="bi bi-save me-1"></i> Simpan Transaksi
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

    <!-- Receipt Section -->
    <div class="container mt-5">
        <div class="row justify-content-center">
            <div class="col-lg-8">
                <div class="card">
                    <div class="card-header bg-info text-white">
                        <h5 class="mb-0"><i class="bi bi-receipt me-2"></i>Preview Bukti <span id="receipt-type-title">Penerimaan</span></h5>
                    </div>
                    <div class="card-body p-0">
                        <!-- Income Receipt Template -->
                        <div class="receipt-container" id="income-receipt" style="display: block;">
                            <div class="receipt">
                                <div class="receipt-title"></div>

                <div class="receipt-header">
                    <div class="church-info">
                        <p>BUKTI PENERIMAAN KAS</p>
                        <p>GEREJA KRISTEN PROTESTAN INDONESIA (GKPI)</p>
                        <p>Jemaat Medan Kota</p>
                    </div>
                    <div class="receipt-details">
                        <div class="receipt-number-large" id="receipt-number">No.KW: -</div>
                    </div>
                </div>

                                <div class="vertical-data">
                                    <div class="data-row">
                                        <div class="data-label">Diterima dari</div>
                                        <div class="data-value" id="received-from">-</div>
                                    </div>
                                    <div class="data-row">
                                        <div class="data-label">Jumlah Uang</div>
                                        <div class="data-value" id="amount-text">Rp 0,-</div>
                                    </div>
                                    <div class="data-row">
                                        <div class="data-label">Untuk</div>
                                        <div class="data-value" id="purpose">KAS JEMAAT GKPI MEDAN KOTA</div>
                                    </div>
                                    <div class="data-row">
                                        <div class="data-label">No.Subkategori</div>
                                        <div class="data-value" id="subcategory-code">-</div>
                                    </div>
                                    <div class="data-row">
                                        <div class="data-label">Uraian</div>
                                        <div class="data-value" id="description-text">-</div>
                                    </div>
                                </div>

                                <div class="amount-section">
                                    <div class="payment-method">
                                        <strong>Bentuk Penerimaan</strong>
                                        <div class="payment-type" style="margin-top: 5px;">
                                            <div>
                                                <div class="box" id="kas-box"></div>
                                                <span>Kas</span>
                                            </div>
                                            <div>
                                                <div class="box" id="giro-box"></div>
                                                <span>Check/Giro No.:</span>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="payment-amount">
                                        <strong>Jumlah</strong>
                                        <div class="amount" id="total-amount">Rp 0,-</div>
                                    </div>
                                </div>

                                <div class="signature-section">
                                    <table class="signature-table">
                                        <tr>
                                            <td class="signature-label">Diperiksa Oleh</td>
                                            <td class="signature-label">Disetujui Oleh</td>
                                            <td class="signature-label">Dibukukan Oleh</td>
                                            <td class="signature-label">Tanggal Penerimaan</td>
                                            <td class="signature-label">Tanda Tangan Kasir</td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <div class="signature-space"></div>
                                                <div>(Bendahara)</div>
                                            </td>
                                            <td>
                                                <div class="signature-space"></div>
                                                <div>(Guru Jemaat)</div>
                                            </td>
                                            <td>
                                                <div class="signature-space"></div>
                                                <div>(Sekretaris)</div>
                                            </td>
                                            <td>
                                                <div class="signature-space" id="receipt-date">-</div>
                                                <div>(Tanggal)</div>
                                            </td>
                                            <td>
                                                <div class="signature-space"></div>
                                                <div>(Kasir)</div>
                                            </td>
                                        </tr>
                                    </table>
                                </div>

                                <div class="footer">
                                    <div id="print-date">Dicetak pada: -</div>
                                    <div>GKPI Medan Kota - Sistem Informasi Keuangan</div>
                                </div>
                            </div>
                        </div>

                        <!-- Expense Receipt Template -->
                        <div class="receipt-container" id="expense-receipt" style="display: none;">
                            <div class="receipt">
                                <div class="receipt-number-large" id="expense-receipt-number">No : 020674</div>
                                <div class="form-title">BUKTI PENGELUARAN KAS</div>

                                <div class="receipt-header">
                                    <div class="bank-info-section">
                                        <div class="bank-info">
                                            <div class="bank-label">Bank</div>
                                            <div class="bank-value" id="bank-value">:</div>
                                        </div>
                                        <div class="bank-info">
                                            <div class="bank-label">Tanggal</div>
                                            <div class="bank-value" id="expense-date">: 03.09.2025</div>
                                        </div>
                                    </div>
                                    <div class="church-info">
                                        <h2>GEREJA KRISTEN PROTESTAN INDONESIA (GKPI)</h2>
                                        <p>Jemaat GKPI Medan Kota</p>
                                    </div>
                                </div>

                                <div class="vertical-data">
                                    <div class="data-row">
                                        <div class="data-label">Diterima dari</div>
                                        <div class="data-value" id="expense-received-from"></div>
                                    </div>
                                    <div class="data-row">
                                        <div class="data-label">Penerima</div>
                                        <div class="data-value" id="expense-receiver"></div>
                                    </div>
                                    <div class="data-row">
                                        <div class="data-label">Alamat Penerima</div>
                                        <div class="data-value" id="expense-address">-</div>
                                    </div>
                                    <div class="data-row">
                                        <div class="data-label">No. Subkategori</div>
                                        <div class="data-value" id="expense-subcategory-code">200.04.01</div>
                                    </div>
                                    <div class="data-row">
                                        <div class="data-label">Uraian</div>
                                        <div class="data-value" id="expense-description-text">Biaya BBH, Mobil Dinas, Pemetaan tgl. 01 Sept 2025</div>
                                    </div>
                                </div>

                                <div class="amount-section">
                                    <div class="payment-type">
                                        <div>
                                            <div class="box" id="expense-cek-box"></div>
                                            <span>Cek / G.B</span>
                                        </div>
                                        <div>
                                            <div class="box" id="expense-jumlah-box"></div>
                                            <span>Jumlah</span>
                                        </div>
                                    </div>
                                    <div class="payment-amount">
                                        <strong>Jumlah</strong>
                                        <div class="amount" id="expense-total-amount">Rp 100.000,-</div>
                                    </div>
                                </div>

                                <div class="signature-section">
                                    <table class="signature-table">
                                        <tr>
                                            <td class="signature-label">Diperiksa Oleh</td>
                                            <td class="signature-label">Disetujui Oleh</td>
                                            <td class="signature-label">Dibukukan</td>
                                            <td class="signature-label">Telah Menerima Jumlah Tsb Diatas</td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <div class="signature-space">Diperiksa Oleh</div>
                                            </td>
                                            <td>
                                                <div class="signature-space">Bendahara</div>
                                                <div class="signature-space" style="margin-top: 5px;">Pemimpin Jemaat</div>
                                            </td>
                                            <td>
                                                <div class="signature-space">Paraf</div>
                                                <div class="signature-space" style="margin-top: 5px;" id="expense-booked-date">03.09.2025</div>
                                            </td>
                                            <td>
                                                <div class="signature-space">Tanda Tangan</div>
                                                <div class="signature-space" style="margin-top: 5px;">Tanggal</div>
                                            </td>
                                        </tr>
                                    </table>
                                </div>

                                <div class="footer">
                                    <div id="expense-print-date">Dicetak pada: 03.09.2025 22:31</div>
                                    <div>GKPI Medan Kota - Sistem Informasi Keuangan</div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="card-footer text-center">
                        <button onclick="printReceipt()" class="btn btn-success btn-lg">
                            <i class="bi bi-printer me-2"></i>Cetak Kuitansi
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        // Global variables
        let currentJurnalId = null;
        let isExpenseJournal = false;

        // Function to detect if journal is expense journal
        function detectExpenseJournal(jurnalName) {
            const expenseKeywords = ['pengeluaran', 'biaya', 'beban', 'expense', 'pengeluaran', 'kas keluar', 'penggunaan'];
            const lowerName = jurnalName.toLowerCase();
            return expenseKeywords.some(keyword => lowerName.includes(keyword));
        }

        // Function to load receipt templates
        function loadReceiptTemplate(isExpenseJournal) {
            const incomeReceipt = document.getElementById('income-receipt');
            const expenseReceipt = document.getElementById('expense-receipt');
            const receiptTypeTitle = document.getElementById('receipt-type-title');

            if (isExpenseJournal) {
                incomeReceipt.style.display = 'none';
                expenseReceipt.style.display = 'block';
                receiptTypeTitle.textContent = 'Pengeluaran';
            } else {
                incomeReceipt.style.display = 'block';
                expenseReceipt.style.display = 'none';
                receiptTypeTitle.textContent = 'Penerimaan';
            }
        }

        // Show/hide fields based on jenis input
        function updateFields() {
            const jenisInput = document.querySelector('input[name="jenis_input"]:checked').value;
            const kategoriSelect = document.getElementById('id_kategori');
            const subkategoriSelect = document.getElementById('id_subkategori');
            const jumlahInput = document.getElementById('jumlah');
            const setoranInput = document.getElementById('setoran');
            const setoranLabel = document.getElementById('setoran-label');
            const noKwitansiInput = document.getElementById('no_kwitansi');
            const tanggalInput = document.getElementById('tanggal');
            const uraianInput = document.getElementById('uraian');
            const uraianLabel = document.querySelector('label[for="uraian"]');
            const kategoriRow = document.getElementById('kategori-row');
            const subkategoriRow = document.getElementById('subkategori-row');
            const jumlahRow = document.getElementById('jumlah-row');
            const setoranRow = document.getElementById('setoran-row');

            if (jenisInput === 'setoran') {
                // Hide kategori row
                if (kategoriRow) kategoriRow.style.display = 'none';

                // Keep subkategori-row visible but hide jumlah row and show setoran row
                if (subkategoriRow) subkategoriRow.style.display = 'block';
                if (jumlahRow) jumlahRow.style.display = 'none';
                if (setoranRow) setoranRow.style.display = 'block';

                // Disable kategori, subkategori, jumlah inputs
                kategoriSelect.disabled = true;
                kategoriSelect.value = '';
                subkategoriSelect.disabled = true;
                subkategoriSelect.value = '';
                jumlahInput.disabled = true;
                jumlahInput.value = '0';

                // Enable setoran and required fields
                setoranInput.disabled = false;
                setoranLabel.textContent = 'Setoran/Uang dari Bank';

                // Ensure required fields are enabled and required
                noKwitansiInput.disabled = false;
                noKwitansiInput.required = true;
                tanggalInput.disabled = false;
                tanggalInput.required = true;
                uraianInput.disabled = false;
                uraianInput.required = true;
                setoranInput.required = true;

                // Update uraian label based on jurnal
                if (currentJurnalId) {
                    const selectedJurnal = document.querySelector(`#id_jurnal option[value="${currentJurnalId}"]`);
                    if (selectedJurnal) {
                        const jurnalName = selectedJurnal.textContent.toLowerCase();
                        if (jurnalName.includes('bank')) {
                            uraianLabel.textContent = 'Uraian Setoran';
                        } else {
                            uraianLabel.textContent = 'Uraian';
                        }
                    }
                } else {
                    uraianLabel.textContent = 'Uraian';
                }
            } else {
                // Show kategori, subkategori, jumlah rows
                if (kategoriRow) kategoriRow.style.display = 'block';
                if (subkategoriRow) subkategoriRow.style.display = 'block';
                if (jumlahRow) jumlahRow.style.display = 'block';

                // Hide setoran row
                if (setoranRow) setoranRow.style.display = 'none';

                // Enable all fields for lengkap mode
                kategoriSelect.disabled = false;
                kategoriSelect.required = true;
                subkategoriSelect.disabled = false;
                subkategoriSelect.required = true;
                jumlahInput.disabled = false;
                jumlahInput.required = true;
                setoranInput.disabled = true;
                setoranInput.value = '0';
                setoranInput.required = false;
                setoranLabel.textContent = 'Setoran (Opsional)';

                // Ensure all fields are enabled and required
                noKwitansiInput.disabled = false;
                noKwitansiInput.required = true;
                tanggalInput.disabled = false;
                tanggalInput.required = true;
                uraianInput.disabled = false;
                uraianInput.required = true;
                uraianLabel.textContent = 'Uraian/Keterangan';
            }
        }

        // Initialize when page loads
        document.addEventListener('DOMContentLoaded', function() {
            // Attach event listeners to jenis input radios
            const jenisInputRadios = document.getElementsByName('jenis_input');
            jenisInputRadios.forEach(radio => {
                radio.addEventListener('change', updateFields);
            });

            // Initial call to set default state
            updateFields();
        });

        // Fungsi untuk memuat kategori berdasarkan jurnal
        document.getElementById('id_jurnal').addEventListener('change', function() {
            const jurnalId = this.value;
            currentJurnalId = jurnalId;
            const kategoriSelect = document.getElementById('id_kategori');
            const jenisInputRadios = document.getElementsByName('jenis_input');
            const subkategoriSelect = document.getElementById('id_subkategori');

            // Detect if this is an expense journal
            const selectedOption = this.options[this.selectedIndex];
            if (selectedOption && selectedOption.textContent) {
                isExpenseJournal = detectExpenseJournal(selectedOption.textContent);
            } else {
                isExpenseJournal = false;
            }

            // Switch receipt template based on journal type
            loadReceiptTemplate(isExpenseJournal);

            // Reset jenis input to default (lengkap) on jurnal change
            jenisInputRadios.forEach(radio => {
                radio.checked = radio.value === 'lengkap';
            });

            // Update fields after resetting radio buttons
            updateFields();

            if (jurnalId) {
                fetch(`index.php?action=get_kategori&id_jurnal=${jurnalId}`)
                    .then(response => response.json())
                    .then(data => {
                        kategoriSelect.innerHTML = '';

                        if (data.length > 0) {
                            kategoriSelect.disabled = false;
                            const defaultOption = document.createElement('option');
                            defaultOption.value = '';
                            defaultOption.textContent = 'Pilih Kategori';
                            defaultOption.selected = true;
                            defaultOption.disabled = true;
                            kategoriSelect.appendChild(defaultOption);

                            data.forEach(kat => {
                                const option = document.createElement('option');
                                option.value = kat.id_kategori;
                                option.textContent = `${kat.kode_kategori} - ${kat.nama_kategori}`;
                                kategoriSelect.appendChild(option);
                            });

                            // Automatically trigger change event on kategori to load subkategori
                            if (kategoriSelect.options.length > 1) {
                                kategoriSelect.selectedIndex = 1;
                                const event = new Event('change');
                                kategoriSelect.dispatchEvent(event);
                            }
                        } else {
                            kategoriSelect.disabled = true;
                            const option = document.createElement('option');
                            option.textContent = 'Tidak ada kategori tersedia';
                            option.disabled = true;
                            kategoriSelect.appendChild(option);
                        }

                        // Reset subkategori
                        subkategoriSelect.innerHTML = '';
                        subkategoriSelect.disabled = true;
                        const subOption = document.createElement('option');
                        subOption.textContent = 'Pilih kategori terlebih dahulu';
                        subOption.disabled = true;
                        subOption.selected = true;
                        subkategoriSelect.appendChild(subOption);
                    });
            } else {
                kategoriSelect.innerHTML = '';
                kategoriSelect.disabled = true;
                const option = document.createElement('option');
                option.textContent = 'Pilih jurnal terlebih dahulu';
                option.disabled = true;
                option.selected = true;
                kategoriSelect.appendChild(option);

                // Reset subkategori
                subkategoriSelect.innerHTML = '';
                subkategoriSelect.disabled = true;
                const subOption = document.createElement('option');
                subOption.textContent = 'Pilih kategori terlebih dahulu';
                subOption.disabled = true;
                subOption.selected = true;
                subkategoriSelect.appendChild(subOption);
            }
        });
        
        // Fungsi untuk memuat subkategori berdasarkan kategori
        document.getElementById('id_kategori').addEventListener('change', function() {
            const kategoriId = this.value;
            const subkategoriSelect = document.getElementById('id_subkategori');
            
            if (kategoriId) {
                const url = `index.php?action=get_subkategori&id_kategori=${kategoriId}`;
                
                fetch(url)
                    .then(response => {
                        if (!response.ok) {
                            throw new Error(`HTTP error! status: ${response.status}`);
                        }
                        return response.json();
                    })
                    .then(data => {
                        
                        subkategoriSelect.innerHTML = '';
                        
                        if (data.length > 0) {
                            subkategoriSelect.disabled = false;
                            const defaultOption = document.createElement('option');
                            defaultOption.value = '';
                            defaultOption.textContent = 'Pilih Subkategori';
                            defaultOption.selected = true;
                            defaultOption.disabled = true;
                            subkategoriSelect.appendChild(defaultOption);
                            
                            data.forEach(sub => {
                                const option = document.createElement('option');
                                option.value = sub.id_subkategori;

                                // Handle both simple and complex code formats
                                const displayCode = formatSubkategoriCode(sub.kode_subkategori);
                                option.textContent = `${displayCode} - ${sub.nama_subkategori}`;
                                subkategoriSelect.appendChild(option);
                            });

                            // Automatically select first subkategori and trigger change event after a short delay
                            if (subkategoriSelect.options.length > 1) {
                                setTimeout(() => {
                                    subkategoriSelect.selectedIndex = 1;
                                    const event = new Event('change');
                                    subkategoriSelect.dispatchEvent(event);
                                }, 300);
                            }
                        } else {
                            subkategoriSelect.disabled = true;
                            const option = document.createElement('option');
                            option.textContent = 'Tidak ada subkategori tersedia';
                            option.disabled = true;
                            subkategoriSelect.appendChild(option);
                        }
                    })
                    .catch(error => {
                        console.error('❌ Error fetching subkategori:', error); // Debug log
                        // Tampilkan error ke user
                        subkategoriSelect.innerHTML = '';
                        subkategoriSelect.disabled = true;
                        const option = document.createElement('option');
                        option.textContent = 'Error: ' + error.message;
                        option.disabled = true;
                        subkategoriSelect.appendChild(option);
                    });
            } else {
                subkategoriSelect.innerHTML = '';
                subkategoriSelect.disabled = true;
                const option = document.createElement('option');
                option.textContent = 'Pilih kategori terlebih dahulu';
                option.disabled = true;
                option.selected = true;
                subkategoriSelect.appendChild(option);
            }
        });
        
        // Auto-fill uraian berdasarkan subkategori yang dipilih
        document.getElementById('id_subkategori').addEventListener('change', function() {
            const selectedOption = this.options[this.selectedIndex];
            if (selectedOption.textContent.includes('-')) {
                const uraian = selectedOption.textContent.split('-')[1].trim();
                document.getElementById('uraian').value = uraian;
            }
        });
        
        // Format input jumlah saat kehilangan fokus
        const jumlahInput = document.getElementById('jumlah');
        jumlahInput.addEventListener('blur', function() {
            if (this.value !== '' && this.value !== '0') {
                let num = parseFloat(this.value);
                this.value = num % 1 === 0 ? num.toString() : num.toFixed(2);
            }
        });
        jumlahInput.addEventListener('focus', function() {
            if (this.value === '0.00' || this.value === '0') {
                this.value = '';
            }
        });

        // Format input setoran saat kehilangan fokus
        const setoranInput = document.getElementById('setoran');
        setoranInput.addEventListener('blur', function() {
            let num = parseFloat(this.value || 0);
            this.value = num % 1 === 0 ? num.toString() : num.toFixed(2);
        });
        setoranInput.addEventListener('focus', function() {
            if (this.value === '0.00' || this.value === '0') {
                this.value = '';
            }
        });

        // Fungsi untuk memformat kode subkategori agar mudah dibaca
        function formatSubkategoriCode(code) {
            if (!code) return '';
            
            // Jika kode sudah dalam format yang benar, kembalikan as is
            if (code.includes('.')) {
                return code;
            }
            
            // Jika kode adalah angka 3 digit, tambahkan .00
            if (/^[0-9]{3}$/.test(code)) {
                return code + '.00';
            }
            
            return code;
        }

        // Fungsi untuk validasi format kode subkategori
        function validateSubkategoriCode(code) {
            // Format: xxx.xx.xx atau xxx.xx.xxx
            const pattern = /^[0-9]{3}\.[0-9]{2}(\.[0-9]{2,3})?$/;
            return pattern.test(code);
        }

        // Event listener untuk validasi real-time pada input kode subkategori
        document.addEventListener('DOMContentLoaded', function() {
            const subkategoriInput = document.getElementById('kode_subkategori');
            if (subkategoriInput) {
                subkategoriInput.addEventListener('input', function() {
                    const code = this.value;
                    if (code && !validateSubkategoriCode(code)) {
                        this.setCustomValidity('Format tidak valid. Gunakan: xxx.xx.xx atau xxx.xx.xxx');
                        this.classList.add('is-invalid');
                    } else {
                        this.setCustomValidity('');
                        this.classList.remove('is-invalid');
                        this.classList.add('is-valid');
                    }
                });
            }
        });

        document.getElementById('transaksiForm').addEventListener('submit', function() {
            const kat = document.getElementById('id_kategori');
            const sub = document.getElementById('id_subkategori');
            const jenisInput = document.querySelector('input[name="jenis_input"]:checked').value;
            const setoranInput = document.getElementById('setoran');
            const jumlahInput = document.getElementById('jumlah');

            // Enable disabled fields for form submission
            if (kat && kat.disabled && kat.value) kat.disabled = false;
            if (sub && sub.disabled && sub.value) sub.disabled = false;

            // Handle validation based on jenis input
            if (jenisInput === 'setoran') {
                // For setoran mode, setoran is required, kategori/subkategori are optional
                setoranInput.required = true;
                setoranInput.disabled = false;
                if (kat) kat.required = false;
                if (sub) sub.required = false;
                if (jumlahInput) jumlahInput.required = false;
            } else {
                // For lengkap mode, kategori/subkategori are required, setoran is optional
                setoranInput.required = false;
                setoranInput.disabled = true;
                if (kat) kat.required = true;
                if (sub) sub.required = true;
                if (jumlahInput) jumlahInput.required = true;
            }
        });

        // Receipt update functions
        function updateReceipt() {
            if (isExpenseJournal) {
                updateExpenseReceipt();
            } else {
                updateIncomeReceipt();
            }
        }

        function updateIncomeReceipt() {
            // Update receipt number
            const noKwitansi = document.getElementById('no_kwitansi').value;
            document.getElementById('receipt-number').textContent = noKwitansi ? `No.KW: ${noKwitansi}` : 'No.KW: -';

            // Update description
            const uraian = document.getElementById('uraian').value;
            document.getElementById('description-text').textContent = uraian || '-';

            // Update received from
            const diterimaDari = document.getElementById('diterima_dari').value;
            document.getElementById('received-from').textContent = diterimaDari || '-';

            // Update date
            const tanggal = document.getElementById('tanggal').value;
            if (tanggal) {
                const dateObj = new Date(tanggal);
                const formattedDate = dateObj.toLocaleDateString('id-ID', {
                    day: 'numeric',
                    month: 'long',
                    year: 'numeric'
                });
                document.getElementById('receipt-date').textContent = formattedDate;
            } else {
                document.getElementById('receipt-date').textContent = '-';
            }

            // Update amount
            const jenisInput = document.querySelector('input[name="jenis_input"]:checked').value;
            let amount = 0;
            if (jenisInput === 'setoran') {
                amount = parseFloat(document.getElementById('setoran').value) || 0;
            } else {
                amount = parseFloat(document.getElementById('jumlah').value) || 0;
            }

            const formattedAmount = new Intl.NumberFormat('id-ID').format(amount);
            document.getElementById('amount-text').textContent = `Rp ${formattedAmount},-`;
            document.getElementById('total-amount').textContent = `Rp ${formattedAmount},-`;

            // Update payment method
            updatePaymentMethod(jenisInput);

            // Update subcategory code
            const subkategoriSelect = document.getElementById('id_subkategori');
            const selectedOption = subkategoriSelect.options[subkategoriSelect.selectedIndex];
            if (selectedOption && selectedOption.value && selectedOption.textContent.includes('-')) {
                const code = selectedOption.textContent.split(' - ')[0];
                document.getElementById('subcategory-code').textContent = code;
            } else {
                document.getElementById('subcategory-code').textContent = '-';
            }

            // Update print date
            const now = new Date();
            const printDate = now.toLocaleDateString('id-ID', {
                day: 'numeric',
                month: 'long',
                year: 'numeric',
                hour: '2-digit',
                minute: '2-digit'
            });
            document.getElementById('print-date').textContent = `Dicetak pada: ${printDate}`;
        }

        function updateExpenseReceipt() {
            // Update receipt number
            const noKwitansi = document.getElementById('no_kwitansi').value;
            document.getElementById('expense-receipt-number').textContent = noKwitansi ? `No : ${noKwitansi}` : 'No : -';

            // Update received from (for expense, this is the recipient)
            const diterimaDari = document.getElementById('diterima_dari').value;
            document.getElementById('expense-received-from').textContent = diterimaDari || '-';

            // Update receiver (same as received from for expense)
            document.getElementById('expense-receiver').textContent = diterimaDari || '-';

            // Update address (placeholder for now)
            document.getElementById('expense-address').textContent = '-';

            // Update description
            const uraian = document.getElementById('uraian').value;
            document.getElementById('expense-description-text').textContent = uraian || '-';

            // Update date
            const tanggal = document.getElementById('tanggal').value;
            if (tanggal) {
                const dateObj = new Date(tanggal);
                const formattedDate = dateObj.toLocaleDateString('id-ID', {
                    day: 'numeric',
                    month: 'short',
                    year: 'numeric'
                });
                document.getElementById('expense-date').textContent = `: ${formattedDate}`;
                document.getElementById('expense-booked-date').textContent = formattedDate;
            } else {
                document.getElementById('expense-date').textContent = ': -';
                document.getElementById('expense-booked-date').textContent = '-';
            }

            // Update amount
            const jenisInput = document.querySelector('input[name="jenis_input"]:checked').value;
            let amount = 0;
            if (jenisInput === 'setoran') {
                amount = parseFloat(document.getElementById('setoran').value) || 0;
            } else {
                amount = parseFloat(document.getElementById('jumlah').value) || 0;
            }

            const formattedAmount = new Intl.NumberFormat('id-ID').format(amount);
            document.getElementById('expense-total-amount').textContent = `Rp ${formattedAmount},-`;

            // Update subcategory code
            const subkategoriSelect = document.getElementById('id_subkategori');
            const selectedOption = subkategoriSelect.options[subkategoriSelect.selectedIndex];
            if (selectedOption && selectedOption.value && selectedOption.textContent.includes('-')) {
                const code = selectedOption.textContent.split(' - ')[0];
                document.getElementById('expense-subcategory-code').textContent = code;
            } else {
                document.getElementById('expense-subcategory-code').textContent = '-';
            }

            // Update print date
            const now = new Date();
            const printDate = now.toLocaleDateString('id-ID', {
                day: 'numeric',
                month: 'short',
                year: 'numeric',
                hour: '2-digit',
                minute: '2-digit'
            });
            document.getElementById('expense-print-date').textContent = `Dicetak pada: ${printDate}`;
        }

            function updatePaymentMethod(jenisInput) {
                const kasBox = document.getElementById('kas-box');
                const giroBox = document.getElementById('giro-box');

                // Reset both boxes (keep them unchecked)
                kasBox.classList.remove('checked');
                giroBox.classList.remove('checked');

                // Both boxes remain unchecked by default
                // Users can manually check the appropriate box if needed
            }

            // Make the Cek / G.B and Jumlah boxes editable and update in real-time
            document.addEventListener('DOMContentLoaded', function() {
                const cekBox = document.getElementById('expense-cek-box');
                const jumlahBox = document.getElementById('expense-jumlah-box');

                if (cekBox) {
                    cekBox.classList.add('editable-field');
                    cekBox.setAttribute('contenteditable', 'true');

                    cekBox.addEventListener('input', function() {
                        // You can add logic here to sync with form or other elements if needed
                    });

                    cekBox.addEventListener('keydown', function(e) {
                        if (e.key === 'Enter') {
                            e.preventDefault();
                            this.blur();
                        }
                    });
                }

                if (jumlahBox) {
                    jumlahBox.classList.add('editable-field');
                    jumlahBox.setAttribute('contenteditable', 'true');

                    jumlahBox.addEventListener('input', function() {
                        // You can add logic here to sync with form or other elements if needed
                    });

                    jumlahBox.addEventListener('keydown', function(e) {
                        if (e.key === 'Enter') {
                            e.preventDefault();
                            this.blur();
                        }
                    });
                }
            });

        function printReceipt() {
            // Select the currently visible receipt template
            let receiptElement;
            let receiptTitle;

            if (isExpenseJournal) {
                receiptElement = document.getElementById('expense-receipt').querySelector('.receipt');
                receiptTitle = 'Bukti Pengeluaran';
            } else {
                receiptElement = document.getElementById('income-receipt').querySelector('.receipt');
                receiptTitle = 'Bukti Penerimaan';
            }

            const printWindow = window.open('', '_blank');
            const styles = `
                <style>
                    body { font-family: Arial, sans-serif; margin: 0; padding: 10px; }
                    .receipt { border: 1px solid #d63384; padding: 10px; max-width: 500px; margin: 0 auto; }
                    .receipt-title { text-align: center; font-weight: bold; font-size: 14px; color: #d63384; margin-bottom: 8px; }
                    .receipt-header { display: flex; justify-content: space-between; align-items: flex-start; border-bottom: 1px solid #d63384; padding-bottom: 8px; margin-bottom: 10px; }
                    .church-info h2 { font-size: 11px; color: #d63384; margin-bottom: 2px; }
                    .receipt-number-large { font-weight: bold; color: #d63384; font-size: 12px; }
                    .vertical-data { display: flex; flex-direction: column; gap: 1px; margin-bottom: 4px; }
                    .data-row { display: flex; border-bottom: 1px solid #eee; padding-bottom: 1px; }
                    .data-label { width: 120px; font-weight: bold; color: #555; font-size: 10px; }
                    .data-value { flex: 1; font-size: 10px; }
                    .amount-section { display: flex; justify-content: space-between; border: 1px solid #ddd; margin-bottom: 10px; }
                    .payment-method { padding: 8px; width: 65%; border-right: 1px solid #ddd; }
                    .payment-amount { padding: 8px; width: 35%; text-align: center; }
                    .amount { font-size: 14px; font-weight: bold; color: #d63384; margin-top: 3px; }
                    .signature-section { border: 1px solid #ddd; }
                    .signature-table { width: 100%; border-collapse: collapse; }
                    .signature-table td { padding: 6px; border: 1px solid #ddd; text-align: center; vertical-align: bottom; font-size: 11px; }
                    .signature-label { font-weight: bold; background: #f9f9f9; font-size: 11px; }
                    .signature-space { height: 40px; border-bottom: 1px dashed #999; margin-top: 3px; }
                    .footer { margin-top: 8px; display: flex; justify-content: space-between; font-size: 11px; color: #777; }
                    .box { width: 10px; height: 10px; border: 1px solid #333; display: inline-block; margin-right: 3px; }
                    .checked { background: #d63384; position: relative; }
                    .checked:after { content: "✓"; color: white; font-size: 6px; position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%); }
                    .payment-type { display: flex; gap: 8px; margin-top: 3px; font-size: 10px; }
                    .payment-type div { display: flex; align-items: center; }
                    .form-title { text-align: center; font-weight: bold; font-size: 14px; color: #d63384; margin-bottom: 8px; }
                    .bank-info { display: flex; margin-bottom: 5px; }
                    .bank-label { width: 80px; font-weight: bold; font-size: 10px; }
                    .bank-value { flex: 1; font-size: 10px; }
                </style>
            `;

            const receiptNumber = document.getElementById('no_kwitansi').value || 'No.KW';

            printWindow.document.write(`
                <!DOCTYPE html>
                <html>
                <head>
                    <title>${receiptTitle} - ${receiptNumber}</title>
                    ${styles}
                </head>
                <body>
                    ${receiptElement.outerHTML}
                </body>
                </html>
            `);

            printWindow.document.close();
            printWindow.print();
        }

        // Initialize receipt update on page load
        document.addEventListener('DOMContentLoaded', function() {
            updateReceipt();

            // Add event listeners to all form fields for real-time updates
            const formFields = [
                'no_kwitansi', 'uraian', 'tanggal', 'jumlah', 'setoran',
                'id_jurnal', 'id_kategori', 'id_subkategori'
            ];

            formFields.forEach(fieldId => {
                const element = document.getElementById(fieldId);
                if (element) {
                    element.addEventListener('input', updateReceipt);
                    element.addEventListener('change', updateReceipt);
                }
            });

            // Add event listeners to radio buttons
            const jenisInputRadios = document.getElementsByName('jenis_input');
            jenisInputRadios.forEach(radio => {
                radio.addEventListener('change', updateReceipt);
            });

            // Initialize editable receipt fields
            initializeEditableReceipt();
        });

        // Function to make receipt fields editable
        function initializeEditableReceipt() {
            // Make receipt fields editable
            const editableFields = [
                'receipt-number',
                'received-from',
                'amount-text',
                'purpose',
                'subcategory-code',
                'description-text',
                'receipt-date',
                'total-amount'
            ];

            editableFields.forEach(fieldId => {
                const element = document.getElementById(fieldId);
                if (element) {
                    element.classList.add('editable-field');
                    element.setAttribute('contenteditable', 'true');

                    // Add event listeners for editing
                    element.addEventListener('input', function() {
                        // Sync changes back to form if needed
                        syncReceiptToForm(fieldId, this.textContent);
                    });

                    element.addEventListener('blur', function() {
                        // Format content when leaving the field
                        formatEditableField(fieldId, this);
                    });

                    element.addEventListener('keydown', function(e) {
                        // Handle Enter key to prevent line breaks in single-line fields
                        if (e.key === 'Enter' && !fieldId.includes('description')) {
                            e.preventDefault();
                            this.blur();
                        }
                    });
                }
            });

            // Also make expense receipt fields editable
            const expenseEditableFields = [
                'expense-receipt-number',
                'expense-received-from',
                'expense-receiver',
                'expense-address',
                'expense-subcategory-code',
                'expense-description-text',
                'expense-total-amount',
                'bank-value'
            ];

            expenseEditableFields.forEach(fieldId => {
                const element = document.getElementById(fieldId);
                if (element) {
                    element.classList.add('editable-field');
                    element.setAttribute('contenteditable', 'true');

                    element.addEventListener('input', function() {
                        syncReceiptToForm(fieldId, this.textContent);
                    });

                    element.addEventListener('blur', function() {
                        formatEditableField(fieldId, this);
                    });

                    element.addEventListener('keydown', function(e) {
                        if (e.key === 'Enter' && !fieldId.includes('description')) {
                            e.preventDefault();
                            this.blur();
                        }
                    });
                }
            });
        }

        // Function to sync receipt changes back to form
        function syncReceiptToForm(fieldId, content) {
            switch(fieldId) {
                case 'receipt-number':
                case 'expense-receipt-number':
                    // Extract number from "No.KW: XXX" format
                    const numberMatch = content.match(/No\.?\s*:?\s*(\w+)/i);
                    if (numberMatch) {
                        document.getElementById('no_kwitansi').value = numberMatch[1];
                    }
                    break;
                case 'received-from':
                case 'expense-received-from':
                    document.getElementById('diterima_dari').value = content.trim();
                    break;
                case 'description-text':
                case 'expense-description-text':
                    document.getElementById('uraian').value = content.trim();
                    break;
                case 'amount-text':
                case 'total-amount':
                case 'expense-total-amount':
                    // Extract number from "Rp XXX,XXX,-" format
                    const amountMatch = content.match(/Rp\s*([\d,]+)/);
                    if (amountMatch) {
                        const cleanAmount = amountMatch[1].replace(/,/g, '');
                        const jenisInput = document.querySelector('input[name="jenis_input"]:checked').value;
                        if (jenisInput === 'setoran') {
                            document.getElementById('setoran').value = cleanAmount;
                        } else {
                            document.getElementById('jumlah').value = cleanAmount;
                        }
                    }
                    break;
            }
        }

        // Function to format editable fields
        function formatEditableField(fieldId, element) {
            let content = element.textContent.trim();

            switch(fieldId) {
                case 'receipt-number':
                    if (content && !content.includes('No.KW:')) {
                        element.textContent = `No.KW: ${content}`;
                    }
                    break;
                case 'expense-receipt-number':
                    if (content && !content.includes('No :')) {
                        element.textContent = `No : ${content}`;
                    }
                    break;
                case 'amount-text':
                case 'total-amount':
                case 'expense-total-amount':
                    if (content && !content.includes('Rp')) {
                        // Format as currency
                        const numValue = parseFloat(content.replace(/[^\d]/g, ''));
                        if (!isNaN(numValue)) {
                            const formatted = new Intl.NumberFormat('id-ID').format(numValue);
                            element.textContent = `Rp ${formatted},-`;
                        }
                    }
                    break;
                case 'receipt-date':
                    // Keep date as is
                    break;
            }
        }

    </script>

    <script>
        // Fungsi untuk menyalin header gereja
        function copyChurchHeader() {
            const incomeChurchHeader = document.querySelector('#income-receipt .church-info p:nth-child(2)');
            const incomeChurchLocation = document.querySelector('#income-receipt .church-info p:nth-child(3)');

            if (incomeChurchHeader && incomeChurchLocation) {
                const expenseChurchHeader = document.querySelector('#expense-receipt .church-info h2');
                const expenseChurchLocation = document.querySelector('#expense-receipt .church-info p');

                if (expenseChurchHeader && expenseChurchLocation) {
                    expenseChurchHeader.textContent = incomeChurchHeader.textContent;
                    expenseChurchLocation.textContent = incomeChurchLocation.textContent.replace('Jemaat ', '');
                }
            }
        }

        // Panggil fungsi ketika halaman dimuat
        document.addEventListener('DOMContentLoaded', copyChurchHeader);
    </script>
</body>
</html>

 