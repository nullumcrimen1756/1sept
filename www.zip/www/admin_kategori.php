<?php
// Error reporting untuk development (comment untuk production)
// error_reporting(E_ALL);
// ini_set('display_errors', 1);

// Mulai session
session_start();

require_once 'config.php';
require_once 'functions.php';
require_once 'includes/url_helper.php';

// Set judul halaman
$page_title = "Kelola Kategori - Sistem Keuangan Gereja";

// Periksa koneksi database
if (!$conn) {
    die("Koneksi database gagal");
}

$action = isset($_GET['action']) ? $_GET['action'] : 'list';

// 1. Ambil semua data jurnal untuk dropdown
// Ganti kode pengambilan data jurnal dengan ini:
$jurnals = [];
$sql = "SELECT * FROM jurnal ORDER BY nama_jurnal";
$result = $conn->query($sql);

if ($result === false) {
    die("Error mengambil data jurnal");
}

$jurnals = $result->fetchAll(PDO::FETCH_ASSOC);
if (empty($jurnals)) {
    die("Tabel jurnal kosong. Silakan isi data jurnal terlebih dahulu.");
}

// DEBUG: Tampilkan data jurnal yang diambil
error_log("Data Jurnal: " . print_r($jurnals, true));

// 2. Ambil id_jurnal dari parameter URL
$selected_jurnal_id = isset($_GET['id_jurnal']) ? intval($_GET['id_jurnal']) : null;

switch ($action) {
    case 'add_kategori':
        addKategori();
        break;
    case 'add_subkategori':
        addSubkategori();
        break;
    case 'save_kategori':
        saveKategori();
        break;
    case 'save_subkategori':
        saveSubkategori();
        break;
    case 'delete_kategori':
        deleteKategori();
        break;
    case 'delete_subkategori':
        deleteSubkategori();
        break;
    default:
        listData();
}
function listData() {
    global $conn, $jurnals, $selected_jurnal_id;
    
    $selected_jurnal = isset($_GET['id_jurnal']) ? intval($_GET['id_jurnal']) : null;
    
    // Ambil data kategori
    $kategori = [];
    $sql = "SELECT * FROM kategori";
    if ($selected_jurnal) {
        $sql .= " WHERE id_jurnal = ?";
        $stmt = $conn->prepare($sql);
        $stmt->execute([$selected_jurnal]);
        $kategori = $stmt->fetchAll(PDO::FETCH_ASSOC);
    } else {
        $result = $conn->query($sql);
        $kategori = $result->fetchAll(PDO::FETCH_ASSOC);
    }
    
    // Ambil data subkategori
    $subkategori = [];
    $sql = "SELECT s.*, k.nama_kategori, j.nama_jurnal
            FROM subkategori s
            JOIN kategori k ON s.id_kategori = k.id_kategori
            JOIN jurnal j ON k.id_jurnal = j.id_jurnal";
    if ($selected_jurnal) {
        $sql .= " WHERE k.id_jurnal = ?";
        $stmt = $conn->prepare($sql);
        $stmt->execute([$selected_jurnal]);
        $subkategori = $stmt->fetchAll(PDO::FETCH_ASSOC);
    } else {
        $result = $conn->query($sql);
        $subkategori = $result->fetchAll(PDO::FETCH_ASSOC);
    }
    
    // Pastikan view menerima semua variabel
    $view_data = [
        'jurnals' => $jurnals,
        'kategori' => $kategori,
        'subkategori' => $subkategori,
        'selected_jurnal_id' => $selected_jurnal_id
    ];
    
    // Debug sebelum include view
    error_log("Data ke View: " . print_r($view_data, true));
    
    // Include header
    include 'views/header.php';
    
    extract($view_data);
    include 'views/admin_kategori.php';
    
    // Include footer
    include 'views/footer.php';
}



function addKategori() {
    global $jurnals, $selected_jurnal_id;
    
    // Include header
    include 'views/header.php';
    
    // Passing variables to view
    $view_data = [
        'jurnals' => $jurnals,
        'selected_jurnal_id' => $selected_jurnal_id
    ];
    extract($view_data);
    
    include 'views/form_kategori.php';
    
    // Include footer
    include 'views/footer.php';
}

function addSubkategori() {
    global $conn, $jurnals, $selected_jurnal_id;
    
    // Ambil data kategori untuk dropdown berdasarkan jurnal yang dipilih (jika ada)
    $selected_jurnal = isset($_GET['id_jurnal']) ? intval($_GET['id_jurnal']) : null;
    
    $kategori = [];
    $sql = "SELECT * FROM kategori";

    if ($selected_jurnal) {
        $sql .= " WHERE id_jurnal = ?";
        $stmt = $conn->prepare($sql);
        $stmt->execute([$selected_jurnal]);
        $kategori = $stmt->fetchAll(PDO::FETCH_ASSOC);
    } else {
        $result = $conn->query($sql);
        $kategori = $result->fetchAll(PDO::FETCH_ASSOC);
    }
    
    // Include header
    include 'views/header.php';
    
    include 'views/form_subkategori.php';
    
    // Include footer
    include 'views/footer.php';
}

function saveKategori() {
    global $conn;
    
    $id_jurnal = intval($_POST['id_jurnal']);
    $kode = trim($_POST['kode_kategori']);
    $nama = trim($_POST['nama_kategori']);
    
    // Validasi
    if (empty($id_jurnal) || empty($kode) || empty($nama)) {
        $_SESSION['error'] = "Semua field harus diisi";
        header("Location: admin_kategori.php?action=add_kategori");
        exit;
    }
    
    // Validasi format kode kategori (3 digit angka)
    if (!preg_match('/^[0-9]{3}$/', $kode)) {
        $_SESSION['error'] = "Kode kategori harus 3 digit angka (contoh: 100, 200, 300)";
        header("Location: admin_kategori.php?action=add_kategori");
        exit;
    }
    
    // Cek apakah kode sudah ada di jurnal yang sama
    $sql = "SELECT id_kategori FROM kategori WHERE kode_kategori = ? AND id_jurnal = ?";
    $stmt = $conn->prepare($sql);
    $stmt->execute([$kode, $id_jurnal]);
    $result = $stmt->fetchAll(PDO::FETCH_ASSOC);

    if (!empty($result)) {
        $_SESSION['error'] = "Kode kategori sudah ada di jurnal ini";
        header("Location: admin_kategori.php?action=add_kategori");
        exit;
    }

    // Simpan ke database
    $sql = "INSERT INTO kategori (id_jurnal, kode_kategori, nama_kategori) VALUES (?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->execute([$id_jurnal, $kode, $nama]);

    if ($stmt->rowCount() > 0) {
        $_SESSION['success'] = "Kategori berhasil ditambahkan";
    } else {
        $_SESSION['error'] = "Gagal menambahkan kategori";
    }
    
    header("Location: admin_kategori.php");
    exit;
}

function saveSubkategori() {
    global $conn;
    
    $id_kategori = intval($_POST['id_kategori']);
    $kode = trim($_POST['kode_subkategori']);
    $nama = trim($_POST['nama_subkategori']);
    
    // Validasi
    if (empty($id_kategori) || empty($kode) || empty($nama)) {
        $_SESSION['error'] = "Semua field harus diisi";
        header("Location: admin_kategori.php?action=add_subkategori");
        exit;
    }
    
// Validasi format kode subkategori dengan pola yang lebih fleksibel
// Format: xxx.xx.xx atau xxx.xx.xxx (mengizinkan huruf di level 3, termasuk trailing huruf setelah angka)
// Modifikasi regex agar huruf di level 3 harus huruf kecil
if (!preg_match('/^[0-9]{3}\.[0-9]{2}(\.[0-9]{2,3}[a-z]?)?$/', $kode)) {
    $_SESSION['error'] = "Format kode subkategori tidak valid. Harap gunakan pola: xxx.xx atau xxx.xx.xx[a-z] (contoh: 100.01 atau 200.05.01a). Level 1 dan 2 harus angka, level 3 bisa angka dengan huruf kecil di akhir.";
    header("Location: admin_kategori.php?action=add_subkategori");
    exit;
}
    
    // Cek apakah kode sudah ada di kategori yang sama
    $sql = "SELECT id_subkategori FROM subkategori WHERE kode_subkategori = ? AND id_kategori = ?";
    $stmt = $conn->prepare($sql);
    $stmt->execute([$kode, $id_kategori]);
    $result = $stmt->fetchAll(PDO::FETCH_ASSOC);

    if (!empty($result)) {
        $_SESSION['error'] = "Kode subkategori sudah ada di kategori ini";
        header("Location: admin_kategori.php?action=add_subkategori");
        exit;
    }

    // Simpan ke database
    $sql = "INSERT INTO subkategori (id_kategori, kode_subkategori, nama_subkategori) VALUES (?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->execute([$id_kategori, $kode, $nama]);

    if ($stmt->rowCount() > 0) {
        $_SESSION['success'] = "Subkategori berhasil ditambahkan";
    } else {
        $_SESSION['error'] = "Gagal menambahkan subkategori";
    }
    
    header("Location: admin_kategori.php");
    exit;
}

function deleteKategori() {
    global $conn;
    
    // Validasi ID
    if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
        $_SESSION['error'] = "ID kategori tidak valid";
        header("Location: admin_kategori.php");
        exit;
    }
    
    $id = intval($_GET['id']);
    
    // Mulai transaksi
    $conn->beginTransaction();

    try {
        // 1. Hapus semua subkategori terkait terlebih dahulu
        $sql = "DELETE FROM subkategori WHERE id_kategori = ?";
        $stmt = $conn->prepare($sql);
        $stmt->execute([$id]);

        // 2. Hapus kategori
        $sql = "DELETE FROM kategori WHERE id_kategori = ?";
        $stmt = $conn->prepare($sql);
        $stmt->execute([$id]);

        // Commit transaksi
        $conn->commit();

        $_SESSION['success'] = "Kategori dan semua subkategori terkait berhasil dihapus";
    } catch (Exception $e) {
        // Rollback jika ada error
        $conn->rollBack();
        $_SESSION['error'] = "Gagal menghapus kategori: " . $e->getMessage();
    }
    
    header("Location: admin_kategori.php");
    exit;
}

function deleteSubkategori() {
    global $conn;
    
    // Validasi ID
    if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
        $_SESSION['error'] = "ID subkategori tidak valid";
        header("Location: admin_kategori.php");
        exit;
    }
    
    $id = intval($_GET['id']);
    
    // 1. Cek apakah subkategori digunakan di transaksi
    $sql = "SELECT COUNT(*) as total FROM transaksi WHERE id_subkategori = ?";
    $stmt = $conn->prepare($sql);
    $stmt->execute([$id]);
    $result = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($result['total'] > 0) {
        $_SESSION['error'] = "Tidak dapat menghapus subkategori karena masih digunakan dalam transaksi";
        header("Location: admin_kategori.php");
        exit;
    }

    // 2. Hapus subkategori
    $sql = "DELETE FROM subkategori WHERE id_subkategori = ?";
    $stmt = $conn->prepare($sql);
    $stmt->execute([$id]);

    if ($stmt->rowCount() > 0) {
        $_SESSION['success'] = "Subkategori berhasil dihapus";
    } else {
        $_SESSION['error'] = "Gagal menghapus subkategori";
    }
    
    header("Location: admin_kategori.php");
    exit;
}
?>