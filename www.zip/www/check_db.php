<?php
require_once 'config.php';

echo "Checking database tables...\n";
$tables = $conn->query('SELECT name FROM sqlite_master WHERE type="table"');
while ($row = $tables->fetch(PDO::FETCH_ASSOC)) {
    echo 'Table: ' . $row['name'] . "\n";
}

echo "\nChecking jurnal table...\n";
$result = $conn->query('SELECT COUNT(*) as count FROM jurnal');
$row = $result->fetch(PDO::FETCH_ASSOC);
echo 'Total journals: ' . $row['count'] . "\n";

if ($row['count'] > 0) {
    $journals = $conn->query('SELECT id_jurnal, nama_jurnal FROM jurnal');
    while ($j = $journals->fetch(PDO::FETCH_ASSOC)) {
        echo 'ID: ' . $j['id_jurnal'] . ' - Name: ' . $j['nama_jurnal'] . "\n";
    }
}
