<?php
require_once 'config.php';

echo 'Checking journal names in database...\n';
try {
    $journals = $conn->query('SELECT id_jurnal, nama_jurnal FROM jurnal');
    echo 'Found journals:\n';
    while ($j = $journals->fetch(PDO::FETCH_ASSOC)) {
        echo 'ID: ' . $j['id_jurnal'] . ' - Name: "' . $j['nama_jurnal'] . '"\n';

        // Check if name contains penerimaan or pengeluaran
        $nama_lower = strtolower($j['nama_jurnal']);
        if (strpos($nama_lower, 'penerimaan') !== false) {
            echo '  -> CONTAINS "penerimaan"\n';
        } elseif (strpos($nama_lower, 'pengeluaran') !== false) {
            echo '  -> CONTAINS "pengeluaran"\n';
        } else {
            echo '  -> DOES NOT contain penerimaan or pengeluaran\n';
        }
    }

    echo '\nChecking transactions for 2025...\n';
    $stmt = $conn->query('SELECT COUNT(*) as total FROM transaksi WHERE strftime(\'%Y\', tanggal) = \'2025\'');
    $result = $stmt->fetch(PDO::FETCH_ASSOC);
    echo 'Total transactions in 2025: ' . $result['total'] . '\n';

    if ($result['total'] > 0) {
        echo '\nSample transactions:\n';
        $sample = $conn->query('SELECT t.id_jurnal, j.nama_jurnal, t.jumlah, t.uraian FROM transaksi t JOIN jurnal j ON t.id_jurnal = j.id_jurnal WHERE strftime(\'%Y\', t.tanggal) = \'2025\' LIMIT 5');
        while ($row = $sample->fetch(PDO::FETCH_ASSOC)) {
            echo 'Journal: ' . $row['nama_jurnal'] . ' - Amount: ' . $row['jumlah'] . ' - Description: ' . $row['uraian'] . '\n';
        }
    }
} catch (Exception $e) {
    echo 'Error: ' . $e->getMessage() . '\n';
}
?>
