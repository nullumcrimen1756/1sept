<?php
// Error reporting untuk development
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Konfigurasi Database SQLite
define('DB_PATH', __DIR__ . '/database/gereja.db');
define('DB_NAME', 'gereja');

// Koneksi ke Database SQLite
try {
    $conn = new PDO('sqlite:' . DB_PATH);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $conn->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
    
    // Enable foreign keys untuk SQLite
    $conn->exec('PRAGMA foreign_keys = ON');
    
} catch (PDOException $e) {
    die("Koneksi database gagal: " . $e->getMessage());
}

// Set timezone
date_default_timezone_set('Asia/Jakarta');

// Base URL Configuration khusus PHP Desktop
function getBaseUrl() {
    // Untuk PHP Desktop, gunakan path lokal
    if (isset($_SERVER['PHP_DESKTOP'])) {
        return 'http://localhost';
    }
    
    // Untuk environment web biasa
    $protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https://' : 'http://';
    $host = $_SERVER['HTTP_HOST'] ?? 'localhost';
    $script = $_SERVER['SCRIPT_NAME'] ?? '';
    $path = dirname($script);

    // Normalisasi path
    $path = str_replace('\\', '/', $path);
    $path = rtrim($path, '/');

    return $protocol . $host . $path;
}

// Set base URL
define('BASE_URL', getBaseUrl());

// Helper function untuk PHP Desktop
function isPhpDesktop() {
    return isset($_SERVER['PHP_DESKTOP']);
}

// Ambil daftar jurnal dari database
$daftar_jurnal = [];
try {
    $sql = "SELECT id_jurnal, kode_jurnal, nama_jurnal FROM jurnal ORDER BY id_jurnal";
    $stmt = $conn->query($sql);
    $result = $stmt->fetchAll();
    
    if ($result) {
        foreach($result as $row) {
            $daftar_jurnal[$row['id_jurnal']] = $row['nama_jurnal'];
        }
    } else {
        // Fallback jika tabel jurnal kosong atau error
        $daftar_jurnal = [
            1 => 'Pengeluaran Jemaat',
            2 => 'Penerimaan Jemaat',
            3 => 'Penerimaan Saldo Bank',
            4 => 'Penerimaan GSG'
        ];
    }
} catch (PDOException $e) {
    // Fallback jika terjadi error
    $daftar_jurnal = [
        1 => 'Pengeluaran Jemaat',
        2 => 'Penerimaan Jemaat',
        3 => 'Penerimaan Saldo Bank',
        4 => 'Penerimaan GSG'
    ];
}
?>