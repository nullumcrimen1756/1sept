$inputFile = "gereja (10).sql"
$outputFile = $inputFile
$content = Get-Content $inputFile -Raw

# Remove MySQL comments
$content = $content -replace '/\*!.*?\*/', ''

# Remove comments
$content = $content -replace '--.*', ''

# Replace int(11) with INTEGER
$content = $content -replace 'int\(11\)', 'INTEGER'

# Replace varchar with TEXT
$content = $content -replace 'varchar\(\d+\)', 'TEXT'

# Replace decimal with REAL
$content = $content -replace 'decimal\(\d+,\d+\)', 'REAL'

# Replace datetime with TEXT
$content = $content -replace 'datetime', 'TEXT'

# Replace timestamp with TEXT
$content = $content -replace 'timestamp', 'TEXT'

# Replace enum with TEXT
$content = $content -replace 'enum\([^)]+\)', 'TEXT'

# Remove ENGINE=InnoDB
$content = $content -replace 'ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci', ''

# Remove AUTO_INCREMENT
$content = $content -replace 'AUTO_INCREMENT', ''

# Remove DEFAULT CHARSET
$content = $content -replace 'DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci', ''

# Remove the COMMIT
$content = $content -replace 'COMMIT;', ''

# Remove the SET statements
$content = $content -replace 'SET SQL_MODE.*;', ''
$content = $content -replace 'START TRANSACTION;', ''
$content = $content -replace 'SET time_zone.*;', ''
$content = $content -replace '/\*!40101 SET.*\*/', ''
$content = $content -replace 'SET @OLD_CHARACTER_SET_CLIENT.*;', ''
$content = $content -replace 'SET @OLD_CHARACTER_SET_RESULTS.*;', ''
$content = $content -replace 'SET @OLD_COLLATION_CONNECTION.*;', ''
$content = $content -replace 'SET NAMES utf8mb4;', ''
$content = $content -replace 'COMMIT;', ''

# Remove the indexes and constraints section
$content = $content -replace '--\s*Indexes for dumped tables\s*--.*', ''

# Write to output file
$content | Out-File $outputFile -Encoding UTF8
