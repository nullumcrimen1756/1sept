import re

with open('gereja (10).sql', 'r', encoding='utf-8') as f:
    content = f.read()

# Remove MySQL comments
content = re.sub(r'/\*!.*?\*/', '', content, flags=re.DOTALL)

# Replace int(11) with INTEGER
content = re.sub(r'\bint\(11\)\b', 'INTEGER', content)

# Replace varchar with TEXT
content = re.sub(r'\bvarchar\(\d+\)\b', 'TEXT', content)

# Replace decimal with REAL
content = re.sub(r'\bdecimal\(\d+,\d+\)\b', 'REAL', content)

# Replace datetime with TEXT
content = re.sub(r'\bdatetime\b', 'TEXT', content)

# Replace timestamp with TEXT
content = re.sub(r'\btimestamp\b', 'TEXT', content)

# Replace enum with TEXT
content = re.sub(r'\benum\([^)]+\)\b', 'TEXT', content)

# Remove ENGINE=InnoDB
content = re.sub(r'ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci', '', content)

# Change AUTO_INCREMENT to AUTOINCREMENT
content = re.sub(r'AUTO_INCREMENT', 'AUTOINCREMENT', content)

# Remove DEFAULT CHARSET
content = re.sub(r'DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci', '', content)

# Remove the COMMIT
content = re.sub(r'COMMIT;', '', content)

# Remove the SET statements
content = re.sub(r'SET SQL_MODE.*;', '', content)
content = re.sub(r'START TRANSACTION;', '', content)
content = re.sub(r'SET time_zone.*;', '', content)
content = re.sub(r'/\*!40101 SET.*\*/', '', content)
content = re.sub(r'SET @OLD_CHARACTER_SET_CLIENT.*;', '', content)
content = re.sub(r'SET @OLD_CHARACTER_SET_RESULTS.*;', '', content)
content = re.sub(r'SET @OLD_COLLATION_CONNECTION.*;', '', content)
content = re.sub(r'SET NAMES utf8mb4;', '', content)
content = re.sub(r'COMMIT;', '', content)

# Write back to the file
with open('gereja (10).sql', 'w', encoding='utf-8') as f:
    f.write(content)

print("File converted to SQLite format.")
