-- Buat tabel anggaran_pendapatan
CREATE TABLE IF NOT EXISTS `anggaran_pendapatan` (
    `id` INT PRIMARY KEY AUTO_INCREMENT,
    `kode_subkategori` VARCHAR(50),
    `bulan` VARCHAR(20) NOT NULL,
    `jumlah` DECIMAL(15,2) NOT NULL DEFAULT 0.00,
    `type` ENUM('uang-setoran', 'kelompok', 'subkategori', 'keseluruhan') NOT NULL,
    UNIQUE KEY `unique_anggaran` (`kode_subkategori`, `bulan`, `type`)
);

-- Insert contoh data anggaran
INSERT INTO `anggaran_pendapatan` (`kode_subkategori`, `bulan`, `jumlah`, `type`) VALUES
('100.01.01', 'All', 1000000.00, 'subkategori'),
('100.01.02', 'All', 800000.00, 'subkategori'),
('100', 'All', 1800000.00, 'kelompok'),
('UANG_SETORAN', 'All', 500000.00, 'uang-setoran'),
('TOTAL_KESELURUHAN', 'All', 5000000.00, 'keseluruhan');

-- Tampilkan data yang sudah diinsert
SELECT * FROM `anggaran_pendapatan`;
