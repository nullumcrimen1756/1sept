import sqlite3

conn = sqlite3.connect('gereja.db')

with open('gereja_sqlite.sql', 'r', encoding='utf-8') as f:
    sql = f.read()

conn.executescript(sql)

conn.commit()

conn.close()

print("Database gereja.db created successfully.")
