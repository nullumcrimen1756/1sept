import sqlite3

conn = sqlite3.connect('gereja_new.db')

with open('gereja_sqlite_new.sql', 'r', encoding='utf-8') as f:
    sql = f.read()

conn.executescript(sql)

conn.commit()

conn.close()

print("Database gereja_new.db created successfully.")
