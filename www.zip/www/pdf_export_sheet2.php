<?php
session_start();
require_once 'lib/dompdf/autoload.inc.php';
use Dompdf\Dompdf;

if (!isset($_SESSION['sheet2_report']) || empty($_SESSION['sheet2_report'])) {
    die("Tidak ada data laporan untuk diexport.");
}

$report = $_SESSION['sheet2_report'];
require_once 'config.php';

$selected_jurnal_filter = isset($_GET['jurnal_filter']) ? $_GET['jurnal_filter'] : '';
$selected_tahun_filter = isset($_GET['tahun_filter']) ? $_GET['tahun_filter'] : date('Y');
$search_keyword = isset($_GET['search']) ? trim($_GET['search']) : '';

if ($selected_jurnal_filter && isset($daftar_jurnal[$selected_jurnal_filter])) {
    $selected_jurnal_name = $daftar_jurnal[$selected_jurnal_filter];
    if (isset($report[$selected_jurnal_name])) {
        $report = [$selected_jurnal_name => $report[$selected_jurnal_name]];
    } else {
        $report = [];
    }
}

if (!empty($search_keyword)) {
    $filtered_report = [];
    foreach ($report as $jurnal => $bulan_data) {
        $filtered_bulan_data = [];
        foreach ($bulan_data as $bulan => $subkategori_data) {
            $filtered_subkategori_data = [];
            foreach ($subkategori_data as $subkategori => $data) {
                $filtered_transactions = [];
                foreach ($data['transactions'] as $trans) {
                    if (stripos($trans['no_kwitansi'], $search_keyword) !== false || 
                        stripos($trans['uraian'], $search_keyword) !== false) {
                        $filtered_transactions[] = $trans;
                    }
                }
                if (!empty($filtered_transactions)) {
                    $filtered_subkategori_data[$subkategori] = [
                        'kategori' => $data['kategori'],
                        'transactions' => $filtered_transactions,
                        'total' => array_sum(array_column($filtered_transactions, 'jumlah'))
                    ];
                }
            }
            if (!empty($filtered_subkategori_data)) {
                $filtered_bulan_data[$bulan] = $filtered_subkategori_data;
            }
        }
        if (!empty($filtered_bulan_data)) {
            $filtered_report[$jurnal] = $filtered_bulan_data;
        }
    }
    $report = $filtered_report;
}

function formatRupiahExport($number) {
    return number_format($number, 0, ',', '');
}

ob_start();
?>
<html>
<head>
    <meta charset="UTF-8">
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 8px;
            font-size: 7pt;
            line-height: 1.1;
        }
        .header { text-align: center; margin-bottom: 10px; }
        .title { font-size: 12pt; font-weight: bold; color: #1F4E78; margin-bottom: 2px; }
        .subtitle { font-size: 9pt; color: #2F75B5; margin-bottom: 8px; }
        .data-table {
            border-collapse: collapse;
            margin-bottom: 10px;
            font-size: 6pt;
            width: 100%;
            table-layout: auto;
        }
        .data-table th {
            background-color: #2c3e50;
            color: white;
            font-weight: bold;
            padding: 3px 2px;
            border: 1px solid #000;
            text-align: center;
            font-size: 6pt;
            word-wrap: break-word;
            min-width: 35px;
            max-width: 50px;
        }
        .data-table td {
            padding: 2px 1px;
            border: 1px solid #BFBFBF;
            text-align: left;
            vertical-align: top;
            font-size: 6pt;
            word-wrap: break-word;
            overflow: hidden;
        }
        .data-table th:first-child { min-width: 80px; max-width: 120px; }
        .data-table td:first-child { min-width: 80px; max-width: 120px; }
        .number-cell { text-align: right; font-size: 6pt; }
        .date-cell { text-align: center; font-size: 6pt; }
        .jurnal-header {
            font-size: 10pt;
            font-weight: bold;
            color: #2F75B5;
            margin: 15px 0 8px 0;
            padding-bottom: 3px;
            border-bottom: 1px solid #2F75B5;
            page-break-after: avoid;
        }
        .subkategori-header {
            font-size: 8pt;
            font-weight: bold;
            color: #823535;
            background-color: #FCE4D6;
            padding: 2px;
            margin: 5px 0 3px 0;
        }
        .total-row { background-color: #d9e1f2; font-weight: bold; font-size: 6pt; }
        .footer {
            margin-top: 10px;
            font-style: italic;
            color: #666;
            text-align: right;
            font-size: 6pt;
        }
        .page-break { page-break-before: always; }
        @page { margin: 0.3in; }
        .month-header th { writing-mode: horizontal-tb; }
    </style>
</head>
<body>
    <div class="header">
        <div class="title">LAPORAN TERSTRUKTUR HORIZONTAL (SHEET 2)</div>
        <div class="subtitle">LAYOUT PER BULAN KE SAMPING - TAHUN <?= $selected_tahun_filter ?></div>
        <?php if ($selected_jurnal_filter && isset($daftar_jurnal[$selected_jurnal_filter])): ?>
            <p>Jurnal: <?= htmlspecialchars($daftar_jurnal[$selected_jurnal_filter]) ?></p>
        <?php endif; ?>
    </div>

    <?php if (!empty($report)): ?>
        <?php foreach ($report as $jurnal => $bulan_data): ?>
            <div class="jurnal-header">JURNAL: <?= htmlspecialchars($jurnal) ?></div>
            
            <?php
            $sorted_months = [];
            foreach ($bulan_data as $bulan => $subkategori_data) {
                $month_number = date('m', strtotime("1 $bulan"));
                $sorted_months[$month_number] = $bulan;
            }
            ksort($sorted_months);

            $all_subkategori = [];
            foreach ($bulan_data as $bulan => $subkategori_data) {
                foreach ($subkategori_data as $subkategori => $data) {
                    if (!in_array($subkategori, $all_subkategori)) {
                        $all_subkategori[] = $subkategori;
                    }
                }
            }

            // Split months into groups of 2 for pagination
            $month_groups = array_chunk($sorted_months, 2, true);
            $page_number = 1;

            foreach ($month_groups as $month_group):
                if ($page_number > 1): ?>
                    <div class="page-break"></div>
                <?php endif; ?>

                <table class="data-table" style="width: 100%;">
                    <thead>
                        <tr>
                            <th style="writing-mode: horizontal-tb; min-width: 200px;">Subkategori</th>
                            <?php foreach ($month_group as $month_number => $bulan): ?>
                                <th colspan="4"><?= strtoupper($bulan) ?></th>
                            <?php endforeach; ?>
                        </tr>
                        <tr>
                            <th style="writing-mode: horizontal-tb;">Kategori / Uraian</th>
                            <?php foreach ($month_group as $month_number => $bulan): ?>
                                <th>Tanggal</th>
                                <th>No. Kwitansi</th>
                                <th>Uraian</th>
                                <th>Jumlah</th>
                            <?php endforeach; ?>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($all_subkategori as $subkategori): ?>
                            <?php
                            $subkategori_found = false;
                            foreach ($month_group as $month_number => $bulan) {
                                if (isset($bulan_data[$bulan][$subkategori])) {
                                    $subkategori_found = true;
                                    break;
                                }
                            }
                            if (!$subkategori_found) continue;

                            $kategori = '';
                            foreach ($month_group as $month_number => $bulan) {
                                if (isset($bulan_data[$bulan][$subkategori])) {
                                    $kategori = $bulan_data[$bulan][$subkategori]['kategori'];
                                    break;
                                }
                            }
                            ?>

                            <tr class="subkategori-header">
                                <td><strong><?= htmlspecialchars($subkategori) ?></strong><br>
                                    <small>(<?= htmlspecialchars($kategori) ?>)</small>
                                </td>
                                <?php foreach ($month_group as $month_number => $bulan): ?>
                                    <td colspan="4" style="text-align: center; font-weight: bold;">
                                        <?php if (isset($bulan_data[$bulan][$subkategori])): ?>
                                            <?= count($bulan_data[$bulan][$subkategori]['transactions']) ?> transaksi
                                        <?php else: ?>
                                            -
                                        <?php endif; ?>
                                    </td>
                                <?php endforeach; ?>
                            </tr>

                            <?php
                            $max_transactions = 0;
                            foreach ($month_group as $month_number => $bulan) {
                                if (isset($bulan_data[$bulan][$subkategori])) {
                                    $count = count($bulan_data[$bulan][$subkategori]['transactions']);
                                    if ($count > $max_transactions) {
                                        $max_transactions = $count;
                                    }
                                }
                            }
                            ?>

                            <?php for ($i = 0; $i < $max_transactions; $i++): ?>
                                <tr>
                                    <td><?= $i == 0 ? 'Transaksi:' : '' ?></td>
                                    <?php foreach ($month_group as $month_number => $bulan): ?>
                                        <?php
                                        $trans = null;
                                        if (isset($bulan_data[$bulan][$subkategori]['transactions'][$i])) {
                                            $trans = $bulan_data[$bulan][$subkategori]['transactions'][$i];
                                        }
                                        ?>
                                        <td class="date-cell"><?= $trans ? date('d/m', strtotime($trans['tanggal'])) : '' ?></td>
                                        <td><?= $trans ? htmlspecialchars($trans['no_kwitansi']) : '' ?></td>
                                        <td><?= $trans ? htmlspecialchars(substr($trans['uraian'], 0, 30)) : '' ?></td>
                                        <td class="number-cell"><?= $trans ? number_format($trans['jumlah'], 0, ',', '') : '' ?></td>
                                    <?php endforeach; ?>
                                </tr>
                            <?php endfor; ?>

                            <tr class="total-row">
                                <td>Total:</td>
                                <?php foreach ($month_group as $month_number => $bulan): ?>
                                    <?php if (isset($bulan_data[$bulan][$subkategori])): ?>
                                        <td colspan="3" style="text-align: right;"><?= htmlspecialchars($subkategori) ?>:</td>
                                        <td class="number-cell"><?= number_format($bulan_data[$bulan][$subkategori]['total'], 0, ',', '') ?></td>
                                    <?php else: ?>
                                        <td colspan="4"></td>
                                    <?php endif; ?>
                                <?php endforeach; ?>
                            </tr>

                        <?php endforeach; ?>
                    </tbody>
                </table>

                <?php $page_number++; ?>
            <?php endforeach; ?>
            
        <?php endforeach; ?>
    <?php else: ?>
        <div style="color: #FF0000; font-weight: bold; text-align: center; margin: 30px 0;">
            Tidak ada data yang cocok dengan filter yang dipilih.
        </div>
    <?php endif; ?>

    <div style="margin-top: 20px; font-style: italic; color: #666; text-align: right;">
        Dokumen ini dihasilkan secara otomatis pada <?= date('d F Y H:i:s') ?> dari Sistem Laporan Keuangan
    </div>
</body>
</html>
<?php
$html = ob_get_clean();

$dompdf = new Dompdf();
$dompdf->loadHtml($html);
$dompdf->setPaper('A4', 'landscape');

// Configure DomPDF for better table handling
$dompdf->set_option('isHtml5ParserEnabled', true);
$dompdf->set_option('isRemoteEnabled', false);
$dompdf->set_option('defaultFont', 'Arial');
$dompdf->set_option('dpi', 96);
$dompdf->set_option('fontHeightRatio', 1.0);

$dompdf->render();
$dompdf->stream("Sheet2_Horizontal_" . date('Ymd_His') . ".pdf", ["Attachment" => false]);
exit;
?>
