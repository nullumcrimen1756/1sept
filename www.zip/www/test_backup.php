<?php
echo "Testing backup script...\n";

require_once 'config.php';

echo "Config loaded\n";

if ($conn->connect_error) {
    echo "Connection failed: " . $conn->connect_error . "\n";
    exit;
}

echo "Database connected successfully\n";

// Test query
$result = $conn->query("SELECT COUNT(*) as count FROM transaksi");
if ($result) {
    $row = $result->fetch_assoc();
    echo "Total transaksi records: " . $row['count'] . "\n";
} else {
    echo "Query failed: " . $conn->error . "\n";
}

echo "Test completed\n";
?>
