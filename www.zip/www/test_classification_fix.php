<?php
require_once 'config.php';
require_once 'functions.php';

echo "=== Testing Transaction Classification Fix ===\n\n";

// Test journal classification
$sql_jurnal = "SELECT id_jurnal, nama_jurnal FROM jurnal";
$result_jurnal = $conn->query($sql_jurnal);
$jurnal_penerimaan = [];
$jurnal_pengeluaran = [];

    if ($result_jurnal && $result_jurnal->rowCount() > 0) {
        $jurnal_rows = $result_jurnal->fetchAll(PDO::FETCH_ASSOC);
        echo "Journal Classification:\n";

        foreach ($jurnal_rows as $row) {
            $nama = strtolower($row['nama_jurnal']);
            $id_jurnal = (int)$row['id_jurnal']; // Ensure integer type
            echo "Journal: '" . $row['nama_jurnal'] . "' (ID: " . $id_jurnal . ") - Type: " . gettype($id_jurnal) . "\n";

            if (strpos($nama, 'penerimaan') !== false) {
                $jurnal_penerimaan[] = $id_jurnal;
                echo "  -> Classified as PENERIMAAN - Adding ID: " . $id_jurnal . "\n";
            } elseif (strpos($nama, 'pengeluaran') !== false) {
                $jurnal_pengeluaran[] = $id_jurnal;
                echo "  -> Classified as PENGELUARAN - Adding ID: " . $id_jurnal . "\n";
            } else {
                echo "  -> NOT CLASSIFIED (no 'penerimaan' or 'pengeluaran' in name)\n";
            }
        }
    } else {
        echo "ERROR: No journals found in database!\n";
    }

$jurnal_penerimaan = array_unique(array_map('intval', $jurnal_penerimaan));
$jurnal_pengeluaran = array_unique(array_map('intval', $jurnal_pengeluaran));

echo "\nFinal classification arrays:\n";
echo "Penerimaan: [" . implode(',', $jurnal_penerimaan) . "]\n";
echo "Pengeluaran: [" . implode(',', $jurnal_pengeluaran) . "]\n\n";

// Test with sample transactions
echo "=== Testing Sample Transactions ===\n";
$sql = "SELECT
    strftime('%Y-%m', t.tanggal) as bulan,
    t.tanggal,
    t.uraian,
    t.no_kwitansi,
    t.jumlah,
    j.id_jurnal,
    j.nama_jurnal
FROM transaksi t
JOIN jurnal j ON t.id_jurnal = j.id_jurnal
WHERE strftime('%Y', t.tanggal) = '2025'
ORDER BY t.tanggal ASC
LIMIT 10";

$stmt = $conn->prepare($sql);
$stmt->execute();
$result = $stmt->fetchAll(PDO::FETCH_ASSOC);

echo "Found " . count($result) . " sample transactions for 2025:\n\n";

foreach ($result as $row) {
    echo "Transaction: " . $row['no_kwitansi'] . " - " . $row['nama_jurnal'] . " (ID: " . $row['id_jurnal'] . ") - Amount: " . $row['jumlah'] . "\n";

    $id_jurnal_int = (int)$row['id_jurnal'];

    if (in_array($id_jurnal_int, $jurnal_penerimaan, true)) {
        echo "  -> CLASSIFIED AS PENERIMAAN (strict comparison)\n";
    } elseif (in_array($id_jurnal_int, $jurnal_pengeluaran, true)) {
        echo "  -> CLASSIFIED AS PENGELUARAN (strict comparison)\n";
    } else {
        echo "  -> NOT CLASSIFIED\n";
    }
    echo "\n";
}

echo "=== Test Complete ===\n";
?>
