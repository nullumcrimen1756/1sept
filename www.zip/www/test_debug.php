<?php
require_once 'config.php';
require_once 'functions.php';

echo "Testing generateLaporanKeuangan function...\n\n";

// Test for year 2025
$report_data = generateLaporanKeuangan(2025);

echo "Report data for 2025:\n";
if (empty($report_data)) {
    echo "No data found!\n";
} else {
    echo "Found " . count($report_data) . " months of data:\n";
    foreach ($report_data as $month => $data) {
        echo "- " . $month . ": " . count($data['penerimaan']) . " penerimaan, " . count($data['pengeluaran']) . " pengeluaran\n";
    }
}

// Test database connection
echo "\nDatabase connection test:\n";
try {
    $stmt = $conn->query("SELECT COUNT(*) as total FROM transaksi WHERE strftime('%Y', tanggal) = '2025'");
    $result = $stmt->fetch(PDO::FETCH_ASSOC);
    echo "Total transactions in 2025: " . $result['total'] . "\n";
} catch (Exception $e) {
    echo "Database error: " . $e->getMessage() . "\n";
}
?>
