<?php
require_once 'config.php';
require_once 'functions.php';

echo "=== COMPREHENSIVE FINANCIAL REPORT TEST ===\n\n";

// Test 1: Database connectivity and data verification
echo "1. DATABASE VERIFICATION:\n";
try {
    $stmt = $conn->query('SELECT COUNT(*) as total FROM transaksi WHERE strftime(\'%Y\', tanggal) = \'2025\'');
    $result = $stmt->fetch(PDO::FETCH_ASSOC);
    echo "✓ Total transactions in 2025: " . $result['total'] . "\n";

    if ($result['total'] > 0) {
        echo "✓ Sample transactions:\n";
        $sample = $conn->query('SELECT t.id_jurnal, j.nama_jurnal, t.jumlah, t.uraian, t.tanggal FROM transaksi t JOIN jurnal j ON t.id_jurnal = j.id_jurnal WHERE strftime(\'%Y\', t.tanggal) = \'2025\' LIMIT 10');
        while ($row = $sample->fetch(PDO::FETCH_ASSOC)) {
            echo "  - " . $row['nama_jurnal'] . " (ID: " . $row['id_jurnal'] . ") - " . $row['jumlah'] . " - " . $row['uraian'] . "\n";
        }
    }
} catch (Exception $e) {
    echo "✗ Database error: " . $e->getMessage() . "\n";
}

// Test 2: Journal classification verification
echo "\n2. JOURNAL CLASSIFICATION:\n";
try {
    $journals = $conn->query('SELECT id_jurnal, nama_jurnal FROM jurnal');
    $jurnal_penerimaan = [];
    $jurnal_pengeluaran = [];

    while ($j = $journals->fetch(PDO::FETCH_ASSOC)) {
        $nama_lower = strtolower($j['nama_jurnal']);
        if (strpos($nama_lower, 'penerimaan') !== false) {
            $jurnal_penerimaan[] = (int)$j['id_jurnal'];
            echo "✓ PENERIMAAN: " . $j['nama_jurnal'] . " (ID: " . $j['id_jurnal'] . ")\n";
        } elseif (strpos($nama_lower, 'pengeluaran') !== false) {
            $jurnal_pengeluaran[] = (int)$j['id_jurnal'];
            echo "✓ PENGELUARAN: " . $j['nama_jurnal'] . " (ID: " . $j['id_jurnal'] . ")\n";
        } else {
            echo "? UNCLASSIFIED: " . $j['nama_jurnal'] . " (ID: " . $j['id_jurnal'] . ")\n";
        }
    }

    echo "\nClassification arrays:\n";
    echo "Penerimaan IDs: [" . implode(',', $jurnal_penerimaan) . "]\n";
    echo "Pengeluaran IDs: [" . implode(',', $jurnal_pengeluaran) . "]\n";

} catch (Exception $e) {
    echo "✗ Journal classification error: " . $e->getMessage() . "\n";
}

// Test 3: Function execution with detailed logging
echo "\n3. FUNCTION EXECUTION TEST:\n";
try {
    // Enable error logging to capture debug output
    ini_set('log_errors', 1);
    ini_set('error_log', 'php_error.log');

    echo "Calling generateLaporanKeuangan(2025)...\n";
    $report_data = generateLaporanKeuangan(2025);

    echo "\nFunction returned:\n";
    if (empty($report_data)) {
        echo "✗ No data returned from function!\n";
    } else {
        echo "✓ Function returned " . count($report_data) . " months of data:\n";
        foreach ($report_data as $month => $data) {
            $penerimaan_count = count($data['penerimaan']);
            $pengeluaran_count = count($data['pengeluaran']);
            $total_penerimaan = $data['total_penerimaan'] ?? 0;
            $total_pengeluaran = $data['total_pengeluaran'] ?? 0;

            echo "  - $month: $penerimaan_count penerimaan (total: $total_penerimaan), $pengeluaran_count pengeluaran (total: $total_pengeluaran)\n";

            if ($penerimaan_count > 0) {
                echo "    Sample penerimaan:\n";
                foreach (array_slice($data['penerimaan'], 0, 2) as $item) {
                    echo "      - " . $item['nama_jurnal'] . ": " . $item['jumlah'] . " (" . $item['uraian'] . ")\n";
                }
            }

            if ($pengeluaran_count > 0) {
                echo "    Sample pengeluaran:\n";
                foreach (array_slice($data['pengeluaran'], 0, 2) as $item) {
                    echo "      - " . $item['nama_jurnal'] . ": " . $item['jumlah'] . " (" . $item['uraian'] . ")\n";
                }
            }
        }
    }

} catch (Exception $e) {
    echo "✗ Function execution error: " . $e->getMessage() . "\n";
}

// Test 4: Direct SQL query test
echo "\n4. DIRECT SQL VERIFICATION:\n";
try {
    $sql = "SELECT
                strftime('%Y-%m', t.tanggal) as bulan,
                t.tanggal,
                t.uraian,
                t.no_kwitansi,
                t.jumlah,
                j.id_jurnal,
                j.nama_jurnal,
                k.kode_kategori
            FROM transaksi t
            JOIN jurnal j ON t.id_jurnal = j.id_jurnal
            LEFT JOIN subkategori s ON t.id_subkategori = s.id_subkategori
            LEFT JOIN kategori k ON s.id_kategori = k.id_kategori
            WHERE strftime('%Y', t.tanggal) = '2025'
            ORDER BY t.tanggal ASC";

    $stmt = $conn->prepare($sql);
    $stmt->execute();
    $transactions = $stmt->fetchAll(PDO::FETCH_ASSOC);

    echo "✓ Direct SQL query returned " . count($transactions) . " transactions\n";

    $manual_penerimaan = [];
    $manual_pengeluaran = [];
    $manual_totals = ['penerimaan' => 0, 'pengeluaran' => 0];

    foreach ($transactions as $row) {
        $nama_lower = strtolower($row['nama_jurnal']);
        if (strpos($nama_lower, 'penerimaan') !== false) {
            $manual_penerimaan[] = $row;
            $manual_totals['penerimaan'] += $row['jumlah'];
        } elseif (strpos($nama_lower, 'pengeluaran') !== false) {
            $manual_pengeluaran[] = $row;
            $manual_totals['pengeluaran'] += $row['jumlah'];
        }
    }

    echo "Manual classification results:\n";
    echo "  - Penerimaan: " . count($manual_penerimaan) . " transactions, total: " . $manual_totals['penerimaan'] . "\n";
    echo "  - Pengeluaran: " . count($manual_pengeluaran) . " transactions, total: " . $manual_totals['pengeluaran'] . "\n";

    if (count($manual_penerimaan) > 0) {
        echo "  Sample penerimaan:\n";
        foreach (array_slice($manual_penerimaan, 0, 3) as $item) {
            echo "    - " . $item['nama_jurnal'] . ": " . $item['jumlah'] . "\n";
        }
    }

    if (count($manual_pengeluaran) > 0) {
        echo "  Sample pengeluaran:\n";
        foreach (array_slice($manual_pengeluaran, 0, 3) as $item) {
            echo "    - " . $item['nama_jurnal'] . ": " . $item['jumlah'] . "\n";
        }
    }

} catch (Exception $e) {
    echo "✗ Direct SQL error: " . $e->getMessage() . "\n";
}

echo "\n=== TEST COMPLETE ===\n";
?>
