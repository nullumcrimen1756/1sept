<?php

// Debug: Tampilkan data jurnal
// echo "<pre style='background:#fff;padding:20px;border:2px solid red;z-index:9999;position:relative'>";
// echo "DEBUG DATA JURNAL:\n";
// print_r($jurnals);
// echo "Jumlah Jurnal: " . count($jurnals) . "\n";
// echo "Query: SELECT * FROM jurnal ORDER BY nama_jurnal\n";
// echo "Error: " . $conn->error . "\n";
// echo "</pre>";
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manajemen Kategori</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <style>
        :root {
            --primary-color: #2c3e50;
            --secondary-color: #3498db;
            --accent-color: #e74c3c;
            --light-bg: #f8f9fa;
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: var(--light-bg);
        }
        
        .card-container {
            border-radius: 10px;
            box-shadow: 0 4px 20px rgba(0,0,0,0.08);
            border: none;
        }
        
        .card-header {
            background-color: var(--primary-color);
            color: white;
            border-radius: 10px 10px 0 0 !important;
            padding: 15px 20px;
        }
        
        .jurnal-filter {
            background-color: white;
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 20px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
        }
        
        .section-title {
            font-weight: 600;
            color: var(--primary-color);
            border-bottom: 2px solid var(--primary-color);
            padding-bottom: 8px;
            margin-bottom: 15px;
        }
        
        .table th {
            background-color: var(--primary-color);
            color: white;
        }
        
        .btn-add {
            background-color: var(--secondary-color);
            color: white;
        }
        
        .btn-add:hover {
            background-color: #2980b9;
        }
        
        .btn-delete {
            background-color: var(--accent-color);
            color: white;
        }
        
        .btn-delete:hover {
            background-color: #c0392b;
        }
        
        .badge-jurnal {
            background-color: var(--secondary-color);
        }
    </style>
</head>
<body>
    <div class="container py-5">
        <div class="card card-container">
            <div class="card-header">
                <h4 class="mb-0"><i class="bi bi-tags me-2"></i>Manajemen Kategori dan Subkategori</h4>
            </div>
            
            <div class="card-body">
                <?php if (isset($_SESSION['success'])): ?>
                    <div class="alert alert-success alert-dismissible fade show">
                        <?php echo $_SESSION['success']; unset($_SESSION['success']); ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    </div>
                <?php endif; ?>
                
                <?php if (isset($_SESSION['error'])): ?>
                    <div class="alert alert-danger alert-dismissible fade show">
                        <?php echo $_SESSION['error']; unset($_SESSION['error']); ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    </div>
                <?php endif; ?>
                                
                <!-- Filter Jurnal -->
                <div class="jurnal-filter mb-4">
                    <form method="get" action="admin_kategori.php">
                        <input type="hidden" name="action" value="list">
                        <div class="row align-items-center">
                            <div class="col-md-6 mb-2">
                            <label for="jurnalDropdown" class="form-label">Filter Berdasarkan Jurnal:</label>
								<select id="jurnalDropdown" name="id_jurnal" class="form-select" onchange="filterByJurnal()">
									<option value="">Semua Jurnal</option>
									<?php if (!empty($jurnals) && is_array($jurnals)): ?>
										<?php foreach ($jurnals as $jurnal): ?>
											<?php if (isset($jurnal['id_jurnal']) && isset($jurnal['kode_jurnal']) && isset($jurnal['nama_jurnal'])): ?>
												<option value="<?= $jurnal['id_jurnal'] ?>" 
													<?= (isset($selected_jurnal_id) && $selected_jurnal_id == $jurnal['id_jurnal']) ? 'selected' : '' ?>>
													<?= htmlspecialchars($jurnal['kode_jurnal']) ?> - <?= htmlspecialchars($jurnal['nama_jurnal']) ?>
												</option>
											<?php endif; ?>
										<?php endforeach; ?>
									<?php else: ?>
										<option value="">Data Jurnal Tidak Tersedia</option>
									<?php endif; ?>
								</select>
                            </div>
                            <div class="col-md-4 mb-2">
                                <button type="submit" class="btn btn-primary">
                                    <i class="bi bi-funnel me-1"></i> Filter
                                </button>
                                <?php if (isset($_GET['id_jurnal'])): ?>
                                    <a href="admin_kategori.php?action=list" class="btn btn-outline-secondary">
                                        <i class="bi bi-x-circle me-1"></i> Reset
                                    </a>
                                <?php endif; ?>
                            </div>
                        </div>
                    </form>
                </div>
                                
                <!-- Daftar Kategori -->
                <div class="mb-5">
                    <div class="d-flex justify-content-between align-items-center mb-3">
                        <h5 class="section-title">
                            <i class="bi bi-list-ul me-2"></i>Daftar Kategori
                        </h5>
                        <a href="admin_kategori.php?action=add_kategori<?php echo isset($_GET['id_jurnal']) ? '&id_jurnal='.$_GET['id_jurnal'] : ''; ?>" 
                           class="btn btn-add">
                            <i class="bi bi-plus-circle me-1"></i>Tambah Kategori
                        </a>
                    </div>
                    
                    <?php if (empty($kategori)): ?>
                        <div class="alert alert-info">
                            <i class="bi bi-info-circle me-2"></i>Belum ada data kategori
                        </div>
                    <?php else: ?>
                        <div class="table-responsive">
								<table id="kategoriTable" class="table table-hover">
									<thead>
										<tr>
											<th>Kode</th>
											<th>Nama Kategori</th>
											<th>Jurnal</th>
											<th>Aksi</th>
										</tr>
									</thead>
                                    <tbody>
                                    <?php foreach ($kategori as $kat): ?>
                                        <tr>
                                            <td><?php echo htmlspecialchars($kat['kode_kategori']); ?></td>
                                            <td><?php echo htmlspecialchars($kat['nama_kategori']); ?></td>
                                            <td>
                                                <?php 
                                                $jurnal_name = '';
                                                foreach ($jurnals as $jurnal) {
                                                    if ($jurnal['id_jurnal'] == $kat['id_jurnal']) {
                                                        $jurnal_name = $jurnal['nama_jurnal'];
                                                        break;
                                                    }
                                                }
                                                echo '<span class="badge badge-jurnal bg-primary">'.htmlspecialchars($jurnal_name).'</span>';
                                                ?>
                                            </td>
                                            <td>
                                                <a href="admin_kategori.php?action=delete_kategori&id=<?php echo $kat['id_kategori']; ?>" 
                                                   class="btn btn-sm btn-delete"
                                                   onclick="return confirm('Yakin ingin menghapus kategori ini? Semua subkategori terkait juga akan dihapus.')">
                                                    <i class="bi bi-trash me-1"></i>Hapus
                                                </a>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php endif; ?>
                </div>
                
                <!-- Daftar Subkategori -->
                <div class="mb-3">
                    <div class="d-flex justify-content-between align-items-center mb-3">
                        <h5 class="section-title">
                            <i class="bi bi-list-nested me-2"></i>Daftar Subkategori
                        </h5>
                        <a href="admin_kategori.php?action=add_subkategori<?php echo isset($_GET['id_jurnal']) ? '&id_jurnal='.$_GET['id_jurnal'] : ''; ?>" 
                           class="btn btn-add">
                            <i class="bi bi-plus-circle me-1"></i>Tambah Subkategori
                        </a>
                    </div>
                    
                    <?php if (empty($subkategori)): ?>
                        <div class="alert alert-info">
                            <i class="bi bi-info-circle me-2"></i>Belum ada data subkategori
                        </div>
                    <?php else: ?>
                        <div class="table-responsive">
								<table id="subkategoriTable" class="table table-hover">
									<thead>
										<tr>
											<th>Kode</th>
											<th>Nama Subkategori</th>
											<th>Kategori</th>
											<th>Jurnal</th>
											<th>Aksi</th>
										</tr>
									</thead>
                                    <tbody>
                                    <?php foreach ($subkategori as $sub): ?>
                                        <tr>
                                            <td><?php echo htmlspecialchars($sub['kode_subkategori']); ?></td>
                                            <td><?php echo htmlspecialchars($sub['nama_subkategori']); ?></td>
                                            <td><?php echo htmlspecialchars($sub['nama_kategori']); ?></td>
                                            <td>
                                                <span class="badge badge-jurnal bg-primary"><?php echo htmlspecialchars($sub['nama_jurnal']); ?></span>
                                            </td>
                                            <td>
                                                <a href="admin_kategori.php?action=delete_subkategori&id=<?php echo $sub['id_subkategori']; ?>" 
                                                   class="btn btn-sm btn-delete"
                                                   onclick="return confirm('Yakin ingin menghapus subkategori ini?')">
                                                    <i class="bi bi-trash me-1"></i>Hapus
                                                </a>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
			</div>
		</div>

		<script>
		function filterByJurnal() {
			const jurnalId = document.getElementById('jurnalDropdown').value;
			if (jurnalId) {
				window.location.href = 'admin_kategori.php?id_jurnal=' + encodeURIComponent(jurnalId);
			} else {
				window.location.href = 'admin_kategori.php';
			}
		}
		</script>
		<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
	</body>
</html> 