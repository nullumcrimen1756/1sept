<?php
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../functions.php';

if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Jika belum login, redirect ke halaman login
if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
    header("Location: login.php");
    exit;
}

// Set judul halaman
$page_title = "Dashboard - Sistem Keuangan Gereja";

// Ambil parameter filter
$selected_year = isset($_GET['tahun']) ? intval($_GET['tahun']) : date('Y');
$selected_jurnal = isset($_GET['jurnal']) ? intval($_GET['jurnal']) : null;

// Query untuk mendapatkan daftar jurnal
$query_jurnal = "SELECT id_jurnal, nama_jurnal FROM jurnal ORDER BY id_jurnal";
$jurnal_result = $conn->query($query_jurnal);

$daftar_jurnal = [];
if ($jurnal_result->num_rows > 0) {
    while($row = $jurnal_result->fetch(PDO::FETCH_ASSOC)) {
        $daftar_jurnal[$row['id_jurnal']] = $row['nama_jurnal'];
    }
}

// Query untuk mendapatkan tahun-tahun yang tersedia (untuk placeholder/suggestion)
$query_years = "SELECT DISTINCT strftime('%Y', tanggal) AS tahun FROM transaksi ORDER BY tahun DESC";
$years_result = $conn->query($query_years);

$available_years = [];
if ($years_result->num_rows > 0) {
    while($row = $years_result->fetch(PDO::FETCH_ASSOC)) {
        $available_years[] = $row['tahun'];
    }
}

// Query untuk data summary tahunan berdasarkan jurnal
$sql_summary = "SELECT
    j.id_jurnal,
    j.nama_jurnal,
    COUNT(t.id_transaksi) as total_transaksi,
    SUM(t.jumlah) as total_jumlah
FROM jurnal j
LEFT JOIN transaksi t ON j.id_jurnal = t.id_jurnal
    AND strftime('%Y', t.tanggal) = ?
    " . ($selected_jurnal ? " AND j.id_jurnal = $selected_jurnal " : "") . "
GROUP BY j.id_jurnal
ORDER BY j.id_jurnal";

$stmt = $conn->prepare($sql_summary);
$stmt->execute([$selected_year]);
$result_summary = $stmt->fetchAll(PDO::FETCH_ASSOC);

$summary_data = [];
$total_keseluruhan = 0;
if (count($result_summary) > 0) {
    foreach($result_summary as $row) {
        $summary_data[] = $row;
        $total_keseluruhan += $row['total_jumlah'] ?? 0;
    }
}

// Query untuk data bulanan berdasarkan jurnal
$sql_monthly = "SELECT
    strftime('%m', t.tanggal) as bulan,
    j.nama_jurnal,
    SUM(t.jumlah) as total_bulanan
FROM transaksi t
JOIN jurnal j ON t.id_jurnal = j.id_jurnal
WHERE strftime('%Y', t.tanggal) = ?
" . ($selected_jurnal ? " AND t.id_jurnal = $selected_jurnal " : "") . "
GROUP BY strftime('%m', t.tanggal), j.nama_jurnal
ORDER BY bulan, j.id_jurnal";

$stmt = $conn->prepare($sql_monthly);
$stmt->execute([$selected_year]);
$monthly_result = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Organize monthly data by month and journal
$monthly_data = array_fill(1, 12, []);
$month_names = [
    1 => 'Januari', 2 => 'Februari', 3 => 'Maret',
    4 => 'April', 5 => 'Mei', 6 => 'Juni',
    7 => 'Juli', 8 => 'Agustus', 9 => 'September',
    10 => 'Oktober', 11 => 'November', 12 => 'Desember'
];

if (count($monthly_result) > 0) {
    foreach($monthly_result as $row) {
        $bulan = $row['bulan'];
        $jurnal = $row['nama_jurnal'];
        if (!isset($monthly_data[$bulan][$jurnal])) {
            $monthly_data[$bulan][$jurnal] = 0;
        }
        $monthly_data[$bulan][$jurnal] += $row['total_bulanan'];
    }
}

// Query untuk transaksi terakhir
$sql_last_trans = "SELECT t.*, j.nama_jurnal, k.nama_kategori, s.nama_subkategori
                   FROM transaksi t
                   JOIN jurnal j ON t.id_jurnal = j.id_jurnal
                   LEFT JOIN subkategori s ON t.id_subkategori = s.id_subkategori
                   LEFT JOIN kategori k ON s.id_kategori = k.id_kategori
                   WHERE strftime('%Y', t.tanggal) = ?
                   " . ($selected_jurnal ? " AND t.id_jurnal = $selected_jurnal " : "") . "
                   ORDER BY t.tanggal DESC, t.created_at DESC
                   LIMIT 10";

$stmt = $conn->prepare($sql_last_trans);
$stmt->execute([$selected_year]);
$result_last_trans = $stmt->fetchAll(PDO::FETCH_ASSOC);

$last_transactions = [];
if (count($result_last_trans) > 0) {
    foreach($result_last_trans as $row) {
        $last_transactions[] = $row;
    }
}



// Include header
include 'views/header.php';
?>

<!-- Konten utama dashboard -->
<div class="card">
    <div class="card-header">
        <h5 class="card-title mb-0">Dashboard Keuangan Gereja</h5>
    </div>
    <div class="card-body">
        <!-- Filter Tahun dan Jurnal -->
        <div class="row mb-4">
            <div class="col-md-12">
                <form method="get" action="dashboard.php" class="row g-3 align-items-center" id="filterForm">
                    <div class="col-auto">
                        <label for="yearInput" class="col-form-label fw-bold">Tahun:</label>
                    </div>
                    <div class="col-auto">
                        <input type="number" 
                               name="tahun" 
                               id="yearInput" 
                               class="form-control" 
                               value="<?= $selected_year ?>" 
                               min="2000" 
                               max="<?= date('Y') + 5 ?>"
                               list="yearSuggestions"
                               placeholder="Masukkan tahun"
                               style="max-width: 120px; text-align: center;">
                        <datalist id="yearSuggestions">
                            <?php foreach($available_years as $year): ?>
                            <option value="<?= $year ?>">
                            <?php endforeach; ?>
                        </datalist>
                    </div>
                    <div class="col-auto">
                        <label for="jurnal" class="col-form-label fw-bold">Jurnal:</label>
                    </div>
                    <div class="col-auto">
                        <select name="jurnal" id="jurnal" class="form-select" onchange="submitFilter()">
                            <option value="">Semua Jurnal</option>
                            <?php foreach ($daftar_jurnal as $id => $nama): ?>
                                <option value="<?= $id ?>" <?= ($selected_jurnal == $id) ? 'selected' : '' ?>>
                                    <?= htmlspecialchars($nama) ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="col-auto">
                        <button type="submit" class="btn btn-primary">
                            <i class="bi bi-search me-1"></i>Cari
                        </button>
                        <?php if ($selected_jurnal || $selected_year != date('Y')): ?>
                            <a href="dashboard.php" class="btn btn-outline-secondary">
                                <i class="bi bi-arrow-clockwise me-1"></i>Reset
                            </a>
                        <?php endif; ?>
                    </div>
                </form>
            </div>
        </div>

        <!-- Card Summary -->
        <div class="row mb-4">
            <div class="col-md-12">
                <div class="card summary-card">
                    <div class="card-header">
                        <h6 class="mb-0">Ringkasan Tahun <?= $selected_year ?></h6>
                    </div>
                    <div class="card-body">
                        <?php if(!empty($summary_data)): ?>
                        <div class="row">
                            <?php foreach ($summary_data as $summary): ?>
                                <div class="col-md-3 mb-3">
                                    <div class="card bg-primary text-white">
                                        <div class="card-body text-center">
                                            <h6 class="card-title"><?= htmlspecialchars($summary['nama_jurnal']) ?></h6>
                                            <p class="card-text mb-1"><?= $summary['total_transaksi'] ?> Transaksi</p>
                                            <p class="card-text fs-5 fw-bold">Rp <?= number_format($summary['total_jumlah'] ?? 0, 0, ',', '.') ?></p>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                        <hr>
                        <div class="row">
                            <div class="col-md-12 text-center">
                                <h5>Total Keseluruhan Tahun <?= $selected_year ?></h5>
                                <p class="text-dark fs-3 fw-bold">Rp <?= number_format($total_keseluruhan, 0, ',', '.') ?></p>
                            </div>
                        </div>
                        <?php else: ?>
                        <div class="alert alert-warning">
                            <i class="bi bi-exclamation-triangle me-2"></i>
                            Tidak ada data untuk tahun <?= $selected_year ?>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>

        <!-- Tabel Manual Bulanan -->
        <div class="row">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header">
                        <h6 class="mb-0">Data Bulanan Manual Tahun <?= $selected_year ?></h6>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-striped table-hover">
                                <thead>
                                    <tr>
                                        <th>Bulan</th>
                                        <?php foreach ($daftar_jurnal as $id => $nama): ?>
                                            <th class="text-end"><?= htmlspecialchars($nama) ?></th>
                                        <?php endforeach; ?>
                                        <th class="text-end fw-bold">Total</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($month_names as $bulan_num => $bulan_nama): ?>
                                        <tr>
                                            <td><strong><?= $bulan_nama ?></strong></td>
                                            <?php
                                            $total_bulan_manual = 0;
                                            foreach ($daftar_jurnal as $id => $nama):
                                                $jumlah_manual = $monthly_data[$bulan_num][$nama] ?? 0;
                                                $total_bulan_manual += $jumlah_manual;
                                            ?>
                                                <td class="text-end">Rp <?= number_format($jumlah_manual, 0, ',', '.') ?></td>
                                            <?php endforeach; ?>
                                            <td class="text-end fw-bold">Rp <?= number_format($total_bulan_manual, 0, ',', '.') ?></td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                                <tfoot class="table-info">
                                    <tr>
                                        <td><strong>Total Tahun</strong></td>
                                        <?php
                                        $total_tahun_manual = 0;
                                        foreach ($daftar_jurnal as $id => $nama):
                                            $total_jurnal_manual = 0;
                                            foreach ($month_names as $bulan_num => $bulan_nama):
                                                $total_jurnal_manual += $monthly_data[$bulan_num][$nama] ?? 0;
                                            endforeach;
                                            $total_tahun_manual += $total_jurnal_manual;
                                        ?>
                                            <td class="text-end fw-bold">Rp <?= number_format($total_jurnal_manual, 0, ',', '.') ?></td>
                                        <?php endforeach; ?>
                                        <td class="text-end fw-bold">Rp <?= number_format($total_tahun_manual, 0, ',', '.') ?></td>
                                    </tr>
                                </tfoot>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card">
                    <div class="card-header">
                        <h6 class="mb-0">Transaksi Terbaru</h6>
                    </div>
                    <div class="card-body">
                        <?php if(!empty($last_transactions)): ?>
                        <div class="list-group list-group-flush">
                            <?php foreach ($last_transactions as $trans): ?>
                                <div class="list-group-item d-flex justify-content-between align-items-start">
                                    <div class="ms-2 me-auto">
                                        <div class="fw-bold"><?= htmlspecialchars($trans['nama_jurnal']) ?></div>
                                        <small class="text-muted">
                                            <?= htmlspecialchars($trans['nama_kategori'] ?? 'N/A') ?> - 
                                            <?= htmlspecialchars($trans['nama_subkategori'] ?? 'N/A') ?>
                                        </small>
                                    </div>
                                    <span class="badge bg-primary rounded-pill">
                                        Rp <?= number_format($trans['jumlah'], 0, ',', '.') ?>
                                    </span>
                                </div>
                            <?php endforeach; ?>
                        </div>
                        <?php else: ?>
                        <p class="text-muted">
                            <i class="bi bi-info-circle me-2"></i>
                            Tidak ada transaksi
                        </p>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>

        <!-- Tabel Detail Bulanan -->
        <div class="row mt-4">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <h6 class="mb-0">Detail Per Bulan Tahun <?= $selected_year ?></h6>
                    </div>
                    <div class="card-body">
                        <p>Section removed as per request.</p>
                    </div>
                </div>
            </div>
        </div>


    </div>
</div>

<?php
// Script untuk input tahun
$custom_scripts = '
// Event listener untuk tombol Enter pada input tahun
document.getElementById("yearInput").addEventListener("keypress", function(e) {
    if (e.key === "Enter") {
        e.preventDefault(); // Mencegah submit default
        document.getElementById("filterForm").submit(); // Submit form
    }
});

// Event listener untuk validasi input tahun
document.getElementById("yearInput").addEventListener("blur", function() {
    const year = parseInt(this.value);
    const minYear = 2000;
    const maxYear = new Date().getFullYear() + 5;

    if (year < minYear || year > maxYear) {
        alert("Tahun harus antara " + minYear + " sampai " + maxYear);
        this.value = new Date().getFullYear();
        this.focus();
    }
});
';

// Include footer
include 'views/footer.php';
?>