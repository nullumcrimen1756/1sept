<?php
// views/header.php
// Pastikan path ke url_helper.php benar
$url_helper_path = dirname(__DIR__) . '/includes/url_helper.php';
if (file_exists($url_helper_path)) {
    require_once $url_helper_path;
} else {
    // Fallback jika path tidak ditemukan
    require_once '../includes/url_helper.php';
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo isset($page_title) ? $page_title : 'Sistem Keuangan Gereja'; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <style>
        :root {
            --primary-color: #2c3e50;
            --secondary-color: #3498db;
            --accent-color: #e74c3c;
            --light-bg: #f8f9fa;
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: var(--light-bg);
            padding-top: 100px; /* Ditambah untuk memberi ruang header yang lebih besar */
        }
        
        .header {
            background-color: var(--primary-color);
            color: white;
            padding: 15px 20px;
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            z-index: 1000;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        
        .header h1 {
            margin: 0;
            font-size: 24px;
        }
        
        .header-nav {
            display: flex;
            align-items: center;
            gap: 15px;
        }
        
        .header-nav a {
            color: white;
            text-decoration: none;
            padding: 8px 12px;
            border-radius: 4px;
            transition: background-color 0.3s;
            display: flex;
            align-items: center;
            gap: 5px;
            font-size: 14px;
        }
        
        .header-nav a:hover {
            background-color: rgba(255, 255, 255, 0.1);
        }
        
        .header-nav a.active {
            background-color: var(--secondary-color);
        }
        
        .nav {
            background-color: #34495e;
            padding: 10px 20px;
            position: fixed;
            top: 70px; /* Disesuaikan dengan tinggi header yang baru */
            left: 0;
            right: 0;
            z-index: 999;
            display: flex;
            gap: 15px;
        }
        
        .nav a {
            color: white;
            text-decoration: none;
            padding: 5px 10px;
            border-radius: 4px;
            transition: background-color 0.3s;
        }
        
        .nav a:hover {
            background-color: var(--primary-color);
        }
        
        .nav a.active {
            background-color: var(--secondary-color);
        }
        
        .logout-btn {
            background-color: var(--accent-color);
            color: white;
            border: none;
            padding: 8px 15px;
            border-radius: 4px;
            cursor: pointer;
            font-size: 14px;
        }
        
        .logout-btn:hover {
            background-color: #c0392b;
        }
        
        .container {
            margin-top: 40px;
        }
        
        /* Tambahan untuk tabel data terstruktur */
        .table-structured {
            width: 100%;
            margin-bottom: 1rem;
            color: #212529;
        }
        
        .table-structured th {
            background-color: #2c3e50;
            color: white;
            padding: 0.75rem;
            vertical-align: top;
            border-top: 1px solid #dee2e6;
        }
        
        .table-structured td {
            padding: 0.75rem;
            vertical-align: top;
            border-top: 1px solid #dee2e6;
        }
        
        .table-structured tbody tr:nth-of-type(odd) {
            background-color: rgba(0, 0, 0, 0.05);
        }
        
        .table-structured tfoot tr {
            background-color: #f8f9fa;
            font-weight: bold;
        }
        
        .text-end {
            text-align: right !important;
        }
        
        /* Tambahan untuk dashboard */
        .summary-card {
            border-left: 4px solid var(--secondary-color);
        }
        
        .table-structured {
            font-size: 0.9rem;
        }
        
        .table-structured th {
            background-color: var(--primary-color);
            color: white;
            padding: 0.5rem;
            font-size: 0.85rem;
        }
        
        .table-structured td {
            padding: 0.5rem;
            font-size: 0.85rem;
        }
        
        .table-structured tbody tr:nth-of-type(odd) {
            background-color: rgba(0, 0, 0, 0.02);
        }
        
        .table-structured tfoot tr {
            background-color: var(--light-bg);
            font-weight: bold;
        }
        
        .list-group-item {
            border-left: 3px solid var(--secondary-color);
        }
        
        .card-header h6 {
            color: var(--primary-color);
            font-weight: 600;
        }

        /* Tambahan untuk form validation */
        .form-control:invalid {
            border-color: var(--accent-color);
            box-shadow: 0 0 0 0.25rem rgba(231, 76, 60, 0.25);
        }
        
        .form-control:valid {
            border-color: #28a745;
            border-width: 2px;
            box-shadow: 0 0 0 0.25rem rgba(40, 167, 69, 0.25);
        }
        
        .form-text {
            font-size: 0.875rem;
            color: #6c757d;
            line-height: 1.4;
        }
        
        .form-text i {
            color: var(--secondary-color);
        }
        
        .form-text strong {
            color: var(--primary-color);
        }
        
        .form-text .text-muted {
            color: #6c757d !important;
        }
        
        .form-text .text-success {
            color: #28a745 !important;
        }
        
        /* Styling untuk input yang sedang difokuskan */
        .form-control:focus {
            border-color: var(--secondary-color);
            box-shadow: 0 0 0 0.25rem rgba(52, 152, 219, 0.25);
        }
        
        /* Styling untuk placeholder */
        .form-control::placeholder {
            color: #adb5bd;
            font-style: italic;
        }
    </style>
</head>
<body>
    <div class="header">
        <h1><i class="bi bi-cash-coin me-2"></i>Sistem Keuangan Gereja</h1>
        
        <div class="header-nav">
            <?php if (isset($_SESSION['logged_in']) && $_SESSION['logged_in'] === true): ?>
                <div class="dropdown">
                    <span class="text-light me-3 dropdown-toggle" data-bs-toggle="dropdown" style="cursor: pointer;">
                        <i class="bi bi-person-circle me-1"></i>
                        <?php echo htmlspecialchars($_SESSION['username'] ?? 'User'); ?>
                        <?php 
                        // Get session info if available
                        $session_info = null;
                        if (function_exists('getLatestLoginInfo')) {
                            $session_info = getLatestLoginInfo($_SESSION['username']);
                        }
                        ?>
                    </span>
                    <div class="dropdown-menu dropdown-menu-end">
                        <div class="px-3 py-2">
                            <small class="text-muted">
                                <i class="bi bi-info-circle me-1"></i>
                                <?php if ($session_info): ?>
                                    <?php echo htmlspecialchars($session_info['browser'] ?? 'Unknown'); ?> 
                                    <?php echo htmlspecialchars($session_info['browser_version'] ?? ''); ?> 
                                    on <?php echo htmlspecialchars($session_info['operating_system'] ?? 'Unknown'); ?><br>
                                    <i class="bi bi-device me-1"></i>
                                    <?php echo htmlspecialchars($session_info['device_type'] ?? 'Desktop'); ?>
                                    <?php if (isset($session_info['device_model']) && $session_info['device_model']): ?>
                                        (<?php echo htmlspecialchars($session_info['device_model']); ?>)
                                    <?php endif; ?>
                                    <i class="bi bi-globe me-1"></i>
                                    <?php echo htmlspecialchars($session_info['ip_address'] ?? 'Unknown'); ?>
                                <?php else: ?>
                                    Informasi sesi tidak tersedia
                                <?php endif; ?>
                            </small>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
            
            <a href="<?= page_url('index.php', ['action' => 'dashboard']) ?>" class="<?= (isset($_GET['action']) && $_GET['action'] == 'dashboard') ? 'active' : '' ?>">
                <i class="bi bi-speedometer2 me-1"></i>Dashboard
            </a>
            <a href="<?= url('admin_kategori.php') ?>" class="<?= active_class('admin_kategori.php') ?>">
                <i class="bi bi-tags me-1"></i>Kelola Kategori
            </a>
<a href="<?= page_url('index.php', ['action' => 'login_sessions']) ?>" class="<?= active_class('login_sessions.php') ?>">
                <i class="bi bi-clock-history me-1"></i>Sesi Login
            </a>

            <?php if (isset($_SESSION['logged_in']) && $_SESSION['logged_in'] === true): ?>
                <form action="<?= url('logout.php') ?>" method="post">
                    <button type="submit" class="logout-btn">
                        <i class="bi bi-box-arrow-right me-1"></i>Logout
                    </button>
                </form>
            <?php endif; ?>
        </div>
    </div>
    
    <?php if (isset($_SESSION['logged_in']) && $_SESSION['logged_in'] === true): ?>
    <div class="nav">
        <a href="<?= url('index.php') ?>" class="<?= active_class('index.php') ?>">
            <i class="bi bi-journal-plus me-1"></i>Input Transaksi
        </a>
        <a href="<?= page_url('index.php', ['action' => 'sheet1_report']) ?>" class="<?= (isset($_GET['action']) && $_GET['action'] == 'sheet1_report') ? 'active' : '' ?>">
            <i class="bi bi-table me-1"></i>Laporan Sheet 1
        </a>
        <a href="<?= page_url('index.php', ['action' => 'sheet2_report']) ?>" class="<?= (isset($_GET['action']) && $_GET['action'] == 'sheet2_report') ? 'active' : '' ?>">
            <i class="bi bi-list-check me-1"></i>Laporan Sheet 2
        </a>
        <a href="<?= page_url('index.php', ['action' => 'sheet3_report']) ?>" class="<?= (isset($_GET['action']) && $_GET['action'] == 'sheet3_report') ? 'active' : '' ?>">
            <i class="bi bi-table me-1"></i>Laporan Sheet 3
        </a>
        <a href="<?= page_url('index.php', ['action' => 'laporan_keuangan']) ?>" class="<?= (isset($_GET['action']) && $_GET['action'] == 'laporan_keuangan') ? 'active' : '' ?>">
            <i class="bi bi-file-earmark-text me-1"></i>Penerimaan & Pengeluaran
        </a>
    </div>
    <?php endif; ?>
    
    <div class="container">
