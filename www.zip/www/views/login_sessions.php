<?php
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../functions.php';
if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
    header('Location: login.php');
    exit;
}

$username = $_SESSION['username'] ?? '';
$sessions = getActiveSessions($username);

$page_title = "Sesi Login Aktif";

include 'header.php';
?>

<div class="container mt-4">
    <div class="card">
        <div class="card-header">
            <h4 class="card-title mb-0">
                <i class="bi bi-clock-history me-2"></i>
                Sesi Login Aktif - <?php echo htmlspecialchars($username); ?>
            </h4>
        </div>
        <div class="card-body">
            <?php if (empty($sessions)): ?>
                <div class="alert alert-info">
                    <i class="bi bi-info-circle me-2"></i>
                    Tidak ada sesi login yang ditemukan.
                </div>
            <?php else: ?>
                <div class="table-responsive">
                    <table class="table table-striped table-hover">
                        <thead class="table-dark">
                            <tr>
                                <th>Waktu Login</th>
                                <th>Alamat IP</th>
                                <th>Browser</th>
                                <th>Sistem Operasi</th>
                                <th>Tipe Perangkat</th>
                                <th>User Agent</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($sessions as $session): ?>
                            <tr>
                                <td><?php echo date('d-m-Y H:i:s', strtotime($session['waktu_login'])); ?></td>
                                <td><?php echo htmlspecialchars($session['ip_address']); ?></td>
                                <td>
                                    <?php 
                                    $browser = htmlspecialchars($session['browser'] ?? 'Unknown');
                                    if (!empty($session['browser_version'])) {
                                        $browser .= ' ' . htmlspecialchars($session['browser_version']);
                                    }
                                    echo $browser;
                                    ?>
                                </td>
                                <td><?php echo htmlspecialchars($session['operating_system'] ?? 'Unknown'); ?></td>
                                <td><?php echo htmlspecialchars($session['device_type'] ?? 'Unknown'); ?></td>
                                <td>
                                    <small class="text-muted">
                                        <?php echo htmlspecialchars(substr($session['user_agent'] ?? '', 0, 50)); ?>...
                                    </small>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
            
            <div class="mt-3">
                <a href="dashboard.php" class="btn btn-primary">
                    <i class="bi bi-arrow-left me-1"></i>Kembali ke Dashboard
                </a>
            </div>
        </div>
    </div>
</div>

<?php include 'footer.php'; ?>
